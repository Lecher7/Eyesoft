use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Process Registration
# This adds new accounts to the database
	my $delimiter = ":::";
	my $nowtime = (time);
	my $ftype = "Debit";
	my $opentime = (time);
	my $listtable;
	if ($config{'affildir'}) {
		umask(000);  # UNIX file permission junk
		mkdir("$config{'basepath'}$config{'affildir'}", 0777) unless (-d "$config{'basepath'}$config{'affildir'}");		
		&oops('You must enter an alias that consists of alphanumeric characters.') if $form{'ALIAS'} =~ /\W/ or !($form{'ALIAS'});
		&oops('You must enter a valid e-mail address.') unless ($form{'EMAIL'} =~ /^.+\@.+\..+$/);
#		###Added for Multi-Alias####
#		$form{'EMAIL'} = lc($form{'EMAIL'}); 
#		&multalias;
#    ###End - Added for Multi-Alias####		
		$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
#####################################################################
# Check the reg directory and see if the person 
# exists.  If not, send an error message to the screen, otherwise proceed.
#####################################################################		
		if (!(-f "$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat")) {
			&headers;
			print "You must be a Registered User to be an Affiliate!\n";
			&footers;		
		}	else {

			if (!(-f "$config{'basepath'}$config{'affildir'}/$form{'ALIAS'}.dat")) {
				&oops('We were unable to write to the user directory.') unless (open NEWREG, ">$config{'basepath'}$config{'affildir'}/$form{'ALIAS'}.dat");
	#			my $newpass = &randompass; 
				my $newtime = (time);
				print NEWREG "$form{'PASS'}\n$form{'EMAIL'}\n$newtime";
				close NEWREG;
	#
	#				
				require "sendemail.pl";
				&headers;
				print "$form{'ALIAS'}, <br>you should receive an e-mail to $form{'EMAIL'} in a few minutes.  This is just to confirm you entered your email address correctly.  If you do not get an e-mail, please re-register.\n";
				&footers;
				&sendemail($form{'EMAIL'}, $config{'admin_address'}, 'Affiliate Confirmation', "PLEASE DO NOT REPLY TO THIS E-MAIL.\n\nThank you for registering to become an affiliate at $config{'sitename'}!\n\nYour account will be credited $5 for every new person registered with you as their referrer.  You can use this credit to add extra's to your listings, such as bold face, attention grabbers or adding it to the Featured Items section.  There is NO COST to the seller for standard auctions, costs apply only to those extras mentioned previously.\nPlease use this code when linking to $config{'sitename'}:\nhttp://www.aftk.com/cgi-bin/eyeauction.cgi?action=reg&affiliate=$form{'ALIAS'}\n\nThank you for visiting!");
			}
			else {
				&headers;
				print "You have already signed up to be an Affiliate!\n";
				&footers;
			}
		}
	}
	else {
		&headers;
		print "User Registration is Not Implemented on This Server!  The System Administrator Did Not Specify a Registration Directory...\n";
		&footers;
	}
	


#-#############################################
# Sub: Random Password
# This generates psudo-random 8-letter
# passwords

sub randompass {
	srand(time ^ $$);
	my @passset = ('a'..'k', 'm'..'n', 'p'..'z', '2'..'9');
	my $randpass = "";
	for (my $i=0; $i<8; $i++) {
		$randpass .= $passset[int(rand($#passset + 1))];
	}
	return $randpass;
}

#-#############################################
# Sub: Headers
sub headers{
print "<HTML>";
print "<HEAD>";
print "<TITLE></TITLE>";
print "</HEAD>";
print "$config{'header'}";
print "$config{'navbar'}";			
}

#-#############################################
# Sub: Footers
sub footers{
print "$config{'navbar'}";
print "$config{'footer'}";
print "</BODY>";
print "</HTML>";
}

###Added for Multi-Aliasing####
#########################
sub multalias {
my $file;
opendir THEDIR, "$config{'basepath'}/$config{'affildir'}" || die "Unable to open directory: $!";
my @allfiles = readdir THEDIR;
closedir THEDIR;
foreach $file (@allfiles) {
if ($file =~ /\.dat/){ 
open REGFILE, "$config{'basepath'}/$config{'affildir'}/$file";
my($pass, $email) = <REGFILE>;      # be sure to edit this to match the rest of your script
chomp($pass, $email);	     # be sure to edit this to match the rest of your script
close REGFILE;
# if ($form{'EMAIL'} =~ $email) {
# &oops3
# }
}
}
}

##############################################
# Sub: Oops3!
# This generates an error message for multiple accounts and dies.

sub oops3 {
&headers;
print "This e-mail address, <b>$form{'EMAIL'}</b>, has already been
registered. ";
die "This e-mail address, <b>$form{'EMAIL'}</b>, has already been
registered. ";
&footers;
} 

###End Multi-Aliasing####