use strict;
#
##########################################################
#                                                        #  
#   This creates a "nice" list of Images in a category.  #
#             				                     # 
#                                                        # 
my $subcatarray = &subcats;
opendir THEDIR, "$config{'basepath'}$form{'category'}" or &oops("Category directory $form{'category'} could not be opened.");
readdir THEDIR;readdir THEDIR;
my @allfiles = sort { $a <=> $b } map {int $_} readdir THEDIR;
closedir THEDIR;
my ($file, $listgallery, $highbidder, $image, $col, $pageb);
my $a=1;
my $b=1;
my $pagebreak = int $form{pb} || $config{'dispcatgal_pb'};
my ($icount, $pcount) = (0,0);
$image = "<IMG SRC=$image>" if ($image);
    foreach $file (@allfiles) {
    $file =~ s/^$config{'basepath'}$form{'category'}\///;
    $file =~ s/\.dat$//;
    if (my ($title, $reserve, $inc, $desc, $image, $grabber, $gallery, $condition, $payment, $shipping, $gallery, @bids) = &read_item_file($form{'category'},$file)) {
	my $numbids = $#bids;	
 	my ($selleralias, $selleremail, $sellerbid, $sellertime, $selleradd1, $selleradd2, $selleradd3) = &read_bid($bids[0]);
     	  $image = "<IMG SRC=$image width=95 height=95>" if ($image);
	      if ($gallery eq 'yes') {
               if(++$icount > $pagebreak){$icount=1; $pcount++}
	         next if $pcount != $form{page};
               my $closetime = &get_time($file);
 		   if ($b==1){
 		   $col="lightblue";
		   }else{
  		   $col="#98CDCA";
		   }
   		   if ($a==1) { 
   		   $listgallery .="\n <TR bgcolor=$col>";
 		   $b=!$b;
 		   }
		   my ($alias, $email, $lastbid, $time, $add1, $add2, $add3) = &read_bid($bids[$numbids]); # read last bid
               if ($alias eq $selleralias){
	         $highbidder = "No bids yet";
               }else{ 
		   $highbidder = $lastbid;
		   }    
	         $listgallery .="\n <TD width=25% align=center><FONT SIZE=-1 FACE=ARIAL><B>Item:</B><FONT SIZE=-1> $file</B></FONT><br><A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}\&item=$file>$image</a><br><center><FONT SIZE=-3 FACE=ARIAL>Current Bid</font><br><FONT SIZE=-2 FACE=ARIAL>\$$highbidder<br>
 	         (<B>Bids:</b>  $#bids)</FONT><br>";
	    	   $listgallery .= "$config{'new'}" if (($sellertime + (86400 * $config{'newdays'})) > time);
		   $listgallery .= "&nbsp;$config{'hot'}" if ($#bids >= $config{'hotnum'});
	         #-- Uncomment the next two lines if you want to show reserevmet or no reserve icons. Then set it up in config just like $endicon!-#
               #$listgallery .= "&nbsp;$config{'nores'}" if ($reserve <= 0);
		   #$listgallery .= "&nbsp;$config{'reser'}" if (($sellerbid >= $reserve) && ($reserve > 0));
               #---------------------------------------------------------------------------------------------------------------------------------#   
               $listgallery .="<br><FONT SIZE=-2 FACE=ARIAL><b><center>Ends:</center></b><center>$closetime</center></font>";
     
      	   if ($a==4) {
   		   $listgallery .= "\n </TR>";
   		   $a=1;
   		   }else{
   		   $a++;
   	         }
            }
	  }  
    }
    if ($a>1 && $a<4) { $listgallery .= "\n </TR>\n";}
    if (!@allfiles){
        $pageb .= "<p align=center><font color=#FF0000><b>No images in this category</b></font></p>";
    }
    my $listbar .="<P><P ALIGN=CENTER><FONT SIZE=-1>Current |";
    $listbar .="| Images In A Category ||";
   ######################## DO NOT UNCOMMENT THIS LINE #######################################
   #$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=catall&level=$form{'level'}>Images In All Catagories</A> |";
   ############################################################# FUTURE EXPANSION ############
    $listbar .= "</FONT></P>\n";

    print &load_template ('dispcatgal.html', { 
		LISTBAR	=>	$listbar,
		THISCAT 	=> 	"Top:$category{$form{'category'}}",
            SUBCATARRAY  =>    $subcatarray,
		LISTGALLERY	=> 	$listgallery,
		PAGEB       =>    $pageb,
    #        CATLEVEL    =>    $form{'category'},
		%globals
		}); 

pagebreak($pcount, $pagebreak);

#-#############################################
# Sub: SubCats
# Makes a table of subcategories with stats
#
sub subcats {
	my (@subcats, @catarray, $nextlevel, $output, %stats, %cattree, $key);
	$nextlevel = $form{'level'} + 1;
	foreach $key (sort keys %category) {
		umask(000);  # UNIX file permission junk
		mkdir("$config{'basepath'}$key", 0777) unless (-d "$config{'basepath'}$key");
		@catarray = split (/\//,$key);
		if ($catarray[$nextlevel] && ($catarray[$form{'level'}] eq $form{'category'})){
			push (@subcats, $catarray[$nextlevel]);
			opendir DIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
			$stats{$catarray[$nextlevel]} = scalar(grep -T, map "$config{'basepath'}$key/$_", readdir DIR);
			$cattree{$catarray[$nextlevel]} = $key; 
			closedir DIR;
		}
	}
	if (@subcats){
		$output = qq|<div><table width="80%" border="$config{'tableborder0'}" cellspacing="$config{'tablecellspace0'}" cellpadding="$config{'tablecellpad0'}"><tr><td valign="top">\n|;
		my $i = 0;
		my $cat;
		my $catclean;
		my $half = int (($#subcats+2) / 2);
    	foreach $cat (sort @subcats) { 
			$catclean = $cat;
			$catclean =~ s/_/ /g;
        	if ($i == $half) {
            	$output .= qq|</td><td valign="top">\n|;
        	}
        	$i++;
        	$output .= qq|<dl><dt><strong><a href="$ENV{'SCRIPT_NAME'}\?category=$cattree{$cat}&level=$nextlevel&listtype=catgal&level=$nextlevel">$catclean</a></strong> <small>($stats{$cat})</small></dt></dl> |;
		}
    	$output .= "</td></tr></table></div>\n";
	}
    return $output;
}

###############################################
###    Get_Time 1.0 by Xev  (ea@xev.net)    ### 
###  Do not distribute without this header  ###
###############################################
# Using Xev's Time routine. I think it looks ##
# nicer than timeleft.                       ##
#                                            ##
#       Format the time to look nice         ##
#                                            ## 
sub get_time {
my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst) = localtime($_[0]);
$hour = 12 if $hour == 0;
$min = "0$min" if length($min) == 1;
my $pmam;
    if ($hour > 12) {
    $pmam = "PM";
    $hour = ($hour - 12);
    }else{
    $pmam = "AM";
    }
    if ($_[1]) {
    $mon++;
    return "$mon/$mday $hour:$min $pmam";
    }else{
    my @mon = qw/Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec/;
    my @wday = qw/Sun Mon Tue Wed Thu Fri Sat/;
    $year = ($year + 1900);
    return "$wday[$wday], $mon[$mon] $mday, $year $hour:$min $pmam PST";
    }
}
#-#############################################
# Sub: Pagebreak
# This displays pagebreak links

sub pagebreak{
	my $begin = "<center>";
	my $next = "Next Page >>";
	my $nonext = "Next Page >>";
	my $previous = "<< Previous Page";
	my $noprevious = "<< Previous Page";
	my $end = "</center>";
	
	my $urlfragment;
	foreach(keys %form){
		next if($_ eq 'pb' || $_ eq 'page');
		my $f = $form{$_};
		$f=~s/(\W)/'%'.unpack("H2", $1)/eg;
		$urlfragment.='&' if $urlfragment;
		$urlfragment.="$_=$f";
	}
	my($pcount, $pagebreak) = @_;

	# Print Pagebreak Links
	print $begin;
	if($form{page} > 0){ print "<br> <a href=$ENV{SCRIPT_NAME}?$urlfragment&page=@{[$form{page}-1]}&pb=$form{pb}><font face=verdana size=2>$previous</a> " }
	else{ print "<br><font face=verdana size=2> $noprevious " }
	print "|";
	for(0..$form{page}-1){ print " <a href=$ENV{'SCRIPT_NAME'}?$urlfragment&page=$_&pb=$form{pb}><font face=verdana size=2>@{[$_+1]}</a> " }
	print " <b>", int($form{page})+1, "</b> ";
	for($form{page}+1..$pcount){ print " <a href=$ENV{'SCRIPT_NAME'}?$urlfragment&page=$_&pb=$form{pb}><font face=verdana size=2>@{[$_+1]}</a> " }
	if($pcount>0){ print " <a href=$ENV{'SCRIPT_NAME'}?$urlfragment&pb=@{[(1+$pcount)*$pagebreak]}><font face=verdana size=2>All</a> " }
	print "|";
	if($form{page} < $pcount){ print " <a href=$ENV{'SCRIPT_NAME'}?$urlfragment&page=@{[$form{page}+1]}&pb=$form{pb}><font face=verdana size=2>$next</a><br><br> " }
	else{ print "<font face=verdana size=2> $nonext<br><br> " }
	print $end;
}
1;