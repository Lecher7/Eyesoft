use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
# 
#-#############################################
# Display List Of Items
# This creates a "nice" list of items in a
# category.
	my $subcatarray = &subcats;
	opendir THEDIR, "$config{'basepath'}$config{'closedir'}$form{'category'}" or &oops("Category directory $form{'category'} could not be opened.");
	my @allfiles = grep -T, map "$config{'basepath'}$config{'closedir'}$form{'category'}/$_", sort { int($a) <=> int($b) } (readdir THEDIR);
	closedir THEDIR;
	my ($file, $listtable);
	my @cellcolor=($config{'colortablerowodd'},$config{'colortableroweven'});
	my $color = 0;
	foreach $file (@allfiles) {
		$file =~ s/^$config{'basepath'}$config{'closedir'}$form{'category'}\///;
		$file =~ s/\.dat$//;
		if (my ($iteminfo, $image, $desc, @bids) = &read_item_file("$config{'closedir'}$form{'category'}",$file)) {
			my @itemvals = split(/:::/, $iteminfo);
			my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
			my ($selleralias, $selleremail, $sellerbid, $sellertime, $selleradd1, $selleradd2, $selleradd3) = &read_bid($bids[0]);
			my @closetime = localtime($file);
			my $boldon ="";
			my $boldoff ="";
			$closetime[4]++;
			$closetime[5] =~ s/1//;
			my $rowcolor = $cellcolor[$color];
			my $grabberpic ="";
			$grabberpic .= "$config{'siren'}" if ($itemvals[4] eq 'siren');
			$grabberpic .= "$config{'eyes'}" if ($itemvals[4] eq 'eyes');
			$grabberpic .= "$config{'hand'}" if ($itemvals[4] eq 'hand');
			$grabberpic .= "$config{'arrowred'}" if ($itemvals[4] eq 'arrow_red');
			$grabberpic .= "$config{'box'}" if ($itemvals[4] eq 'box');
			$grabberpic .= "$config{'cdrom'}" if ($itemvals[4] eq 'cdrom');
			$grabberpic .= "$config{'click'}" if ($itemvals[4] eq 'click');
			$grabberpic .= "$config{'clock'}" if ($itemvals[4] eq 'clock');
			$grabberpic .= "$config{'cool1'}" if ($itemvals[4] eq 'cool1');
			$grabberpic .= "$config{'hot1'}" if ($itemvals[4] eq 'hot1');
			$grabberpic .= "$config{'dot'}" if ($itemvals[4] eq 'dot');
			$grabberpic .= "$config{'star'}" if ($itemvals[4] eq 'star');	
			$boldon .= "<b>" if ($itemvals[6] eq '1');
			$boldoff .= "</b>" if ($itemvals[6] eq '1');			
			$listtable .= "<TR><TD width=35 BGCOLOR=$rowcolor ALIGN=LEFT>$grabberpic&nbsp;</td><TD BGCOLOR=$rowcolor ALIGN=LEFT>$boldon<A HREF=$ENV{'SCRIPT_NAME'}\?action=dispcloseditem&category=$form{'category'}\&item=$file>$itemvals[0]</A>";
			$listtable .= "$config{'pic'}" if ($image);
			$listtable .= "$config{'hot'}" if ($#bids >= $config{'hotnum'});
			$listtable .= "$boldoff</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>\$$bid</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$#bids</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$closetime[4]/$closetime[3]/$closetime[5] $closetime[2]:$closetime[1]:$closetime[0]</TD></TR>\n";
			$color = int(!($color));
		}
	}
	if (!@allfiles){
		$listtable = "<TR><td></td><TD>No Listings in this Category</TD><TD></TD><TD></TD><TD></TD></TR>";
	}
	my $listbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1><A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=current&level=$form{'level'}>Current</A> |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=new&level=$form{'level'}>New Today</A> |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=hot&level=$form{'level'}>Hot</A> |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=closingtoday&level=$form{'level'}>Closing Today</A> |";
	$listbar .= "| Completed |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=going&level=$form{'level'}>Going, Going, Gone</A>";
	$listbar .= "</FONT></P>\n";

    print	&load_template ('displistclosed.html', { 
				LISTBAR		=>	$listbar,
				SUBCATARRAY	=>	$subcatarray,
				THISCAT 	=> 	"Top:$category{$form{'category'}}",
				LISTTABLE 	=> 	$listtable,
				%globals
	}); 
#-#############################################
# Sub: SubCats
# Makes a table of subcategories with stats
#
sub subcats {
	my (@subcats, @catarray, @catfixed, $nextlevel, $catname, $output, $level1, $level2, $level3, $level4, $level5, %stats, %cattree, $key);
	$nextlevel = $form{'level'} + 1;
	my ($X, $Y, %saw);
	my $totalfiles = 0;
	foreach $key (sort keys %category) {
		umask(000);  # UNIX file permission junk
		mkdir("$config{'basepath'}$key", 0777) unless (-d "$config{'basepath'}$key");
		@catarray = split (/\//,$key);
##################################		
#		if ($catarray[$nextlevel] && ($catarray[$form{'level'}] eq $form{'category'})){
#			push (@subcats, $catarray[$nextlevel]);
#			opendir DIR, "$config{'basepath'}$config{'closedir'}$key" or &oops("Category directory $key could not be opened.");
#			$stats{$catarray[$nextlevel]} = scalar(grep -T, map "$config{'basepath'}$config{'closedir'}$key/$_", readdir DIR);
#			$cattree{$catarray[$nextlevel]} = $key; 
#			closedir DIR;
#		}
#	}
####################################################
# Added 6/20/02 to create sub-sub cats.  Added "level1", "X" and "Y" variables
# to accomplish task.  Follow the below logic structure to create an unlimited
# amount of sub-sub-sub cats
#

$level1 = ($catarray[$form{'level'}]);

 if ($form{'level'} == 0){
  $X = $catarray[0];
  $Y = "$catarray[0]/$catarray[1]";
 }elsif ($form{'level'} == 1){
  $X = "$catarray[0]/$catarray[1]";
  $Y = "$catarray[0]/$catarray[1]/$catarray[2]";
 }elsif ($form{'level'} == 2){
  $X = "$catarray[0]/$catarray[1]/$catarray[2]";
  $Y = "$catarray[0]/$catarray[1]/$catarray[2]/$catarray[3]";
 }else{
  $X = "$catarray[0]/$catarray[1]/$catarray[2]/$catarray[3]";
  $Y = "$catarray[0]/$catarray[1]/$catarray[2]/$catarray[3]/$catarray[4]";
 }
 
		if ($catarray[$nextlevel] && ($X eq $form{'category'})){
			push (@subcats, $catarray[$nextlevel]);
			$level1 = "$level1/$catarray[$nextlevel]";
			opendir DIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
			$totalfiles = scalar(grep -T, map "$config{'basepath'}$key/$_", readdir DIR);			
			$cattree{$catarray[$nextlevel]} = $Y; 
			closedir DIR;
			$stats{$catarray[$nextlevel]} = $stats{$catarray[$nextlevel]} + $totalfiles
		}
	}
###############################	
	if (@subcats){
		$output = qq|<div><table width="80%" border="$config{'tableborder0'}" cellspacing="$config{'tablecellspace0'}" cellpadding="$config{'tablecellpad0'}"><tr><td valign="top">\n|;
		my $i = 0;
		my $cat;
		my $catclean;
################################
#		Removed this section 6/16/02 and fixed it so to create multiple columns.
#		To change the number of columns, change the variable called "half"
#
#		my $half = int (($#subcats+1) / 2);
#    	foreach $cat (sort @subcats) { 
#			$catclean = $cat;
#			$catclean =~ s/_/ /g;
#        	if ($i == $half) {
#        			$i=0;
#            	$output .= qq|</td><td valign="top">\n|;
#        	}
#        	$i++;
#        	$output .= qq|<dl><dt><strong><a href="$ENV{'SCRIPT_NAME'}\?category=$cattree{$cat}&level=$nextlevel&listtype=current">$catclean</a></strong> <small>($stats{$cat})</small></dt></dl> |;
#		}
		my $half = int (($#subcats+1) / 2);
    	foreach $cat (sort @subcats) { 
			$catclean = $cat;
			$catclean =~ s/_/ /g;
        	if ($i == $half) {
        			$i=0;
            	$output .= qq|</td></tr><tr><td valign="top">\n|;
        	}
        	$i++;
        	$output .= qq|<dl><dt><strong><a href="$ENV{'SCRIPT_NAME'}\?category=$cattree{$cat}&level=$nextlevel&listtype=closed">$catclean</a></strong> <small>($stats{$cat})</small></dt></dl></td><td> |;
		}		
    	$output .= "</td></tr></table></div>\n";
	}
    return $output;
}

#-#############################################
# Sub: Movefile(file1, file2)
# This moves a file.  Quick and dirty!

sub movefile {
	my ($firstfile, $secondfile) = @_;
	return 0 unless open(FIRSTFILE,$firstfile);
	my @lines=<FIRSTFILE>;
	close FIRSTFILE;
	return 0 unless open(SECONDFILE,">$secondfile");
	my $line;
	foreach $line (@lines) {
		print SECONDFILE $line;
	}
	close SECONDFILE;
	return 0 unless unlink($firstfile);
	return 1;
}
   
1;
