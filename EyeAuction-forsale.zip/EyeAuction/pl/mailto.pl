use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
# 
#------------------------------------------------------#
# Mail Auction To A Friend
# This gets the form input info for mailing the auction
#------------------------------------------------------#
	&oops("Item $form{'item'} could not be opened.") unless (my ($iteminfo, $image, $desc, @bids) = &read_item_file($form{'category'},$form{'item'}));
	my @itemvals = split(/:::/, $iteminfo);
	my ($selleralias, $selleremail, $sellerbid, $sellertime, $selleradd1, $selleradd2, $selleradd3) = &read_bid($bids[0]); # read first bid
	my $numbids = $#bids;
	my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$numbids]); # read last bid
    print	&load_template ('mailto.html', { 
       DESC  		=>    $desc,        
       BID  		=>    $bid,        
	   CATTREE		=>	  $form{'category'},
       ITEMNUM  	=>    $form{'item'},        
       ITEMTITLE  	=>    $itemvals[0],        
				%globals
	});      
1;



