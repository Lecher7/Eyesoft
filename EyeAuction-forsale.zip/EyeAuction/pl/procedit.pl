use strict;
#require Time::Local;
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Process New Item
# This processes new item to be put up for
# sale from a posted form

	my ($password, @userbids);
	if ($config{'regdir'} ne "") {
		$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
		&oops('Your alias could not be found!') unless ($password, $form{'EMAIL'}, $form{'ADDRESS1'}, $form{'ADDRESS2'}, $form{'ADDRESS3'}, @userbids) = &read_reg_file($form{'ALIAS'});
		&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	}
	&oops('You must have an item title that is up to 50 characters.') unless ($form{'TITLE'} && (length($form{'TITLE'}) < 51));
	$form{'TITLE'} =~ s/\</\&lt\;/g;
	$form{'TITLE'} =~ s/\>/\&gt\;/g;
        &oops('You must select a valid category.') unless (-d "$config{'basepath'}$form{'CATEGORY'}" and $category{$form{'CATEGORY'}}) or ($form{'DELETE'} eq "YES");
	$form{'IMAGE'} = "" if ($form{'IMAGE'} eq "http://");
	&oops('You must enter an item description.') unless ($form{'DESC'});
	&oops('You must enter an alias to track your item.') unless ($form{'ALIAS'});
	&oops('You must enter a valid e-mail address.') unless ($form{'EMAIL'} =~ /^.+\@.+\..+$/);
	&oops('You must enter a valid starting bid.') unless ($form{'BID'} =~ /^(\d+\.?\d*|\.\d+)$/);
	&oops('You must enter a valid bid increment.') unless (($form{'INC'} =~ /^(\d+\.?\d*|\.\d+)$/) and ($form{'INC'} >= .01));
	$form{'INC'} = &parsebid($form{'INC'});
	$form{'RESERVE'} = &parsebid($form{'RESERVE'});
	&oops('You must enter your full name.') unless ($form{'ADDRESS1'});
	&oops('You must enter your street address.') unless ($form{'ADDRESS2'});
	&oops('You must enter your city, state, and zip code.') unless ($form{'ADDRESS3'});
	########### Fix For Yr 2001 - Item Number Generation & Ending date patch ######################
#				$item_number = $form{'ITEM'};
        my $timenum = time;
        my $dayoffset = ($form{'HOURS'} * 3600) + ($form{'MINS'} * 60);
       my $item_number = ($form{'DAYS'} * 86400 + time + $dayoffset);
#        &oops('You must enter the number of days your auction should run, from 1 to 14.') unless (($item_number > time) && ($form{'DAYS'} > 0));
       $item_number = ($form{'DAYS'} * 86400 + time + $dayoffset) until (!(-f "$config{'basepath'}$form{'CATEGORY'}/$item_number.dat"));
       $item_number++ until (!(-f "$config{'basepath'}$form{'CATEGORY'}/$item_number.dat"));
  ########### Fix For Yr 2001 - Item Number Generation End ######################################
  
  $item_number = $form{'ITEM'};
# print "item: $item_number\n";
	if ($form{'FROMPREVIEW'}) {
		my $key;
		foreach $key (keys %form) {
			$form{$key} =~ s/\[greaterthansign\]/\>/gs;
			$form{$key} =~ s/\[lessthansign\]/\</gs;
			$form{$key} =~ s/\[quotes\]/\"/gs;
		}
		
		
####################################
# Fees for auctions go here
#	my $counterfee;
#	if ( $form{'COUNTER'} ne "N" ) {
#		$counterfee = &parsebid($config{'count_amount'});
#		# &apply_transaction($form{'ALIAS'}, "Attention Grabber Image Fee for #$form{'ITEM'}", "$config{'grabbercharge'}", "Attention Grabber - $form{'TITLE'}", 1, 1, 1, 0);
#	}else{
#		$counterfee = "0.00";
#	}
#	
#	my $grabberfee;
#	if ( $form{'GRABBER'} ne "none" ) {
#		$grabberfee = &parsebid($config{'grabbercharge'});
#		# &apply_transaction($form{'ALIAS'}, "Attention Grabber Image Fee for #$form{'ITEM'}", "$config{'grabbercharge'}", "Attention Grabber - $form{'TITLE'}", 1, 1, 1, 0);
#	}else{
#		$grabberfee = "0.00";
#	}
#	
#	my $fee;
#	if ($config{'post_amount'} > 0) {
#		$fee = &parsebid($config{'post_amount'});
#	}else{
#		$fee = "0.00";
#	}
#	
#	my $boldfee;
#	my $B;
#	if ($form{'BOLDITEM'} eq "1") {
# 		$boldfee = &parsebid($config{'bold_amount'});
#		$B = "<font color=red><b> B </b></font>";
#	}else {
# 		$boldfee = "0.00";
#		$B = "";
#	}
#	
#	my $featfee;
#	my $F;
#	if ($form{'CATFEAT'} eq "CATFEATYES") {
# 		$featfee = &parsebid($config{'feat_amount'});
#		$F = "<font color=green><b> F </b></font>";
#	}else{
# 		$featfee = "";
#		$F = "";
#	}
#	
#	my $buyitfee;
#	my $BN;
#	if ($form{'BUYITNOW'} eq "1") {
# 	$buyitfee = &parsebid($config{'buyit_amount'});
#	$BN = "<font color=navy><b> BN </b></font>";
#	}else{
# 	$buyitfee = "";
#	$BN = "";
#	}
#	my $bannerfee;
#	my $BF;
#	if ($form{'BANNERIMAGEURL'} ne "") {
# 	$bannerfee = &parsebid($config{'banner_amount'});
#	$BF = "<font color=maroon><b> BF </b></font>";
#	}else{
# 	$bannerfee = "";
#	$BF = "";
#	}
#	my $twocatfee;
#	my $TC;
#	if ($form{'CATEGORY2'}) {
# 	$bannerfee = &parsebid($config{'two_cat_fee'});
#	$TC = "<font color=#800080><b> TC </b></font>";
#	}else{
# 	$twocatfee = "";
#	$TC = "";
#	}
#	my $posting_charges;
#	$posting_charges = "$config{'post_fee_1'}" if ($form{'BID'} < $config{'post_range_1'});
#	$posting_charges = "$config{'post_fee_2'}" if (($form{'BID'} >= $config{'post_range_1'}) and ($form{'BID'} < $config{'post_range_2'}));
#	$posting_charges = "$config{'post_fee_3'}" if (($form{'BID'} >= $config{'post_range_2'}) and ($form{'BID'} < $config{'post_range_3'}));
#	$posting_charges = "$config{'post_fee_4'}" if (($form{'BID'} >= $config{'post_range_3'}) and ($form{'BID'} < $config{'post_range_4'}));
#	$posting_charges = "$config{'post_fee_5'}" if (($form{'BID'} >= $config{'post_range_4'}) and ($form{'BID'} < $config{'post_range_5'}));
#	$posting_charges = "$config{'post_fee_6'}" if ($form{'BID'} >= $config{'post_range_6'});
#	my $charges = &parsebid($counterfee + $grabberfee + $posting_charges + $boldfee + $featfee);		
#	my $charges = &parsebid($grabberfee + $posting_charges + $boldfee + $featfee);
#	if ($charges > 0) {
#	&debcredit($form{'ALIAS'}, "Posting, $item_number $B$F$BN$BF$TC", "$charges", "$config{'adminpass'}", "debit");
#	}		
####################################	

		&oops('We are unable to edit your item.  This could be a write permissions problem.') unless (open (NEW, ">$config{'basepath'}$form{'CATEGORY'}/$item_number.dat"));
#		print NEW "$form{'TITLE'}\n$form{'RESERVE'}\n$form{'INC'}\n$form{'DESC'}\n$form{'IMAGE'}\n$form{'COUNTER'}\n$form{'GRABBER'}\n$form{'CATFEAT'}\n$form{'BOLDITEM'}\n$form{'ALIAS'}\[\]$form{'EMAIL'}\[\]".&parsebid($form{'BID'})."\[\]$timenum\[\]$form{'ADDRESS1'}\[\]$form{'ADDRESS2'}\[\]$form{'ADDRESS3'}";
				my $delim = ":::";
				my $delim2 = " ";
				print NEW "$form{'TITLE'}$delim$form{'RESERVE'}$delim$form{'INC'}$delim$form{'CTR'}$delim$form{'GRAB'}$delim$form{'CATF'}$delim$form{'BOLD'}$delim$form{'BUY'}$delim2$delim$form{'AGAIN'}\n$form{'IMAGE'}\n$form{'DESC'}\n$form{'ALIAS'}\[\]$form{'EMAIL'}\[\]".&parsebid($form{'BID'})."\[\]$timenum\[\]$form{'ADDRESS1'}\[\]$form{'ADDRESS2'}\[\]$form{'ADDRESS3'}";

		close NEW;

# Added 7/21/02 to allow items to be moved to a new category when edited		
		if ($form{'CAT'} ne $form{'CATEGORY'}){
			print "Please notify the site admin that this item cannot be moved to the new category.\n" unless &movefile("$config{basepath}$form{'CAT'}/$item_number.dat", "$config{basepath}$form{'CATEGORY'}/$item_number.dat");		
		}
#		print "A successful edit!<br><B>$form{'TITLE'} was posted under $category{$form{'CATEGORY'}}...</B>.<BR>You may want to go to <A HREF=\"$ENV{'SCRIPT_NAME'}\?category=$form{'CATEGORY'}\&item=$item_number\">the item</A> to confirm your item was edited correctly.\n\n";
		
	if ($form{'DELETE'} eq "YES"){
	  unlink("$config{basepath}$form{'CAT'}/$item_number.dat");
####################################
# Replaced the above line with this section on 7/2/02 to make it a little more "pretty".
print "<HTML>";
print "<HEAD>";
print "<TITLE></TITLE>";
print "</HEAD>";
print "$config{'header'}";
print "$config{'navbar'}";
print "A successful auction cancellation!<br><B>Your auction for $form{'TITLE'} was cancelled from $category{$form{'CAT'}}...</B>.<BR>\n\n";
print "$config{'navbar'}";
print "$config{'footer'}";
print "</BODY>";
print "</HTML>";
######################################	  
	}else{		
####################################
# Replaced the above line with this section on 7/2/02 to make it a little more "pretty".
print "<HTML>";
print "<HEAD>";
print "<TITLE></TITLE>";
print "</HEAD>";
print "$config{'header'}";
print "$config{'navbar'}";
print "A successful edit!<br><B>$form{'TITLE'} was posted under $category{$form{'CATEGORY'}}...</B>.<BR>You may want to go to <A HREF=\"$ENV{'SCRIPT_NAME'}\?category=$form{'CATEGORY'}\&item=$item_number\">the item</A> to confirm your item was edited correctly.\n\n";
print "$config{'navbar'}";
print "$config{'footer'}";
print "</BODY>";
print "</HTML>";
######################################
}
		
	}
	else {
		my $nowtime = localtime(time);
		my $closetime = localtime($item_number);
####################################
# Fees for auctions go here
#	my $counterfee;
#	if ( $form{'COUNTER'} ne "N" ) {
#		$counterfee = &parsebid($config{'count_amount'});
#				if (!(-f "$config{'basepath'}$config{'counterpath'}/$form{'item'}.dat")) {
#					&oops('We were unable to write to the counter directory.') unless (open NEWBILL, ">$config{'basepath'}$config{'counterpath'}/$form{'item'}.dat");
#					print NEWBILL "0";
#					close NEWBILL;
#				}
#		# &apply_transaction($form{'ALIAS'}, "Attention Grabber Image Fee for #$form{'ITEM'}", "$config{'grabbercharge'}", "Attention Grabber - $form{'TITLE'}", 1, 1, 1, 0);
#	}else{
#		$counterfee = "0.00";
#	}
#	
#	my $grabberfee;
#	if ( $form{'GRABBER'} ne "none" ) {
#		$grabberfee = &parsebid($config{'grabbercharge'});
#		# &apply_transaction($form{'ALIAS'}, "Attention Grabber Image Fee for #$form{'ITEM'}", "$config{'grabbercharge'}", "Attention Grabber - $form{'TITLE'}", 1, 1, 1, 0);
#	}else{
#		$grabberfee = "0.00";
#	}
#	
#	my $fee;
#	if ($config{'post_amount'} > 0) {
#		$fee = &parsebid($config{'post_amount'});
#	}else{
#		$fee = "0.00";
#	}
#	
#	my $boldfee;
#	my $B;
#	if ($form{'BOLDITEM'} eq "1") {
# 		$boldfee = &parsebid($config{'bold_amount'});
#		$B = "<font color=red><b> B </b></font>";
#	}else {
# 		$boldfee = "0.00";
#		$B = "";
#	}
#	
#	my $featfee;
#	my $F;
#	if ($form{'CATFEAT'} eq "CATFEATYES") {
# 		$featfee = &parsebid($config{'feat_amount'});
#		$F = "<font color=green><b> F </b></font>";
#	}else{
# 		$featfee = "";
#		$F = "";
#	}
#	
#	my $buyitfee;
#	my $BN;
#	if ($form{'BUYITNOW'} eq "1") {
# 	$buyitfee = &parsebid($config{'buyit_amount'});
#	$BN = "<font color=navy><b> BN </b></font>";
#	}else{
# 	$buyitfee = "";
#	$BN = "";
#	}
#	my $bannerfee;
#	my $BF;
#	if ($form{'BANNERIMAGEURL'} ne "") {
# 	$bannerfee = &parsebid($config{'banner_amount'});
#	$BF = "<font color=maroon><b> BF </b></font>";
#	}else{
# 	$bannerfee = "";
#	$BF = "";
#	}
#	my $twocatfee;
#	my $TC;
#	if ($form{'CATEGORY2'}) {
# 	$bannerfee = &parsebid($config{'two_cat_fee'});
#	$TC = "<font color=#800080><b> TC </b></font>";
#	}else{
# 	$twocatfee = "";
#	$TC = "";
#	}
#	my $posting_charges;
#	$posting_charges = "$config{'post_fee_1'}" if ($form{'BID'} < $config{'post_range_1'});
#	$posting_charges = "$config{'post_fee_2'}" if (($form{'BID'} >= $config{'post_range_1'}) and ($form{'BID'} < $config{'post_range_2'}));
#	$posting_charges = "$config{'post_fee_3'}" if (($form{'BID'} >= $config{'post_range_2'}) and ($form{'BID'} < $config{'post_range_3'}));
#	$posting_charges = "$config{'post_fee_4'}" if (($form{'BID'} >= $config{'post_range_3'}) and ($form{'BID'} < $config{'post_range_4'}));
#	$posting_charges = "$config{'post_fee_5'}" if (($form{'BID'} >= $config{'post_range_4'}) and ($form{'BID'} < $config{'post_range_5'}));
#	$posting_charges = "$config{'post_fee_6'}" if ($form{'BID'} >= $config{'post_range_6'});
#	my $charges = &parsebid($counterfee + $grabberfee + $posting_charges + $boldfee + $featfee);		
#	my $charges = &parsebid($grabberfee + $posting_charges + $boldfee + $featfee);		
		print "<HTML>";
		print "<HEAD>";
		print "<TITLE></TITLE>";
		print "</HEAD>";
		print "$config{'header'}";
		print "$config{'navbar'}";		
		print "<H2>$form{'TITLE'} PREVIEW</H2><HR><FONT SIZE=+1><B>Information</B></FONT><HR>\n";
		print "<TABLE WIDTH=100\%><TR>";
		print "<TD BGCOLOR=$config{'colortablebody'}><IMG SRC=$form{'IMAGE'}></TD>" if ($form{'IMAGE'});
		print "<TD><TABLE BORDER=1><TR><TD BGCOLOR=$config{'colortablehead'}><B>$form{'TITLE'}</B></TD></TR>\n";
		print "<TR><TD BGCOLOR=$config{'colortablebody'}><B>Category:</B> <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'CATEGORY'}>$category{$form{'CATEGORY'}}</A></TD></TR>\n";
		print "<TR><TD BGCOLOR=$config{'colortablebody'}><B>Offered By:</B> <A HREF=mailto:$form{'EMAIL'}>$form{'ALIAS'}</A></TD></TR>\n";
		print "<TR><TD BGCOLOR=$config{'colortablebody'}><B>Current Time:</B> $nowtime</TD></TR>\n";
		print "<TR><TD BGCOLOR=$config{'colortablebody'}><B>Closes:</B> $closetime<BR><FONT SIZE=-2>Or $config{'aftermin'} minutes after last bid...</FONT></TD></TR>\n";
#		print "<TR><TD BGCOLOR=$config{'colortablebody'}><B>Total Fees Charged:</B> $config{'pre_curr'}$charges</TD></TR>\n";
		print "<TR><TD BGCOLOR=$config{'colortablebody'}><B>Number of Bids:</B> 0</TD></TR>\n";
		print "<TR><TD BGCOLOR=$config{'colortablebody'}><B>Last Bid:</B> \$$form{'BID'}</TD></TR>\n";
		if ($form{'DELETE'} eq "YES"){
		  print "<TR><TD BGCOLOR=$config{'colortablebody'}><FONT color=red><B>YOUR AUCTION IS BEING CANCELLED</B></FONT></TD></TR></TABLE>\n";
		}else{
		  print "</TABLE>\n";
		}
		print "<HR><FONT SIZE=+1><B>Description</B></FONT><HR>$form{'DESC'}</FONT></FONT></B></I></U></H1></H2></H3></H4></H5>";
		if ($form{'DELETE'} eq "YES"){
		  print "<HR><B><FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>If this looks good, hit <INPUT TYPE=SUBMIT VALUE=\"Cancel Auction\">, else hit the back button on your browser to edit the item.<INPUT TYPE=HIDDEN NAME=FROMPREVIEW VALUE=1></B>\n";
		}else{
		  print "<HR><B><FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>If this looks good, hit <INPUT TYPE=SUBMIT VALUE=\"Post Item\">, else hit the back button on your browser to edit the item.<INPUT TYPE=HIDDEN NAME=FROMPREVIEW VALUE=1></B>\n";
		}
#		print "Old Cat: $config{basepath}$form{'CAT'}/$item_number.dat  New Cat: $config{basepath}$form{'CATEGORY'}/$item_number.dat\n";
		my $key;
		foreach $key (keys %form) {
			$form{$key} =~ s/\>/\[greaterthansign\]/gs;
			$form{$key} =~ s/\</\[lessthansign\]/gs;
			$form{$key} =~ s/\"/\[quotes\]/gs;
			print "<INPUT TYPE=hidden NAME=\"$key\" VALUE=\"$form{$key}\">\n";
		}
		print "</FORM>\n";
		print "$config{'navbar'}";
		print "$config{'footer'}";
		print "</BODY>";
		print "</HTML>";
	}

#-#############################################
# Sub: Movefile(file1, file2)
# This moves a file.  Quick and dirty!

sub movefile {
	my ($firstfile, $secondfile) = @_;
	print "Failed to open first file" unless open(FIRSTFILE,$firstfile);
	my @lines=<FIRSTFILE>;
	close FIRSTFILE;
	print "Failed to open second file" unless open(SECONDFILE,">$secondfile");
	my $line;
	foreach $line (@lines) {
		print SECONDFILE $line;
	}
	close SECONDFILE;
	print "Failed to unlink first file" unless unlink($firstfile);
	return 1;
}
