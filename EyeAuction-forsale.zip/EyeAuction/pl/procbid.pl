use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Process Bid
# This processes new bids from a posted form


my ($iteminfo, $image, $desc, @bids) = &read_item_file($form{'CATEGORY'},$form{'ITEM'}); # Info on Item
my @itemvals = split(/:::/, $iteminfo);
my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[0]);      # Info on Poster
my (@lastbid, @firstbid);
&oops('You cannot bid on items you posted.') if ((lc $form{'ALIAS'}) eq (lc $alias));                 # Same Person?

	require "sendemail.pl";
	my ($password, @userbids);
	if ($config{'regdir'} ne "") {
		&oops('Your alias could not be found!') unless ($password, $form{'EMAIL'}, $form{'ADDRESS1'}, $form{'ADDRESS2'}, $form{'ADDRESS3'}, @userbids) = &read_reg_file($form{'ALIAS'});
		$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
		&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	}
	&oops('You must enter an alias to track your item.') unless ($form{'ALIAS'});
	&oops('You must enter a valid e-mail address.') unless ($form{'EMAIL'} =~ /^.+\@.+\..+$/);
	&oops('You must enter a valid bid amount.') unless ($form{'BID'} =~ /^(\d+\.?\d*|\.\d+)$/);
	$form{'BID'} = &parsebid($form{'BID'});
	&oops('You must enter your full name.') unless ($form{'ADDRESS1'});
	&oops('You must enter your street address.') unless ($form{'ADDRESS2'});
	&oops('You must enter you city, state, and zip.') unless ($form{'ADDRESS3'});
	&oops('The item number you entered cannot be found.  Maybe it has closed or it was moved since you last loaded the page.') unless my ($iteminfo, $image, $desc, @bids) = &read_item_file($form{'CATEGORY'},$form{'ITEM'});
	my ($selleralias, $selleremail, $sellerbid, $sellertime, $selleradd1, $selleradd2, $selleradd3) = &read_bid($bids[0]);
	&oops('You cannot bid on your own item!') if ($selleralias eq $form{'ALIAS'});
	my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
	@firstbid = split(/\[\]/,$bids[0]);
  @lastbid = split(/\[\]/,$bids[$#bids]);
	#=======================BEGIN OF AUTOBIDDER 2=======================#
	if ((time <= $form{'ITEM'}) or (time <= (60 * $config{'aftermin'} + $time))) {
		if(($form{BID} < $bid + $itemvals[2] && $#bids) || $form{BID} < $bid){
			&oops("<br>Your bid is too low. Sorry...<table><tr><td></table><a href=$ENV{SCRIPT_NAME}?category=$form{CATEGORY}&item=$form{ITEM}&refr=$^T><b>Go Back to the Item</b></a><p>");
		}

		# Uncomment to disallow $0.00 bids, the normal(though wrong) behavior.
		#&oops('Your bid cannot be 0.00') if $form{BID} == 0;

		my @autobid = &read_bid($bids[-1]);
		my $changed = 0;
		# Change Option
		if($#bids && lc $autobid[0] eq lc $form{ALIAS}){
			&oops('Cannot update bidhistory.') unless open DAT, "$config{basepath}$form{CATEGORY}/$form{ITEM}.dat";
			my @old = <DAT>;
			pop @old; # Delete last bid
			chomp $old[-1]; # Crop LF
			close(DAT);
			&oops('Cannot update bidhistory.') unless open DAT, ">$config{basepath}$form{CATEGORY}/$form{ITEM}.dat";
			eval { flock(DAT, 2); } if $config{flock};
			print DAT @old;
			close(DAT);
			($iteminfo, $image, $desc, @bids) = read_item_file($form{CATEGORY}, $form{ITEM});
			($alias, $email, $bid, $time, $add1, $add2, $add3) = read_bid($bids[-1]); 
			$changed = 1;
		}
		# Change Option

		&oops('Cannot update bidhistory.') unless open NEW, ">>$config{basepath}$form{CATEGORY}/$form{ITEM}.dat";
		eval { flock(NEW, 2); } if $config{flock};
		
		print $config{'header'};
		
		## The Bidder And The Autobidder:
		my $mybidder = sub {print NEW "\n$form{ALIAS}\[]$form{EMAIL}\[]$_[0]\[]$_[1]\[]$form{ADDRESS1}\[]$form{ADDRESS2}\[]$form{ADDRESS3}"};
		my $autobidder = sub { my (@this) = @autobid; ($this[2], $this[3]) = ($_[0], $_[1]); print NEW "\n", join("[]", @this)};
		## Now The Bids:
		$form{MAXBID} = &parsebid($form{BID});
		if ($form{PROXYBUTTON} ne '' || $form{PROXYCHECKED}==1){
			$form{BID} = &parsebid($bid);
			$form{BID} = &parsebid($bid + $itemvals[2]) if ($#bids);
		}
		my $proxy = ($time =~ /\d*\#(\-?\d*\.?\d*)/ ? parsebid($1*1) : -1);
		my $message;
		## BID WAS IMMEDIATELY BEATEN SO RETURN WITHOUT EMAIL
		if($proxy >= $form{MAXBID} && $#bids >= 0){
			$form{BID} = &parsebid($form{MAXBID});
			&$mybidder($form{MAXBID}, "$^T#$form{MAXBID}#beaten");
			&$autobidder($form{MAXBID}, "$^T#$proxy#");
			$message = "Your bid was beaten by a proxy bid.<br><big><b>You are not the high bidder!</b></big>";
		## BID WAS IMMEDIATELY BEATEN BUT SUCCESSFULLY REBID
		}elsif($proxy >= $form{BID} && $#bids >= 0){ ##(add-on remark: If rebid is necessary the reserve price is allways lower than the high bid because there cannot be a hidden proxybid if reserve is not matched. Proxbids are allways raised to the maximum if reserve price is not matched. So we needn't care about this here.)
			&$mybidder($form{BID}, "$^T#$form{MAXBID}#beaten");
			&$autobidder($proxy, "$^T#$proxy#beaten");
			$form{BID} = &parsebid((($proxy + $itemvals[2]) > $form{MAXBID}) ? ($form{MAXBID}) : ($proxy + $itemvals[2]));
			&$mybidder($form{BID}, "$^T#$form{MAXBID}#");
			$message = "Your bid has been raised to $form{BID} in order to outbid an old proxy bid";
		## BID WAS NOT BEATEN
		}else{
			## RAISED TO RESERVE PRICE BUT RESERVE WAS TOO HIGH
			if($itemvals[1] > $form{MAXBID} && $form{MAXBID} > $form{BID}){
				$form{BID} = &parsebid($form{MAXBID});
				&$mybidder($form{BID}, "$^T#$form{MAXBID}#");
				$message = "Your bid has been raised to \$$form{BID} in order to meet the reserve price.<br>The reserve price is not yet met.";
			## SUCCESSFULLY RAISED TO RESERVE PRICE
			}elsif($itemvals[1] > $form{BID} && $form{MAXBID} > $form{BID}){
				$form{BID} = $itemvals[1];
				&$mybidder($form{BID}, "$^T#$form{MAXBID}#");
				$message = "Your bid has been raised in order to meet the reserve price.<br>The reserve price was \$$itemvals[1].";
			## BID JUST REGULARLY
			}else{
				&$mybidder($form{BID}, "$^T#$form{MAXBID}#")
			}
		}
		
		$message .= "<br>The proxy will automatically bid for you until \$@{[parsebid($form{MAXBID})]}" if ($form{BID} < $form{MAXBID});
		$message = "<p><b>Note:</b><br>$message</p>" if $message;
		my $nowtime = localtime(time);
		close NEW;

		my $nowtime = localtime(time);
		if($changed){
			print "$form{ALIAS}, your bid on item number $form{ITEM} has been changed to \$$form{BID}.$message<p>You may want to print this notice as confirmation of your bid.<p>Go <a href=\"$ENV{SCRIPT_NAME}?category=$form{CATEGORY}&item=$form{ITEM}\">back to the item</a></p>";
		}else{
			print "$form{ALIAS}, your bid has been placed on item number $form{ITEM} for \$$form{BID} on $nowtime$message<p>You may want to print this notice as confirmation of your bid.<p>Go <a href=\"$ENV{SCRIPT_NAME}?category=$form{CATEGORY}&item=$form{ITEM}\">back to the item</a></p>";
		}
		
		print $config{'footer'};
		
		return if $changed || $proxy >= $form{MAXBID};
		$config{scripturl} = $ENV{HTTP_HOST} if $config{scripturl} eq '' || $config{scripturl} =~ /your\.host/;
		my $ends = localtime int $form{ITEM};
		sendemail($email, $config{admin_address}, "Outbid Notice", <<EOF) if $config{scripturl} && $#bids;
*** DO NOT REPLY TO THIS AUTOMATED MESSAGE. ***

\u$alias, you have been outbid on item #$form{ITEM}!

   Item Title: $itemvals[0]
   Current High Bid: \$$form{BID}

If you want to place a higher bid, please visit the following URL:
http://$config{scripturl}$ENV{SCRIPT_NAME}?category=$form{CATEGORY}&item=$form{ITEM}

Bids may be placed until $ends.

Thanks for using $config{sitename}
EOF
	}
	#=========================END OF AUTOBIDDER 2=======================#

	else {
		print "Item number $form{'ITEM'} in category $form{'CATEGORY'} is now closed!<BR>Sorry...\n";
	}
1;
