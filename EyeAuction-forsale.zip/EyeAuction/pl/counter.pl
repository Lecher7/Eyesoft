#!c:\Perl\bin\perl
# use vars qw(%config %form);
use strict;

sub counter {
### read the hits counter file
    
	my (@ct) = &read_ct_file($form{'item'});
	my $counts =  @ct[0];

### increment the hits counter file    
	$counts++;

	&oops('We were unable to increment the counter.') unless (open NEWCOUNT, ">$config{'basepath'}$config{'counterpath'}/$form{'item'}.dat");
	print NEWCOUNT "$counts";
	close NEWCOUNT;

	return "$counts";

}
 
#-#############################################
sub read_ct_file {
	open FILE, "$config{'basepath'}$config{'counterpath'}/$form{'item'}.dat";
	my (@ct) = <FILE>;
	close FILE;
	chomp (@ct);
	return (@ct);
}
#############################################
