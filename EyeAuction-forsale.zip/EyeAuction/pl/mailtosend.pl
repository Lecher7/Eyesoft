use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
# 
#------------------------------------------------------#
# Mail Auction To A Friend
# This does the actual mailing of the auction
#------------------------------------------------------#

	require "sendemail.pl";
	my ($password, $email, $addr1, $addr2, $addr3, @bids);
    $form{'ALIAS'} =~ s/\W//g;
    $form{'ALIAS'} = lc($form{'ALIAS'});
    $form{'ALIAS'} = ucfirst($form{'ALIAS'});
	if ($config{'regdir'} ne "") {
		&oops('Your alias could not be found!') unless ($password, $email, $addr1, $addr2, $addr3, @bids) = &read_reg_file($form{'ALIAS'});
		$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
		&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	}
	&oops('The item cannot be found.  Maybe it has closed or it was moved since you last loaded the page.') unless my ($iteminfo, $image, $desc, @bids) = &read_item_file($form{'CATEGORY'},$form{'ITEM'});
	my @itemvals = split(/:::/, $iteminfo);
	my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);

my $mailto = "
 Hello,

 A user at $config{'sitename'}, $form{'ALIAS'}, has forwarded
 this auction to you:

 $form{'MESSAGE'}

 The item information posted is as follows :

   Item number :  $form{'ITEM'}
   Item Title  :  $itemvals[0]
   Current Bid :  \$$form{'BID'}
   URL Here    :  http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?$form{'CATEGORY'}\&$form{'ITEM'}
   Description :  $desc

 Thank you and please tell a friend about us!
 Sincerely,
 $config{'sitename'}
";

		#&sendemail($form{'EMAILADD'}, 'Fwd: Auction Item', $config{'admin_address'}, $mailto);
            #This should fix the above line
            &sendemail($form{'EMAILADD'}, $config{'admin_address'}, 'Fwd: Auction Item', $mailto); 
    print	&load_template ('mailtosend.html', { 
       BID  		=>    $bid,        
	   EMAILADD		=>	  $form{'EMAILADD'},
	   CATTREE		=>	  $form{'CATEGORY'},
       ITEMNUM  	=>    $form{'ITEM'},        
       ITEMTITLE  	=>    $itemvals[0],        
				%globals
	});      

1;