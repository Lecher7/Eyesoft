use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Admin
# Allows the administrator to delete items.
# Use this format after the script name: ?action=admin&password=


	my ($key, $category_list);
	foreach $key (sort keys %category) {
		$category_list .= "<OPTION VALUE=\"$key\">$category{$key}</OPTION>\n";
	}

    print	&load_template ('adminform.html', { 
       CATEGORIES  =>    $category_list,
			%globals
	});  
1;      
