use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
# 
#-#############################################
# Display List Of Items
# This creates a "nice" list of items in a
# category.
	my $subcatarray = &subcats;
	opendir THEDIR, "$config{'basepath'}$form{'category'}" or &oops("Category directory $form{'category'} could not be opened.");
	my @allfiles = grep -T, map "$config{'basepath'}$form{'category'}/$_", sort { int($a) <=> int($b) } (readdir THEDIR);
	closedir THEDIR;
	my ($file, $listtable);
	my @cellcolor=($config{'colortablerowodd'},$config{'colortableroweven'});
	my $color = 0;
	foreach $file (@allfiles) {
		$file =~ s/^$config{'basepath'}$form{'category'}\///;
		$file =~ s/\.dat$//;
		if ($file < (time + 86400)) {
			if (my ($iteminfo, $image, $desc, @bids) = &read_item_file($form{'category'},$file)) {
			  my @itemvals = split(/:::/, $iteminfo);
				my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
				my ($selleralias, $selleremail, $sellerbid, $sellertime, $selleradd1, $selleradd2, $selleradd3) = &read_bid($bids[0]);
				my @closetime = localtime($file);
				my $boldon ="";
				my $boldoff ="";				
				$closetime[4]++;
				my $rowcolor = $cellcolor[$color];
				my $timeleft = &timeleft($file);
				my $grabberpic ="";
				$grabberpic .= "$config{'siren'}" if ($itemvals[4] eq 'siren');
				$grabberpic .= "$config{'eyes'}" if ($itemvals[4] eq 'eyes');
				$grabberpic .= "$config{'hand'}" if ($itemvals[4] eq 'hand');
				$grabberpic .= "$config{'arrowred'}" if ($itemvals[4] eq 'arrow_red');
				$grabberpic .= "$config{'box'}" if ($itemvals[4] eq 'box');
				$grabberpic .= "$config{'cdrom'}" if ($itemvals[4] eq 'cdrom');
				$grabberpic .= "$config{'click'}" if ($itemvals[4] eq 'click');
				$grabberpic .= "$config{'clock'}" if ($itemvals[4] eq 'clock');
				$grabberpic .= "$config{'cool1'}" if ($itemvals[4] eq 'cool1');
				$grabberpic .= "$config{'hot1'}" if ($itemvals[4] eq 'hot1');
				$grabberpic .= "$config{'dot'}" if ($itemvals[4] eq 'dot');
				$grabberpic .= "$config{'star'}" if ($itemvals[4] eq 'star');	
				$boldon .= "<b>" if ($itemvals[6] eq '1');
				$boldoff .= "</b>" if ($itemvals[6] eq '1');						
				$listtable .= "<TR><TD width=35 BGCOLOR=$rowcolor ALIGN=LEFT>$grabberpic&nbsp;</td><TD BGCOLOR=$rowcolor ALIGN=LEFT>$boldon<A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}\&item=$file>$itemvals[0]</A>";
				$listtable .= "$config{'pic'}" if ($image);
				$listtable .= "$config{'new'}" if (($sellertime + (86400 * $config{'newdays'})) > time);
				$listtable .= "$config{'hot'}" if ($#bids >= $config{'hotnum'});
				$listtable .= "$boldoff</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>\$$bid</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$#bids</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$timeleft</TD></TR>\n";
				$color = int(!($color));
			}
		}
	}
	if (!@allfiles){
		$listtable = "<TR><td></td><TD>No Listings in this Category</TD><TD></TD><TD></TD><TD></TD></TR>";
	}
	my $listbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1><A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=current&level=$form{'level'}>Current</A> |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=new&level=$form{'level'}>New Today</A> |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=hot&level=$form{'level'}>Hot</A> |";
	$listbar .= "| Closing Today |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=closed&level=$form{'level'}>Completed</A> |";
	$listbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?category=$form{'category'}&listtype=going&level=$form{'level'}>Going, Going, Gone</A>";
	$listbar .= "</FONT></P>\n";

    print	&load_template ('displist.html', { 
				LISTBAR		=>	$listbar,
				SUBCATARRAY	=>	$subcatarray,
				THISCAT 	=> 	"Top:$category{$form{'category'}}",
				LISTTABLE 	=> 	$listtable,
				%globals
	}); 
#-#############################################
# Sub: SubCats
# Makes a table of subcategories with stats
#
sub subcats {
	my (@subcats, @catarray, $nextlevel, $output, %stats, %cattree, $key, $file);
	$nextlevel = $form{'level'} + 1;
	foreach $key (sort keys %category) {
		umask(000);  # UNIX file permission junk
		mkdir("$config{'basepath'}$key", 0777) unless (-d "$config{'basepath'}$key");
		@catarray = split (/\//,$key);
		if ($catarray[$nextlevel] && ($catarray[$form{'level'}] eq $form{'category'})){
			$cattree{$catarray[$nextlevel]} = $key; 
			push (@subcats, $catarray[$nextlevel]);
			opendir DIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");       
	        my @files = grep -T, map "$config{'basepath'}$key/$_", readdir DIR;
			foreach $file (@files) {
				$file =~ s/^$config{'basepath'}$key\///;
				$file =~ s/\.dat$//;
				if ($file < (time + 86400)) {
					$stats{$catarray[$nextlevel]}++;
				}
			}
			$stats{$catarray[$nextlevel]} = 0 unless ($stats{$catarray[$nextlevel]});
			closedir DIR;
		}
	}
	if (@subcats){
		$output = qq|<div><table width="80%" border="$config{'tableborder0'}" cellspacing="$config{'tablecellspace0'}" cellpadding="$config{'tablecellpad0'}"><tr><td valign="top">\n|;
		my $i = 0;
		my $cat;
		my $catclean;
################################
#		Removed this section 6/16/02 and fixed it so to create multiple columns.
#		To change the number of columns, change the variable called "half"
#
#		my $half = int (($#subcats+1) / 2);
#    	foreach $cat (sort @subcats) { 
#			$catclean = $cat;
#			$catclean =~ s/_/ /g;
#        	if ($i == $half) {
#        			$i=0;
#            	$output .= qq|</td><td valign="top">\n|;
#        	}
#        	$i++;
#        	$output .= qq|<dl><dt><strong><a href="$ENV{'SCRIPT_NAME'}\?category=$cattree{$cat}&level=$nextlevel&listtype=current">$catclean</a></strong> <small>($stats{$cat})</small></dt></dl> |;
#		}
		my $half = int (($#subcats+1) / 2);
    	foreach $cat (sort @subcats) { 
			$catclean = $cat;
			$catclean =~ s/_/ /g;
        	if ($i == $half) {
        			$i=0;
            	$output .= qq|</td></tr><tr><td valign="top">\n|;
        	}
        	$i++;
        	$output .= qq|<dl><dt><strong><a href="$ENV{'SCRIPT_NAME'}\?category=$cattree{$cat}&level=$nextlevel&listtype=closingtoday">$catclean</a></strong> <small>($stats{$cat})</small></dt></dl></td><td> |;
		}		
    	$output .= "</td></tr></table></div>\n";
	}
    return $output;
}

#-#############################################
# Sub: Movefile(file1, file2)
# This moves a file.  Quick and dirty!

sub movefile {
	my ($firstfile, $secondfile) = @_;
	return 0 unless open(FIRSTFILE,$firstfile);
	my @lines=<FIRSTFILE>;
	close FIRSTFILE;
	return 0 unless open(SECONDFILE,">$secondfile");
	my $line;
	foreach $line (@lines) {
		print SECONDFILE $line;
	}
	close SECONDFILE;
	return 0 unless unlink($firstfile);
	return 1;
}
#-#############################################
# Sub: time left
# revised w/ proper english - smarter output
# Note: This sub does not handle the year change properly, yet.
# Also may not handle leap years. Fixes are welcome.

sub timeleft {

 my ($rsecond, $rminute, $rhour, $rday, $timeremain, $adddays);
 my ($second, $minute, $hour, $dayofmonth, $month, $year, $weekday, $dayofyear, $iddst) = localtime($_[0]); 
 my ($csecond, $cminute, $chour, $cdayofmonth, $cmonth, $cyear, $cweekday, $cdayofyear, $ciddst) = localtime(time); 
if (($cyear % 4) == 0) { 
$adddays = 366; 
} 
else { 
$adddays = 365; 
} 
if ($cyear != $year) { 
$dayofyear = ($dayofyear + $adddays); 
} 

  if ($second >= $csecond) { $rsecond = ($second - $csecond); }
  else { $rsecond = (($second + 60) - $csecond);
         $minute = ($minute - 1); }

  if ($minute >= $cminute) { $rminute = ($minute - $cminute); }
  else { $rminute = (($minute + 60) - $cminute);
         $hour = ($hour - 1); }

  if ($hour >= $chour) { $rhour = ($hour - $chour); }
  else { $rhour = (($hour + 24) - $chour);
         $dayofyear = ($dayofyear - 1); }

    if ($dayofyear == $cdayofyear) {
     if($rhour < 1) {
      if($rminute < 1) {
       if ($rminute = 0) { $timeremain = "<font color=red> auction has ended</font>"; }
       else { 
         $timeremain = sprintf('%02d seconds', $rsecond);
         my @s = split / /, $timeremain;
         if ($s[0] eq "01") {$s[1] = "second";}
         $timeremain = "<font color=red> " . "$s[0] $s[1]"; }}

      else {
       $timeremain = sprintf('%02d minutes %02d seconds', $rminute, $rsecond);
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "minute";}
       if ($s[2] eq "01") {$s[3] = "second";}
       $timeremain = "<font color=red> " . "$s[0] $s[1] $s[2] $s[3]"; }}

     else {
       $timeremain = sprintf('%02d hours %02d minutes', $rhour, $rminute); 
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "hour";}
       if ($s[2] eq "01") {$s[3] = "minute";}
       $timeremain = "<font color=red> " . "$s[0] $s[1] $s[2] $s[3]"; }}

    else {
     $rday = ($dayofyear - $cdayofyear);
 
     if ($rday <= -1) { $timeremain = "<font color=red> auction has ended</font>"; }
     else {
       $timeremain = sprintf('%02d days %02d hours +', $rday, $rhour);
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "day";}
       if ($s[2] eq "01") {$s[3] = "hour";}
       if ($s[2] eq "00") {($s[3], $s[2], $s[4]) = (" 1 hour","\<","");}
       $timeremain = "$s[0] $s[1] $s[2] $s[3] $s[4]"; }
     }
  return "$timeremain";
}    
1;
