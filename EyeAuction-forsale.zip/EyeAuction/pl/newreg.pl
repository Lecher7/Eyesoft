use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# New Registration
# This creates a form for registration

    print	&load_template ('newreg.html', { 
				TITLE	=>	"New Registration",
				AFFIL    => $form{'affiliate'},
				%globals
	});      

1;