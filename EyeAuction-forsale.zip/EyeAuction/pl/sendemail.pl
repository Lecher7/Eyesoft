use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Send E-mail
# This is a real quick-and-dirty mailer that
# should work on any platform.  It is my first
# attempt to work with sockets, so if anyone
# has any suggestions, let me know!
#
# Takes:
# (To, From, Subject, Message)
#-#############################################
# SUB: Send E-mail
# This is a real quick-and-dirty mailer that
# should work on any platform.  It is my first
# attempt to work with sockets, so if anyone
# has any suggestions, let me know!
#
# Takes:
# (To, Subject, From, Message)

sub sendemail {
        my ($to,$from,$subject,$message) = @_;
        my $trash;
        if ($config{'mailhost'}) {
		eval('use IO::Socket; 1;') or &oops("IO::Socket could not be loaded by the script.  Please see the script documentation for details.  It looks like this server is using perl version $].  IO::Socket may not be included with versions of perl prior to 5.00404."); # don't cause errors on machines where IO::Socket is not available
                my $remote;
                $remote = IO::Socket::INET->new("$config{'mailhost'}:smtp(25)");
                $remote->autoflush();
                print $remote "HELO\r\n";
                $trash = <$remote>;
                print $remote "MAIL From:<$config{'admin_address'}>\r\n";
                $trash = <$remote>;
                print $remote "RCPT To:<$to>\r\n";
                $trash = <$remote>;
                print $remote "DATA\r\n";
                $trash = <$remote>;
                print $remote "From: <$from>\r\nSubject: $subject\r\n\r\n";
                print $remote $message;
                print $remote "\r\n.\r\n";
                $trash = <$remote>;
                print $remote "QUIT\r\n";
        }
        else {
                open MAIL, "|$config{'mailprog'}";
                print MAIL "To: $to\r\nFrom: $from\r\nSubject: $subject\r\n\r\n$message\r\n\r\n";
                close MAIL;
        }
}

###############################################
#sub sendemail {
#        my ($to,$from,$subject,$message) = @_;
#        my $trash;
#        if ($config{'mailhost'}) {
#		eval('use IO::Socket 1;') or &oops("IO::Socket could not be loaded by the script.  Please see the script documentation for details.  It looks likethis server is using perl version $].  IO::Socket may not be included with versions of perl prior to 5.004_04."); # don't cause errors on machines where IO::Socket is not available
#                my $remote;
#                $remote = IO::Socket::INET->new("$config{'mailhost'}:smtp(25)");
#                $remote->autoflush();
#                print $remote "HELO\r\n";
#                $trash = <$remote>;
#                print $remote "MAIL From:<$config{'admin_address'}>\r\n";
#                $trash = <$remote>;
#                print $remote "RCPT To:<$to>\r\n";
#                $trash = <$remote>;
#                print $remote "DATA\r\n";
#                $trash = <$remote>;
#                print $remote "From: <$from>\r\nSubject: $subject\r\n\r\n";
#                print $remote $message;
#                print $remote "\r\n.\r\n";
#                $trash = <$remote>;
#                print $remote "QUIT\r\n";
#        }
#        else {
#                open MAIL, "|$config{'mailprog'} -t";
#                print MAIL "To: $to\n";
#				print MAIL "From: $from\n";
#				print MAIL "Subject: $subject\n";
#				print MAIL "Reply-To: $from\n\n";
#				print MAIL "$message\n\n";
#                close MAIL;
#        }
#}
1;
