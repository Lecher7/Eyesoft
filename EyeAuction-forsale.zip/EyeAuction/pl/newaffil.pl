use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# New Registration
# This creates a form for registration


    print	&load_template ('newaffil.html', { 
				TITLE	=>	"New Affiliate",
				%globals
	});      

1;