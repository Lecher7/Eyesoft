
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
##############################################################################
# 		NOTHING BELOW THIS LINE SHOULD NEED TO BE EDITED/CONFIGURED!    	 #
##############################################################################
use CGI::Carp qw(fatalsToBrowser);

require "common.cgi";
require "cookie.lib";

&get_input;
&get_template;
if (&GetCookies('Custom-CGI_pass','Custom-CGI_id')){
	&logged_in;
	exit;
} else {
	&not_logged_in;
	exit;
}


sub logged_in {



	print "Content-type: text/html\n\n";
	if ($in{'page'} eq "" || $in{'page'} =~ s/[^a-z0-9\_\-\.]//g) {
		print $header;	
		print "<h1>Error</h1>\n";
		print "Sorry <b>$Cookies{'Custom-CGI_id'}</b> but you  can't do that, please return, \n";
		print "<a href=\"javascript:history.go(-1)\">here</a></a>\n";
		print $footer;
		exit;
	}
	
	if (-e "$base_protected_dir/$in{'page'}"){
	
		open (FILE,"$base_protected_dir/$in{'page'}") || print "Unable to open the file";
		while (<FILE>)
		{
			print $_;
		}
		close (FILE);
	
	} else {
		print $header;
		print "<h1>404 Erro</h1>\n";
		print "You are looking for the page <b>$in{'page'}</b> but it\n";
		print "does not seem to exist. Please make sure you have the correct address.\n";
		print $footer;
		exit;
	}
}

sub not_logged_in {
	print "Content-type: text/html\n\n";
	print $header;
	print "Sorry, but you are not logged in, you must \n";
	print "<a href=\"$weburl\">login</a> before you can view this page\n";
	print $footer;
	exit;
}





