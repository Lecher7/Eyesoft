use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#------------------------------------------------------#
# Ask Seller a Question
# This does the actual mailing
#------------------------------------------------------#

	require "sendemail.pl";
	my ($password, $email, $addr1, $addr2, $addr3, @bids);
    $form{'SELLER'} =~ s/\W//g;
    $form{'SELLER'} = lc($form{'SELLER'});
    $form{'SELLER'} = ucfirst($form{'SELLER'});
    $form{'ALIAS2'} =~ s/\W//g;
    $form{'ALIAS2'} = lc($form{'ALIAS2'});
    $form{'ALIAS2'} = ucfirst($form{'ALIAS2'});
	&oops('You must enter your alias so we can validate your account.') unless ($form{'ALIAS2'});
	&oops('You must enter your password so we can validate your account.') unless ($form{'PASSWORD'});
	&oops('Your alias could not be found!') unless ($password, $email, $addr1, $addr2, $addr3, @bids) = &read_reg_file($form{'ALIAS2'});
      $form{'email2'}=$email;
	&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	&oops('The seller is not a valid user!') unless ($password, $email, $addr1, $addr2, $addr3, @bids) = &read_reg_file($form{'SELLER'});
my $mailto = "
 Hello,

 A user at $config{'sitename'}:

 User: $form{'ALIAS2'}
 Email: $form{'email2'}

 has asked this question:

 $form{'MESSAGE'}

 The item information posted is as follows :

   Item number :  $form{'ITEMNUM'}
   URL Here    :  http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?category=$form{'CATTREE'}\&item=$form{'ITEMNUM'}

 Thank you and please tell a friend about us!
 Sincerely,
 $config{'sitename'}
";
	#&sendemail($email, 'Fwd: Auction Question', $config{'admin_address'}, $mailto);
      # This should fix the above line
      &sendemail($email, $config{'admin_address'}, 'Fwd: Auction Question',  $mailto);
    print	&load_template ('sellersend.html', {
	   CATTREE		=>	  $form{'CATTREE'}, 
	   SELLER		=>	  $form{'SELLER'},
       ITEMNUM  	=>    $form{'ITEMNUM'},        
				%globals
	});      

1;