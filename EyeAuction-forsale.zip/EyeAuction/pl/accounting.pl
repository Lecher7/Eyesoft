#!c:\Perl\bin\perl
use vars qw(%config %searchcats %category %form);
#use CGI::Carp qw/fatalsToBrowser/; # For testing only
use strict;
##############################################################
#This is where the user logs in to see what there tracking

sub acct_login {
		print "<HTML>";
		print "<HEAD>";
		print "<TITLE></TITLE>";
		print "</HEAD>";
		print "$config{'header'}";
		print "$config{'navbar'}";
    print "<DIV ALIGN=center>\n";
    print "<BR><TABLE WIDTH=340 BORDER=0 cellpadding=1 cellspacing=1 bgcolor=000000>";
    print "<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>\n";
    print "<INPUT TYPE=HIDDEN NAME=action VALUE=view_balance>";
    print "<TR><TD bgcolor=$config{'colortablehead'} COLSPAN=2 VALIGN=CENTER>\n";
    print "<font face=arial color=FFFFFF size=4><B><CENTER>Check your account</CENTER></B></FONT>\n";
    print "</TD></TR>\n";
    print "<TR><TD bgcolor=$config{'colortablebody'} ALIGN=RIGHT VALIGN=CENTER><font face=arial><B>Username/Alias: \n";
    print "</B></TD>\n";
    print "<TD align=center bgcolor=$config{'colortablebody'}><INPUT TYPE=TEXT SIZE=22 NAME=ALIAS>\n";
    print "</TD></TR>\n";
    print "<TR><TD bgcolor=$config{'colortablebody'} ALIGN=RIGHT VALIGN=CENTER><font face=arial><B>Password: \n";
    print "</B></TD>\n";
    print "<TD align=center bgcolor=$config{'colortablebody'}><INPUT TYPE=PASSWORD SIZE=22 NAME=PASSWORD>\n";
    print "</TD></TR></TABLE>\n";
    print "<BR>\n";
    print "<INPUT TYPE=submit VALUE=\"Check My Account \">\n";
    print "</FORM>\n";
    print "$config{'navbar'}";
		print "$config{'footer'}";
		print "</BODY>";
		print "</HTML>";
}

##############################################################
#-#############################################
sub user_list {
		print <<"EOF";
<br>
<table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=$config{'colortablehead'}>
<tr><td align=center><font size=4<b>Enter Admin Password</b></font></td></tr>
</table>
<br>
<table width=90%  border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=$config{'colortablebody'}>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<INPUT TYPE=HIDDEN NAME=action VALUE="show_list">
<tr><td><b>Password:</b> </td><td><INPUT TYPE=PASSWORD NAME=PASSWORD SIZE=40 MAXLENGTH=40 VALUE="$form{'PASSWORD'}"></td></tr>
<tr><td colspan=2 align=center><INPUT TYPE=SUBMIT VALUE="View Accounts"></td></tr>
</FORM></table>
EOF
}
#-#############################################
sub show_list {
&oops('You must enter your password.') unless ($form{'PASSWORD'});
&oops('You are unauthorized.') unless ($form{'PASSWORD'} eq $config{'adminpass'});
print "<br><br><TABLE BORDER=1 BORDERCOLOR=$config{'colorborder'} CELLSPACING=0 CELLPADDING=0 WIDTH=100\%>\n";
print "<TR><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Click \"View Account\" button to view a users account</B></TD></TR>\n";
print "</TABLE>";
print "<br><br><TABLE BORDER=1 BORDERCOLOR=$config{'colorborder'} CELLSPACING=0 CELLPADDING=0 WIDTH=100\% bgcolor=ffffff>\n";
print "<TR><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>User</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Balance</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>View</B></TD></TR>\n";
opendir THEDIR, "$config{'basepath'}$config{'accounts'}" or &oops("Accounting directory could not be opened.");
readdir THEDIR;readdir THEDIR;
my @allaccounts = sort { $a <=> $b } readdir THEDIR;
closedir THEDIR;
my $account;
foreach $account (sort @allaccounts) {
$account =~ s/^$config{'basepath'}$config{'accounts'}\///;
$account =~ s/\.dat$//;
my (@bills) = &read_bill_file($account);
my ($transaction, $amount, $type, $btime , $balance) = &read_bill($bills[0]); # read first bill
print "<TR><TD><B>$account</B></TD><TD ALIGN=CENTER><B>\$$balance</B></TD><TD ALIGN=CENTER>";
print "<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>";
print "<TR><TD ALIGN=CENTER>";
print "<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>";
print "<INPUT TYPE=HIDDEN NAME=action VALUE=show_history>";
print "<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE=$config{'adminpass'}>";
print "<INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$account>";
print "<INPUT TYPE=HIDDEN NAME=DAYSBACK VALUE=all>";
print "<INPUT TYPE=HIDDEN NAME=BALANCE VALUE=$balance>";
print "<INPUT TYPE=SUBMIT VALUE=\"View Account\">";
print "</TD></TR></FORM></TABLE>";
print "</TD></TR>";
}
print "</TABLE>";
}
###############################################
sub show_history {
my $pagebreak = 20;
my ($icount, $pcount) = (0,0);
my $tcount;
my $line;
	&oops('You must enter your alias.') unless ($form{'ALIAS'});
	&oops('You must enter your password.') unless ($form{'PASSWORD'});
	$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
#	my ($userinfo, @past_bids) = &read_reg_file($form{'ALIAS'});
	my ($password,$email,$add1,$add2,$add3,@past_bids) = &read_reg_file($form{'ALIAS'}); 
#	my @userid = split(/:::/, $userinfo);
	if ($form{'PASSWORD'} ne $config{'adminpass'}) {
	&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	}else {
	
print "$config{'header'}";
print "$config{'navbar'}";	
print <<"EOF";
<br><table width=75% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=$config{'colortablehead'}>
<tr><td align=center><font size=4><b>$form{'ALIAS'}\'s Account Details</b></font></td></tr>
<tr><td bgcolor=FFFFFF><b>Name:</b>&nbsp;$add1</td></tr>
<tr><td bgcolor=FFFFFF><b>Address:</b>&nbsp;$add2</td></tr>
<tr><td bgcolor=FFFFFF><b>City/State/Zip:</b>&nbsp;$add3</td></tr>
<tr><td bgcolor=FFFFFF><b>E-Mail:</b>&nbsp;$email</td></tr>
<tr><td bgcolor=FFFFFF><b>Password:</b>&nbsp;$password</td></tr>
</table>
<br><table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=$config{'colortablehead'}>
<tr><td align=center><font size=4><b>Apply A Transaction To $form{'ALIAS'} Account</b></font> (admin only)</td></tr>
</table>
<br>
<table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=ffffff>
<tr><td align=center>
<table border=0 cellspacing=0 cellpadding=0>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<INPUT TYPE=HIDDEN NAME=action VALUE=go_debcredit>
<INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$form{'ALIAS'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE=$form{'PASSWORD'}>
<TR><TD VALIGN=TOP><B>Debit Or Credit:</B></TD><TD><SELECT NAME=CREDDEB>
<OPTION SELECTED VALUE="1">Credit</OPTION>
<OPTION VALUE="0">Debit</OPTION>
</SELECT></TD></TR>
<tr><td><b>Description of transaction:</b> </td><td><INPUT TYPE=TEXT NAME=TRAN SIZE=30 MAXLENGTH=30></td></tr>
<tr><td><b>Amount of transaction: \$</b></td><td><INPUT TYPE=TEXT NAME=AMT SIZE=9 MAXLENGTH=10></td></tr>
<tr><td colspan=2><INPUT TYPE=SUBMIT VALUE="Submit Transaction"></td></tr>
</FORM></table>
</td></tr></table>
<br>

<table width=100% border=0 cellspacing=0 cellpadding=0>
<tr><td align=center><b>Send $form{'ALIAS'} A Bill</b></td></tr>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<INPUT TYPE=HIDDEN NAME=action VALUE="send_bill">
<INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$form{'ALIAS'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE=$form{'PASSWORD'}>
<INPUT TYPE=HIDDEN NAME=AMT VALUE=$form{'BALANCE'}>
<INPUT TYPE=HIDDEN NAME=EMAIL VALUE=$email>
<tr><td align=center><INPUT TYPE=SUBMIT VALUE="Send bill"></td></tr>
</FORM></table>
EOF
}
	my (@bills) = &read_bill_file($form{'ALIAS'});
	my $bill;
	print "$config{'header'}";
	print "$config{'navbar'}";	
	print "<br><TABLE width=100% border=1 bordercolor=$config{'colorborder'} cellpadding=0 cellspacing=0 bgcolor=#FFFFFF>";
	print "<TR><TD align=center><font color=red><b>B</b></font>= Bold Listing\&nbsp\;\&nbsp\;\&nbsp\;<font color=#008000><b>F</b></font>= Featured Listing\&nbsp\;\&nbsp\;\&nbsp\;<font color=navy><b>BN</b></font>= Buyit Button Used\&nbsp\;\&nbsp\;\&nbsp\;<font color=maroon><b>BF</b></font>= Banner Used<br><font color=800080><b>TC</b></font>= 2nd category listing</TD></TR>";
	print "</TABLE>";
	print "<br><TABLE width=100% border=1 bordercolor=$config{'colorborder'} cellpadding=0 cellspacing=0 bgcolor=#FFFFFF>";
	print "<TR><TD align=center bgcolor=$config{'colortablehead'}>Transaction</TD><TD align=center bgcolor=$config{'colortablehead'}>Amount</TD><TD align=center bgcolor=$config{'colortablehead'}>Type</TD><TD align=center bgcolor=$config{'colortablehead'}>Time</TD><TD align=center bgcolor=$config{'colortablehead'}>Balance</TD></TR>";
	foreach $bill (@bills) {
	my @bidline = split(/:::/, $bill);
	my $nowtime = (time);
	my $dayid;
	$dayid = localtime($bidline[3]);
	$dayid =~ s/Sun//;
	$dayid =~ s/Mon//;
	$dayid =~ s/Tue//;
	$dayid =~ s/Wed//;
	$dayid =~ s/Thu//;
	$dayid =~ s/Fri//;
	$dayid =~ s/Sat//;
	$tcount++;
	if(++$icount > $pagebreak){$icount=1; $pcount++}
	next if $pcount != $form{page};
	if (($form {'DAYSBACK'} eq "10") && ($nowtime >= $bidline[3]) && ($nowtime < ($bidline[3] + 864000))) {
		if ($bidline[4] < 0) {
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center><font color=red>\$$bidline[4]</font></TD></TR>";
		}else{
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center>\$$bidline[4]</TD></TR>";
		}
	}
elsif (($form {'DAYSBACK'} eq "30") && ($nowtime >= $bidline[3]) && ($nowtime < ($bidline[3] + 2592000))) {
		if ($bidline[4] < 0) {
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center><font color=red>\$$bidline[4]</font></TD></TR>";
		}else{
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center>\$$bidline[4]</TD></TR>";
		}
	}
if (($form {'DAYSBACK'} eq "60") && ($nowtime >= $bidline[3]) && ($nowtime < ($bidline[3] + 5184000))) {
		if ($bidline[4] < 0) {
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center><font color=red>\$$bidline[4]</font></TD></TR>";
		}else{
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center>\$$bidline[4]</TD></TR>";
			}
		}
if (($form {'DAYSBACK'} eq "all") && ($nowtime >= $bidline[3])) {
		if ($bidline[4] < 0) {
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center><font color=red>\$$bidline[4]</font></TD></TR>";
		}else{
		print "<TR><TD>$bidline[0]</TD><TD align=center>\$$bidline[1]</TD><TD align=center>$bidline[2]</TD><TD align=center>$dayid</TD><TD align=center>\$$bidline[4]</TD></TR>";
			}
		}
	}	
print "</TABLE>";
pagebreak($pcount,$pagebreak);
}
#################################################
sub check_account {
print "$config{'header'}";
print "$config{'navbar'}";
		print <<"EOF";
<br>
<table width=90% border=1 bordercolor=$config{'colorborder'} bgcolor=$config{'colortablehead'} cellspacing=0 cellpadding=0>
<tr><td align=center><font size=4><b>View Your Account</b></font></td></tr>
</table>
<br>
<table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=$config{'colortablebody'}>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<INPUT TYPE=HIDDEN NAME=action VALUE="view_balance">
<tr><td><b>Alias:</b> </td><td><INPUT TYPE=TEXT NAME=ALIAS SIZE=40 MAXLENGTH=40 VALUE="$form{'ALIAS'}"></tr>
<tr><td><b>Password:</b> </td><td><INPUT TYPE=PASSWORD NAME=PASSWORD SIZE=40 MAXLENGTH=40 VALUE="$form{'PASSWORD'}"></td></tr>
<tr><td colspan=2 align=center><INPUT TYPE=SUBMIT VALUE="View Account"></td></tr>
</FORM></table>
EOF
}
##################################################
# SUB: Send Bill
sub send_bill {
	&oops('You are not authorized.') unless ($form{'PASSWORD'} eq $config{'adminpass'});
	require "sendemail.pl";
	&sendemail($form{'EMAIL'}, $config{'admin_address'}, 'Payment Request', "$form{'ALIAS'}, your account is holding a balance of \$$form{'AMT'}\nPlease log in and make a prompt payment\nhttp://$config{'scripturl'}$ENV{'SCRIPT_NAME'}?action=check_account\nThank You\r\n\r\nFrom The Auction At: $config{'sitename'}.");
print <<EOF;
<br><br>
<table width=50% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=ffffff>
<tr><td align=center>$form{'ALIAS'} has been sent a bill.</td></tr>
</table>
EOF
}
###############################################
sub view_balance {

	&oops('You must enter your alias.') unless ($form{'ALIAS'});
	&oops('You must enter your password.') unless ($form{'PASSWORD'});
	$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
	my ($userinfo, @past_bids) = &read_reg_file($form{'ALIAS'});
	my @userid = split(/:::/, $userinfo);
	if ($form{'PASSWORD'} ne $config{'adminpass'}) {
	&oops('Your password is incorrect.') unless ((lc $userid[0]) eq (lc $form{'PASSWORD'}));
	}
	my (@bills) = &read_bill_file($form{'ALIAS'});
	my @firstbill =  &read_bill($bills[0]);
	my $showbalance = &parsebid($firstbill[4]);
print "$config{'header'}";
print "$config{'navbar'}";	
print "<br><table width=90% cellspacing=0 cellpadding=0 bgcolor=ffffff border=0 bordercolor=$config{'colorborder'}>";
print "<td align=center><font size=+2><b>$form{'ALIAS'}'s Auction Page</b></font><BR><HR></td>";
if ($firstbill[4] < 0) {
print "<tr><td align=center><b>Your Account Holds A Balance of: <font color=red>\$$showbalance</font></b></td></tr>";
}else{
print "<tr><td align=center><b>Your Account Holds A Balance of: + \$$showbalance</b></td></tr>";
}
print "</table><BR>";
if ($form{'PASSWORD'} eq $config{'adminpass'}) {
print <<"EOF";
<br>
<table width=100% border=0 cellspacing=0 cellpadding=0 bgcolor=ffffff>
<tr><td align=center><b>Send $form{'ALIAS'} A Bill</b></td></tr>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<INPUT TYPE=HIDDEN NAME=action VALUE="send_bill">
<INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$form{'ALIAS'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE=$form{'PASSWORD'}>
<INPUT TYPE=HIDDEN NAME=AMT VALUE=$showbalance>
<INPUT TYPE=HIDDEN NAME=EMAIL VALUE=$userid[1]>
<tr><td colspan=2 align=center><INPUT TYPE=SUBMIT VALUE="Send bill"></td></tr>
</FORM></table>
EOF
}
		print <<"EOF";
<table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=ffffff>
<tr><td align=center width=100%><BR>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<b>Make a payment or add funds to your account</b>
<INPUT TYPE=HIDDEN NAME=action VALUE="proc_paypal_pay">
<INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$form{'ALIAS'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE=$form{'PASSWORD'}>
<INPUT TYPE=SUBMIT VALUE="Submit">
</FORM></td></tr></table><BR>
EOF
print "<br><table width=90% cellspacing=0 cellpadding=4 bgcolor=ffffff border=1 bordercolor=$config{'colorborder'}>";
print "<tr><td width=45% align=center valign=middle bgcolor=FFFFFF><a href=$ENV{'SCRIPT_NAME'}\?action=new>Post New Item</a></td>";
print "<td width=45% align=center valign=middle bgcolor=FFFFFF><a href=$ENV{'SCRIPT_NAME'}\?action=creg>Change Registration</a></td></tr>";
print "<td width=45% align=center valign=middle bgcolor=FFFFFF><a href=$ENV{'SCRIPT_NAME'}\?action=search&searchtype=username&searchstring=$form{'ALIAS'}>View My Auctions</a></td>";
print "<td width=45% align=center valign=middle bgcolor=FFFFFF><a href=$ENV{'SCRIPT_NAME'}\?action=proctracking&ALIAS=$form{'ALIAS'}&PASSWORD=$form{'PASSWORD'}>View Profile/Tracked Auctions</a></td></tr>";

print "</tr></table>";
if ($config{'favorites_allow'}) {
print "<p><FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>";
print "<p><table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=ffffff>";
print "<td width=100% align=center valign=middle bgcolor=FFFFFF>";
print "<INPUT TYPE=HIDDEN NAME=action VALUE=\"see_favorites\">";
print "<INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$form{'ALIAS'}>";
print "<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE=$form{'PASSWORD'}>";
print "<INPUT TYPE=SUBMIT VALUE=\"My Favorite Users Items\">";
print "</td></tr>";
print "</table>";
print "</FORM>";
}
          print <<"EOF";
<p><table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=ffffff>
<tr><td align=center width=100%><BR>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<B>View Last:</B>
<INPUT TYPE=HIDDEN NAME=action VALUE="show_history">
<INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$form{'ALIAS'}>
<INPUT TYPE=HIDDEN NAME=PASSWORD VALUE=$form{'PASSWORD'}>
<SELECT NAME=DAYSBACK>
<OPTION SELECTED VALUE="10">10 Days</OPTION>
<OPTION VALUE="30">30 Days</OPTION>
<OPTION VALUE="60">60 Days</OPTION>
<OPTION VALUE="all">All Transactions</OPTION>
</SELECT>
<INPUT TYPE=SUBMIT VALUE="View Account History">
</FORM>
</td></tr></table>
EOF
}
#-#############################################
sub proc_paypal_pay {
	&oops('You must enter your alias.') unless ($form{'ALIAS'});
	&oops('You must enter your password.') unless ($form{'PASSWORD'});
	$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
	my ($userinfo, @past_bids) = &read_reg_file($form{'ALIAS'});
	my @userid = split(/:::/, $userinfo);
	&oops('Your password is incorrect.') unless ((lc $userid[0]) eq (lc $form{'PASSWORD'}));
my (@bills) = &read_bill_file($form{'ALIAS'});
my @firstbill =  &read_bill($bills[0]);
my $paybill;
$paybill = $firstbill[4];
$paybill =~ s/-//;
my $parsedpaybill = &parsebid($paybill);
if ($firstbill[4] < 0) {
print "$config{'header'}";
print "$config{'navbar'}";
print "<br><br><table border=0 bordercolor=$config{'colorborder'} cellpadding=0 cellspacing=0 bgcolor=#FFFFFF width=90%>";
print "<tr><td align=center width=100%><font size=4><b>Click here to pay with PayPal.Com</font></b><br>";
print <<"EOF";
<FORM ACTION="https://secure.paypal.com/cgi-bin/webscr" METHOD="POST">
<INPUT TYPE="hidden" NAME="cmd" VALUE="_xclick">
<INPUT TYPE="hidden" NAME="business" VALUE="$config{'ppemail'}">
<INPUT TYPE="hidden" NAME="return" VALUE="http://$config{'auctionurl'}?action=pcredit&ALIAS=$form{'ALIAS'}&TRAN=PayPal_Payment&AMT=$paybill">
<INPUT TYPE="hidden" NAME="item_name" VALUE="Auction Payment">
<INPUT TYPE="hidden" NAME="amount" VALUE="$parsedpaybill">
<INPUT TYPE="image" SRC="https://www.paypal.com/images/lgo/logo4.gif" NAME="submit" ALT="Make payments with PayPal - it's fast, free and secure!">
</FORM>
EOF
print "</td></tr>";
print "</table>";
if ($config{'verisign'} eq "1") {
print "<br><hr width=75%>";
print "<br><font size=4><b>Click the Verisign button to pay using Verisign.</b></font><br>";
print "<br><table border=0 bordercolor=$config{'bordercolor'} cellpadding=0 cellspacing=0 bgcolor=#FFFFFF width=90%>";
print "<tr><td align=center width=100%>";
print <<"EOF";
<table border="8" cellpadding="8" cellspacing="0"><tr><td><p align="center"><font face="Arial"><b><font size="2">
For your protection, we <br> use the most trusted name<br> in Credit Card Processing<br>
</font></b><input type="image" name="VS" src="http://$config{'scripturl'}/images/verisign.gif" width="114" height="62" border="0">
</font>
</p>
<form method="POST"action="https://payflowlink.verisign.com/payflowlink.cfm">
<input type="hidden" name="LOGIN" value="$config{'vsid'}">
<input type="hidden" name="PARTNER" value="hps">
<input type="hidden" name="TYPE" value="S">
<input type="hidden" name="COMMENT" value="AuctionPayment">
<input type="hidden" name="RETURNMETHOD" value="2">
<input type="hidden" name="RETURNURL" value="$ENV{'SCRIPT_NAME'}">
<input type="hidden" name="ACTIVATE_SP" value="1">
<input type="hidden" name="POSTURL" value="$ENV{'SCRIPT_NAME'}?">
<input type="hidden" name="ECHODATA" value="True">
<input type="hidden" name="USER1" value="vcredit">
<input type="hidden" name="CUSTID" value="$form{'ALIAS'}">
<input type="hidden" name="AMOUNT" value="$parsedpaybill">
<input type="hidden" name="USER2" value="Verisign_Payment">
<input type="submit" value="Pay Through VeriSign" name="VS"></font>
</form>
<p align="center"><b><font size="2" face="Arial">Credit Cards Accepted:<br>MasterCard and Visa</font></b>
</p></td></tr></table>
EOF
print "</td></tr></table>";
}
}else{
print "$config{'header'}";
print "$config{'navbar'}";
print "<br><br><table border=0 bordercolor=$config{'colorborder'} cellpadding=0 cellspacing=0 bgcolor=#FFFFFF width=90%>";
print "<tr><td align=center width=100%><font size=4><b>Your balance is currently + \$$parsedpaybill</font></b></td></tr>";
print "<tr><td align=center width=100%><font size=4>You may add more funds to your account if you wish.</font></td></tr>";
print "<tr><td align=center width=100%><font size=4>Fill in the amount you wish to add and click the image below to add funds using PayPal.</font></td></tr>";
print "<tr><td align=center width=100%>";
print <<"EOF";
<FORM ACTION=https://secure.paypal.com/cgi-bin/webscr METHOD=POST>
<INPUT TYPE="hidden" NAME="cmd" VALUE="_xclick">
<INPUT TYPE="hidden" NAME="business" VALUE="$config{'ppemail'}">
<INPUT TYPE="hidden" NAME="return" VALUE="$ENV{'SCRIPT_NAME'}?action=pcredit&ALIAS=$form{'ALIAS'}&TRAN=PayPal_Payment&AMT=$paybill">
<INPUT TYPE="hidden" NAME="item_name" VALUE="Auction Payment">
<INPUT TYPE="hidden" NAME="amount" VALUE="$parsedpaybill">
<br><b>Add \$</b><INPUT TYPE="text" NAME="amount" SIZE=5 MAXLENGHT=5 VALUE=1.00><br><b>To my account</b><br>
<INPUT TYPE="image" SRC="https://www.paypal.com/images/lgo/logo4.gif" NAME="submit" ALT="Make payments with PayPal - it's fast, free and secure!">
</FORM>
EOF
print "</td></tr>";
print "</table>";
if ($config{'verisign'} eq "1") {
print "<hr width=75%>";
print "<br><font size=4><b>Click the Verisign button to add funds using Verisign.</b></font><br>";
print "<br><table border=0 bordercolor=$config{'bordercolor'} cellpadding=0 cellspacing=0 bgcolor=#FFFFFF width=90%>";
print "<tr><td align=center width=100%>";
print <<"EOF";
<table border="8" cellpadding="8" cellspacing="0"><tr><td><p align="center"><font face="Arial" size="2"><b>
For your protection, we <br> use the most trusted name<br> in Credit Card Processing<br>
</b><input type="image" name="VS" src="http://$config{'scripturl'}/images/verisign.gif" width="114" height="62" border="0">
</font>
</p>
<form method="POST"action="https://payflowlink.verisign.com/payflowlink.cfm">
<input type="hidden" name="LOGIN" value="$config{'vsid'}">
<input type="hidden" name="PARTNER" value="hps">
<input type="hidden" name="TYPE" value="S">
<input type="hidden" name="COMMENT" value="AuctionPayment">
<input type="hidden" name="RETURNMETHOD" value="2">
<input type="hidden" name="RETURNURL" value="$ENV{'SCRIPT_NAME'}">
<input type="hidden" name="ACTIVATE_SP" value="1">
<input type="hidden" name="POSTURL" value="$ENV{'SCRIPT_NAME'}?">
<input type="hidden" name="ECHODATA" value="True">
<input type="hidden" name="USER1" value="vcredit">
<input type="hidden" name="CUSTID" value="$form{'ALIAS'}">
<input type="hidden" name="USER2" value="Verisign_Payment">
<input type="submit" value="Pay Through VeriSign" name="VS">
<p align="center"><b>Add \$</b><INPUT TYPE="text" NAME="AMOUNT" SIZE=5 MAXLENGHT=5 VALUE=1.00><br><b>To my account</b></p>
</font>
</form>
<p align="center"><b><font size="2" face="Arial">Credit Cards Accepted:<br>MasterCard and Visa</font></b>
</p></td></tr></table>
EOF
print "</td></tr></table>";
}}}
#######################################
sub make_transaction {
&oops('You must enter your password.') unless ($form{'PASSWORD'});
&oops('You are unauthorized.') unless ($form{'PASSWORD'} eq $config{'adminpass'});
		print <<"EOF";
<br><table width=90% border=1 bordercolor=$config{'colorborder'} cellspacing=0 cellpadding=0 bgcolor=$config{'colortablehead'}>
<tr><td align=center><font size=4><b>Apply A Transaction To A Users Account</b></font> (admin only)</td></tr>
</table>
<br>
<table width=90% border=0 cellspacing=0 cellpadding=0 bgcolor=$config{'colortablebody'}>
<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>
<INPUT TYPE=HIDDEN NAME=action VALUE=go_debcredit>
<TR><TD VALIGN=TOP><B>Debit Or Credit:<BR></B>Select One</TD><TD>
<SELECT NAME=CREDDEB>
<OPTION SELECTED VALUE="1">Credit</OPTION>
<OPTION VALUE="0">Debit</OPTION>
</SELECT></TD></TR>
<tr><td><b>Description of transaction:</b> </td><td><INPUT TYPE=TEXT NAME=TRAN SIZE=30 MAXLENGTH=30></td></tr>
<tr><td><b>Amount of transaction: \$</b></td><td><INPUT TYPE=TEXT NAME=AMT SIZE=40 MAXLENGTH=40></tr>
<tr><td><b>User's Alias:</b> </td><td><INPUT TYPE=TEXT NAME=ALIAS SIZE=40 MAXLENGTH=40></tr>
<tr><td><b>Admin Password:</b> </td><td><INPUT TYPE=PASSWORD NAME=PASSWORD SIZE=40 MAXLENGTH=40></td></tr>
<tr><td colspan=2><INPUT TYPE=SUBMIT VALUE="Submit Transaction"></td></tr>
</FORM></table>
EOF
}
#-#############################################
sub go_debcredit {
	&oops('You must enter your password.') unless ($form{'PASSWORD'});
	&oops('You are unauthorized.') unless ($form{'PASSWORD'} eq $config{'adminpass'});
	&oops('You must enter an alias.') unless ($form{'ALIAS'});
	$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
	my $amt = &parsebid($form{'AMT'});
	my $creddeb;
	if ($form{'CREDDEB'} eq "1") {$creddeb = "credit";}else{$creddeb = "debit";}
	my (@bills) = &read_bill_file($form{'ALIAS'});
	my @firstbill =  &read_bill($bills[0]);
	my $newbalance;
	if ($form{'CREDDEB'} eq "0") {
	$newbalance = ($firstbill[4] - $amt);
	}elsif ($form{'CREDDEB'} eq "1") {
	$newbalance = ($firstbill[4] + $amt);
	}
	my $showbalance = &parsebid($newbalance);
	&debcredit($form{'ALIAS'}, "$form{'TRAN'}", "$amt", "$config{'adminpass'}", "$creddeb");
print "<br><br><br><br>";
print "<TABLE WIDTH=90% BORDER=0 CELLSPACING=0 CELLPADDING=0>";
print "<TR><TD HEIGHT=100% ALIGN=CENTER><b>Transaction Complete..</b></TD></TR>";
if ($newbalance >= 0) {
print "<TR><TD HEIGHT=100% ALIGN=CENTER><b>$form{'ALIAS'}\'s balance is now: + \$$showbalance</b></TD></TR>";
}else{
print "<TR><TD HEIGHT=100% ALIGN=CENTER><b>$form{'ALIAS'}\'s balance is now: <font color=red>\$$showbalance</font></b></TD></TR>";
}
print "</TABLE>";

print "<center><a href=\"EyeAuction.cgi\">Auction Home</a></center>";
}
#-#############################################
sub pcredit {
# print "Hello\n";
			my $trans = $form{'TRAN'};
			my $ammount  = &parsebid($form{'AMT'});
			my $transtype  = "Credit";
			my $delimiter  = ":::";
			$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
			my (@bills) = &read_bill_file($form{'ALIAS'});
			my ($transaction, $amount, $type, $btime, $balance) = &read_bill($form{'ALIAS'});
			my @firstbill =  &read_bill($bills[0]);
			my $newtime = (time);
			my $newbalance = &parsebid($firstbill[4] + $ammount);
			&oops('NEWBILL') unless (open(NEWBILL,">$config{'basepath'}$config{'accounts'}/$form{'ALIAS'}.dat"));
			if ($config{'flock'}) {
			flock(NEW, 2);
			seek(NEW, 0, 2);
			}
			print NEWBILL "$trans$delimiter$ammount$delimiter$transtype$delimiter$newtime$delimiter$newbalance";
			my $bill;
			foreach $bill (@bills) {print NEWBILL "\n$bill";}
			close(NEWBILL);
			print "<TABLE width=100% border=0 cellpadding=0 cellspacing=0 bgcolor=#FFFFFF>";
			print "<TR><TD width=100%><b>$form{'ALIAS'} has been credited \$$ammount for $trans. Pending PayPal confirmation.</b></TD></TR>";
			print "<TR><TD width=100%><b>If no confirmation is recieved from PayPal, your account will be adjusted accordingly.</b></TD></TR>";
			print "</TABLE>";
			&sendemail($config{'admin_address'}, "$config{'sitename'}", 'PayPal Auction Payment', "$form{'ALIAS'} Has paid \$$ammount using paypal.\nCheck administration email for confirmation of this transaction.\nFrom The Auction At: $config{'sitename'}.");
}
#-#############################################
sub vcredit {
&oops('We dont Accept Verisign') unless ($config{'verisign'} eq "1");
my $trans = $form{'USER2'};
my $ammount  = &parsebid($form{'AMOUNT'});
my $transtype  = "Credit";
$form{'CUSTID'} = ucfirst(lc($form{'CUSTID'}));
my (@bills) = &read_bill_file($form{'CUSTID'});
my ($transaction, $amount, $type, $btime, $balance) = &read_bill($form{'CUSTID'});
my @firstbill =  &read_bill($bills[0]);
my $newtime = (time);
my $newbalance = &parsebid($firstbill[4] + $ammount);
&oops('NEWBILL') unless (open(NEWBILL,">$config{'basepath'}$config{'accounts'}/$form{'CUSTID'}.dat"));
if ($config{'flock'}) {
flock(NEW, 2);
seek(NEW, 0, 2);
}
print NEWBILL "$trans\[\]$ammount\[\]$transtype\[\]$newtime\[\]$newbalance";
my $bill;
foreach $bill (@bills) {print NEWBILL "\n$bill";}
close(NEWBILL);
&sendemail($config{'admin_address'}, "$config{'sitename'}", 'Verisign Auction Payment', "$form{'CUSTID'} Has paid \$$ammount using paypal.\nCheck administration email for confirmation of this transaction.\nFrom The Auction At: $config{'sitename'}.");
}
###############################################
sub debcredit {
my $trans = $_[1];
my $ammount  = $_[2];
my $postpass  = $_[3];
my $more_less  = $_[4];
my $delimiter = ":::";
my $newbalance;
my $transtype;
if ($more_less eq "debit") {
$transtype  = "Debit";
}
if (($more_less eq "credit") or ($more_less eq "pcredit")) {
$transtype  = "Credit";
}
&oops('Cant do that in a browser window silly') unless($postpass eq $config{'adminpass'});
&oops('We do not accept PayPal.') unless($config{'paypal'} eq "1");
&oops('Not a valid amount.') unless ($ammount =~ /^(\d+\.?\d*|\.\d+)$/);
$form{'ALIAS'} = $form{'ALIAS'};
$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
my (@bills) = &read_bill_file($form{'ALIAS'});
my ($transaction, $amount, $type, $btime, $balance) = &read_bill($form{'ALIAS'});
my @firstbill =  &read_bill($bills[0]);
my $newtime = (time);
if ($more_less eq "debit") {
$newbalance = &parsebid($firstbill[4] - $ammount);
}
if ($more_less eq "credit") {
$newbalance = &parsebid($firstbill[4] + $ammount);
}
my $printbalance = &parsebid($newbalance);

###################################
# Kill this if newbalance is negative
if ($printbalance > 0){
}else{
&oops('Your balance is too low.  Please add funds.')
}
###################################

&oops('NEWBILL') unless (open(NEWBILL,">$config{'basepath'}$config{'accounts'}/$form{'ALIAS'}.dat"));
if ($config{'flock'}) {
flock(NEW, 2);
seek(NEW, 0, 2);
}
print NEWBILL "$trans$delimiter$ammount$delimiter$transtype$delimiter$newtime$delimiter$printbalance";
my $bill;
foreach $bill (@bills) {print NEWBILL "\n$bill";}
close(NEWBILL);
}
#######################################
sub closedebit {
my $lister = $_[0];
my $trans = $_[1];
my $ammount  = $_[2];
my $postpass  = $_[3];
my $transtype  = "Debit";
my $delimiter = ":::";
my $newbalance;
&oops('Cant do that in a browser window silly') unless($postpass eq $config{'adminpass'});
&oops('Not a valid amount.') unless ($ammount =~ /^(\d+\.?\d*|\.\d+)$/);
$lister = ucfirst(lc($lister));
my (@bills) = &read_bill_file($lister);
my ($transaction, $amount, $type, $btime, $balance) = &read_bill($lister);
my @firstbill =  &read_bill($bills[0]);
my $newtime = (time);
$newbalance = &parsebid($firstbill[4] - $ammount);
my $printbalance = &parsebid($newbalance);
&oops('NEWBILL') unless (open(NEWBILL,">$config{'basepath'}$config{'accounts'}/$lister.dat"));
if ($config{'flock'}) {
flock(NEW, 2);
seek(NEW, 0, 2);
}
print NEWBILL "$trans$delimiter$ammount$delimiter$transtype$delimiter$newtime$delimiter$printbalance";
my $bill;
foreach $bill (@bills) {print NEWBILL "\n$bill";}
close(NEWBILL);
}
#-#############################################
sub read_bill {
my $bill_string = shift;
my ($transaction, $amount, $type, $btime , $balance) = split(/:::/,$bill_string);
return ($transaction, $amount, $type, $btime , $balance);
}
#-#############################################
sub read_bill_file {
my $user = shift;
open FILE, "$config{'basepath'}$config{'accounts'}/$user.dat";
my (@bills) = <FILE>;
close FILE;
chomp (@bills);
return (@bills);
}
#############################################
1;