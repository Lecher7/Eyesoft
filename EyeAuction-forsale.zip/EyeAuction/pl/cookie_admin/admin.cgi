#!/usr/bin/perl

##############################################################################
# Edit above line (in necessary) to the path of Perl on you system 			 #
##############################################################################
# Cookie Login                     Version 2                                 #
# Copyright 1999-2000 Custom CGI   webmaster@custom-cgi.com                  #
# Created 15/July/00               Last Modified 13/Feb/2001                 #
# Custom CGI, Inc.:    			   http://www.custom-cgi.com/free/     		 #
##############################################################################
# COPYRIGHT NOTICE                                                           #
# Copyright 1999-2001 Custom CGI  All Rights Reserved.    		     		 #
#                                                                            #
# Cookie Login system may be used and modified free of charge by anyone so   #
# long as this copyright notice and the comments above remain intact. By     #
# using this code you agree to indemnify Custom CGI from any liability that  #
# might arise from its use.                                                  #
#                                                                            #
# Selling the code for this program without prior written consent is         #
# expressly forbidden.  In other words, please ask first before you try and  #
# make money off of my program.                                              #
#                                                                            #
# Obtain permission before redistributing this software over the Internet or #
# in any other medium.	In all cases copyright and header must remain intact #
##############################################################################
# Please submit any changes or add-ons you have made to,		     		 #
# http://www.custom-cgi.com/free/cookie_login/?action=submit_addon           #
##############################################################################
# 		NOTHING BELOW THIS LINE SHOULD NEED TO BE EDITED/CONFIGURED!    	 #
##############################################################################
use CGI::Carp qw(fatalsToBrowser);
require '../cookie.lib';
require '../common.cgi';
&get_input;
&GetCookies('admin_pass','admin_id');
$header = "<SCRIPT LANGUAGE=\"JavaScript\" SRC=\"http://www.custom-cgi.com/template.php3?action=header\"></script>";
$footer = "<SCRIPT LANGUAGE=\"JavaScript\" SRC=\"http://www.custom-cgi.com/template.php3?action=footer\"></script>";
if ($Cookies{'admin_pass'} eq "" || $Cookies{'admin_pass'} eq "") {

	if ($in{'action'} eq '') {
		&login;
	} elsif ($in{'action'} eq 'login') {
		&check_pass;
		print "Location: admin.cgi?cookies=turned_off\n\n";
		exit;
	}
	
} else {
	
	if ($in{'cookies'} eq "turned_off") {
		print "Location: admin.cgi\n\n";
		exit;
	}
	if ($in{'action'} eq "") {
		&editmembers;
		exit;
	}
	if ($in{'action'} eq "delete_mem") {
		&delete_mem;
	}
	if ($in{'action'} eq "delete_user_confirm") {
		&delete_user_confirm;
	}
	if ($in{'action'} eq "mail_selected_display") {
		&mail_selected_display;
	}
	if ($in{'action'} eq "mass_mail1") {
		&mail_selected_display;
	}
	if ($in{'action'} eq "send_mail") {
		if ($demo ne "on") {
			&send_mail;
			&mail_sent;
			exit;
		} else {
			&mail_sent;
			exit;
		}
	}
}
exit;

######## The Subroutines ########


sub login {
	print "Content-type: text/html\n\n";
	print $header;
	print "<h1>Please Login</h1>\n";
	print "Please login with your username and password.<P>\n";
	# this checks if cookies have been set. 
	if ($in{'cookies'} eq "turned_off") {
		print "<b><font color=\"#FF0000\">Error:</font></b> Cookies seem to be disabled. You cannot login until, \n";
		print "these are turned on.\n";
	}
	print "<form action=\"$ENV{'SCRIPT_NAME'}\" method=\"POST\">\n";
	print "	<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#000000\" width=\"400\">	\n";
	print "	    <tr> 	\n";
	print "	      <td> 	\n";
	print "	        <table cellpadding=8 border=0 width=\"100%\">\n";
	print "		<tr><td bgcolor=\"#ffffff\">\n";
	print "			<table cellpadding=8 border=0 width=\"100%\">\n";
	print "			<tr><td >\n";
	print "				User Name: \n";
	print "			</td><td>\n";
	print "				<input type=text name=username size=28 value=\"";
		if ($demo eq "on") {
			print "demo";
		}
	print "\">\n";
	print "			</td></tr>\n";
	print "			<tr bgcolor=\"#ffffff\"><td>\n";
	print "				Password:\n";
	print "			</td><td>\n";
	print "				<input type=password name=password size=28 value=\"";
		if ($demo eq "on") {
			print "demo";
		}
	print "\">\n";
	print "			</td></tr>\n";
	print "			</table>\n";
	print "			</td></tr>\n";
	print "			<tr><td bgcolor=\"#ffffff\">\n";
	print "			<input type=hidden name=action value=login>\n";
	print "			<input type=submit value=\"Submit Login\">\n";
	print "			<input type=\"reset\" value=\"Reset\">\n";
	print "		</td></tr>\n";
	print "		</table>\n";
	print "	   </td></tr>\n";
	print "   </table>\n";
	print '  </form>';
	
	print $footer;
}


sub editmembers {
  
	print "Content-type: text/html\n\n";
	print $header;
	print "<h1>Admin Menu</h1><P>\n";
	print "This is the admin area for Cookie Login System. You email selected, all or \n";
	print "an individual member.<P><center><form action=\"$ENV{'SCRIPT_NAME'}\" method =\"POST\">\n";
	print "<table width=\"400\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#000000\">\n";
	print "  <tr>\n";
	print "    <td>\n";
	print "      <table width=\"400\" border=\"0\" cellspacing=\"1\" cellpadding=\"6\">\n";
	print "        <tr bgcolor=\"#FFFFFF\"> \n";
	print "          <td>Member Name</td>\n";
	print "          <td> \n";
	print "            <div align=\"center\">Email</div>\n";
	print "          </td>\n";
	print "        </tr>\n";
	
	open(CF, "$setup_base_dir/members.txt");
	# get all th info in the file
	@all = <CF>;
	close(CF);
	@all = sort(@all);
	# loop for number of elements
	for($i = 0; $i <= @all; $i++){
		# split (explode) each line
		($mem_name,$mem_password,$mem__encrypted_password,$mem_email) = split(':',$all[$i]);
		if ($mem_name ne "") {
			# check to see if submited info matches existing info
			$mem_email =~ s/\n//g;
			print "        <tr><td bgcolor=\"#FFFFFF\"> \n";
			print "         <b>$mem_name</b>\n";
			print "        </td><td bgcolor=\"#FFFFFF\">\n";
			print "         <input type=\"checkbox\" name=\"email_$i\" value=\"$mem_email\">\n";
			print "        </td></tr>\n";
			$total++;
		}
	}
	
	if ($total eq "") {
		print "        <tr bgcolor=\"#FFFFFF\"><td colspan=\"2\" align=\"center\"><b>No Members</b></td></tr>\n";
	}
	print "        <tr bgcolor=\"#FFFFFF\"> \n";
	print "          <td colspan=\"2\">\n";
	print "           <input type=\"hidden\" name=\"total\" value=\"$total\">\n";
	print "           <input type=\"hidden\" name=\"action\" value=\"mail_selected_display\">\n";
	print "           <input type=submit value=\"Mail Selected\"></td>\n";
	print "        </tr>\n";
	print "      </table>\n";
	print "    </td>\n";
	print "  </tr>\n";
	print "</table></form>\n";
	print "<p>\&nbsp;</p>\n";
	print "<table width=\"450\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#000000\">\n";
	print "  <tr> \n";
	print "    <td colspan=\"3\">\n";
	print "      <table width=\"450\" border=\"0\" cellspacing=\"1\" cellpadding=\"6\">\n";
	print "        <tr bgcolor=\"#FFFFFF\" valign=\"bottom\"> \n";
	print "          <td> \n";
	print "            <form action=\"$ENV{'SCRIPT_NAME'}\" method =\"POST\">\n";
	print "              <select name=\"member\">\n";
	
	open(CF, "$setup_base_dir/members.txt");
	# get all th info in the file
	@all = <CF>;
	close(CF);
	# sort the array
	@all = sort(@all);
	# now store sorted array
	open (SIGNUP, ">$setup_base_dir/members.txt");
	# loop for number of elements
	for($i = 0; $i <= @all; $i++){
		# split (explode) each line
		($mem_name,$mem_password,$mem__encrypted_password,$mem_email) = split(':',$all[$i]);
		if ($mem_name ne "") {
			# check to see if submited info matches existing info
			$mem_email =~ s/\n//g;
			print "               <option value=\"$mem_name\">$mem_name</option>\n";
			$total++;
			# update member file with sorted array
			print SIGNUP ("@all[$i]");
		}
	}
	# close member file
	close (SIGNUP);
	if ($total == "") {
		print "               <option value=\"\">\&gt; No Mumbers</option>\n";
	}
	
	print "              </select>\n";
	print "              <input type=\"hidden\" name=\"action\" value=\"delete_mem\">\n";
	print "              <input type=submit value=\"Delete Member\">\n";
	print "            </form>\n";
	print "          </td>\n";
	print "          <td> \n";
	print "            <form action=\"$ENV{'SCRIPT_NAME'}\" method =\"POST\">\n";
	print "              <input type=\"hidden\" name=\"action\" value=\"mass_mail1\">\n";
	print "              <input type=\"submit\" value=\"Email all members\">\n";
	print "            </form>\n";
	print "          </td>\n";
	print "        </tr>\n";
	print "      </table>\n";
	print "    </td>\n";
	print "  </tr>\n";
	print "</table></center>\n";
	@name_array = sort(@name_array);
	for($i = 0; $i <= $#name_array; $i++){
		print "My name is: <b>@name_array[$i]</b><br>\n";
	}
	print $footer;
	exit;
}


sub check_pass {

	if  ($in{'username'} ne "$admin_login" || $in{'password'} ne "$admin_password") {
		&login_fail;
	} else {
		$crypted = crypt("$in{'password'}",'�mHgF*&');
		$crypted =~ s/[^a-z0-9\_]//g;
		&SetCookies('admin_id',$in{'username'});
	    &SetCookies('admin_pass',$crypted);
	}
}


sub login_fail {
	print "Content-type: text/html\n\n"; 
	print $header;
	print "<h2>Error</h2>\n";
	print "<P>Sorry that was the wrong login.\n";
	print $footer;
	exit;

}


sub delete_mem {

	print "Content-type: text/html\n\n";
 	print $header;
	print "<h1>Delete member</h1>\n";
	print "Once you delete a user, there is <b>no</b> turning back.  Please be sure \n";
	print "you're deleting the right user before  you hit that delete button!<P>\n";
 	print " <FORM ACTION=\"$ENV{'SCRIPT_NAME'}\" METHOD=\"POST\">\n";
	print "  <input type=hidden name=action value=delete_user_confirm>\n";
	print "<P> Delete member, <b>$in{'member'}</b><P>\n";
	print "<input type=checkbox name=member value=$in{'member'}>\n";
	print "Yes Delete member <b>$in{'member'}</b>.";
 	print "  <input type=submit value=\"Confirm Delete\"></form>\n";
	print "<P><i>You must check the box to delete the member</i>.\n";
	print $footer;

}

sub delete_user_confirm {

	if ($in{'member'} eq "") {
		print "Content-type: text/html\n\n";
		print $header;
		print "<h1>Error</h1>\n";
		print "You must check the checkbox to confirm deleting the member.\n";
		print $footer;
		exit;
	}
	
	open(CF, "$setup_base_dir/members.txt");
	# get all th info in the file
	@all = <CF>;
	close(CF);
	# loop for number of elements
	
	open (SIGNUP, ">$setup_base_dir/members.txt");
	for($i = 0; $i <= @all; $i++){
		# split (explode) each line
		($mem_name,$mem_password,$mem__encrypted_password,$mem_email) = split(':',$all[$i]);
		if ($mem_name ne "$in{'member'}" && $all[$i] ne "") {
			print SIGNUP ("$all[$i]");
		}
	}
	close (SIGNUP);
	
	print "Content-type: text/html\n\n";
	print $header;
	print "<h1>Member Deleted</h1>\n";
	print "Member has been successfully deleted. Press 'Retun' to go back to the main menu.\n";
	print "<FORM ACTION=\"$ENV{'SCRIPT_NAME'}\" METHOD=\"POST\">\n";
	print "<input type=submit value=\" Return \">\n";
	print "</form>";
	print $footer;
}
 
 
 
sub mail_selected_display {

	print "Content-type: text/html\n\n";
	print $header;
	#print "You are send an email to <b>$in{'total'}</b> members<P>\n";
	
	print "<FORM ACTION=\"$ENV{'SCRIPT_NAME'}\" METHOD=\"POST\">\n";
	if ($in{'action'} eq "mass_mail1") {
		print "<input type=\"hidden\" name=\"email\" value=\"all\">\n";
		print "<h1>Email All Members</h1>\n";
	} else {
		print "<h1>Email Selected</h1>\n";
	}
	
	$count = $in{'total'};
	$v = 0;
	for ($i=0;$i<=$count;$i++)
	{
		if ($in{"email_$i"} ne "") {
			print "<input type=\"hidden\" name=\"email_$i\" value=\"$in{\"email_$i\"}\">\n";
			$v++;
		}
	}
	print "From: <br><input type=text name=from size=45 value=\"$setup_email_admin\"><P>\n";
	print "Subject: <BR><input type=text name=subject size=45>\n";
	print "<BR><BR>Body of Message<BR>\n";
	print "<TEXTAREA NAME=body ROWS=14 COLS=50></TEXTAREA>\n";
	print "<input type=hidden name=action value=\"send_mail\"><br>\n";
	print "<input type=hidden name=total value=\"$v\">\n";
	print "<input type=submit value=\"Send this message\">\n";
	print "</form>";
	print $footer;
}

sub send_mail {
	if ($in{'email'} eq "all") {			
			
		open(CF, "$setup_base_dir/members.txt");
		# get all th info in the file
		@all = <CF>;
		close(CF);
		# loop for number of elements
		open (SIGNUP, "$setup_base_dir/members.txt") or die "Unable to open $setup_base_dir"."members.txt";
		for($i = 0; $i <= $#all; $i++){
			# split (explode) each line
			($mem_name,$mem_password,$mem__encrypted_password,$mem_email) = split(':',$all[$i]);
			
			open(MAIL, "|$setup_sendmail -t") || die;
			print MAIL "To: $mem_email \n";
			print MAIL "From: $setup_email_admin\n";
			print MAIL "Return-Path: $setup_email_admin\n";
			print MAIL "Subject: $in{'subject'}\n\n";
			print MAIL "$in{'body'}\n";
			print MAIL "\n\n";
			# please do not remove this
			print MAIL "============================================================\n";
			print MAIL "This uses Cookie Login System (http://www.custom-cgi.com)\n";
			close (MAIL);
			
		}
		close (SIGNUP);

	}
	else {
		
		for ($i=0;$i<=$in{'total'};$i++)
		{
			if ($in{"email_$i"} ne "") {
				open(MAIL, "|$setup_sendmail -t") || die;
				print MAIL "To: $mem_email \n";
				print MAIL "From: $setup_email_admin\n";
				print MAIL "Return-Path: $setup_email_admin\n";
				print MAIL "Subject: $in{'subject'}\n\n";
				print MAIL "$in{'body'}\n";
				print MAIL "\n\n";
				# please do not remove this
				print MAIL "============================================================\n";
				print MAIL "This uses Cookie Login System (http://www.custom-cgi.com)\n";
				close (MAIL);
			}
		}
	}

}	
sub mail_sent {
	
	print "Content-type: text/html\n\n";
	print $header;
	print "<h1>Email Sent</h1>\n";
	print "Your email has been successfully sent. Press 'Retun' to go back to the main menu.\n";
	if ($demo eq "on") {
		print "<P><i>Email disabled in demo.</i><P>\n";
	}
	print "<FORM ACTION=\"$ENV{'SCRIPT_NAME'}\" METHOD=\"POST\">\n";
	print "<input type=submit value=\" Return \">\n";
	print "</form>";
	print $footer;
	exit;
}
