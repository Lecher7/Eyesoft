use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
# 
#-#############################################
# Process Search
# This displays search results

	my ($key, $searchout);
	foreach $key (sort keys %category) {
		opendir THEDIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
		my @allfiles = grep -T, map "$config{'basepath'}$key/$_", sort { int($a) <=> int($b) } (readdir THEDIR);
		closedir THEDIR;
		my $file;
		foreach $file (@allfiles) {
			$file =~ s/^$config{'basepath'}$key\///;
			$file =~ s/\.dat$//;
			if (my ($iteminfo, $image, $desc, @bids) = &read_item_file($key,$file)) {
			  my @itemvals = split(/:::/, $iteminfo);
				my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
				my @closetime = localtime($file);
				$closetime[4]++;
				if($form{'searchtype'} eq 'keyword' and ($itemvals[0] =~ /$form{'searchstring'}/i) || ($desc =~ /$form{'searchstring'}/i)) {
					$searchout .= "<TR><TD BGCOLOR=$config{'colortablebody'}><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$itemvals[0]</A>";
					$searchout .= "<FONT COLOR=#3333FF SIZE=-1>[PIC]</FONT>" if ($image);
					$searchout .= "</TD><TD BGCOLOR=$config{'colortablebody'}>$closetime[4]/$closetime[3]</TD><TD BGCOLOR=$config{'colortablebody'}>$#bids</TD><TD BGCOLOR=$config{'colortablebody'}>\$$bid</TD></TR>\n";
				}
				elsif($form{'searchtype'} eq 'username' and join(' ',@bids) =~ /$form{'searchstring'}/i) {
					$searchout .= "<TR><TD BGCOLOR=$config{'colortablebody'}><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$itemvals[0]</A>";
					$searchout .= " <FONT COLOR=#3333FF SIZE=-1>[PIC]</FONT>" if ($image);
					$searchout .= "</TD><TD BGCOLOR=$config{'colortablebody'}>$closetime[4]/$closetime[3]</TD><TD BGCOLOR=$config{'colortablebody'}>$#bids</TD><TD BGCOLOR=$config{'colortablebody'}>\$$bid</TD></TR>\n";
				}
			}
		}

	}
	
    print	&load_template ('search.html', { 
       SEARCHOUT  	 =>    $searchout,
       SEARCHSTRING  =>    $form{'searchstring'},
			%globals
	});  

