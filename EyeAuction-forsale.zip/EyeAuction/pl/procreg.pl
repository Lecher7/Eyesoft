use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Process Registration
# This adds new accounts to the database
	my $delimiter = ":::";
	my $nowtime = (time);
	my $ftype = "Debit";
	my $opentime = (time);
	my $listtable;
	if ($config{'regdir'}) {
		umask(000);  # UNIX file permission junk
		mkdir("$config{'basepath'}$config{'regdir'}", 0777) unless (-d "$config{'basepath'}$config{'regdir'}");		
		&oops('You must enter an alias that consists of alphanumeric characters.') if $form{'ALIAS'} =~ /\W/ or !($form{'ALIAS'});
		&oops('You must enter a valid e-mail address.') unless ($form{'EMAIL'} =~ /^.+\@.+\..+$/);
		###Added for Multi-Alias####
		$form{'EMAIL'} = lc($form{'EMAIL'}); 
#		&multalias;
    ###End - Added for Multi-Alias####		
		&oops('You must enter your full name so buyers or sellers may contact you.') unless ($form{'ADDRESS1'});
		&oops('You must enter a valid street address so buyers or sellers can contact you.') unless ($form{'ADDRESS2'});
		&oops('You must enter a valid city, state, and zip code so buyers or sellers can contact you.') unless ($form{'ADDRESS3'});
		$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
		if (!(-f "$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat")) {
			&oops('We were unable to write to the user directory.') unless (open NEWREG, ">$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat");
			my $newpass = &randompass; 
			print NEWREG "$newpass\n$form{'EMAIL'}\n$form{'ADDRESS1'}\n$form{'ADDRESS2'}\n$form{'ADDRESS3'}";
			close NEWREG;
# Give the user an upload account too...	
			my $upldelim = "|";
			&oops('We were unable to assign you an account to upload images.') unless (open NEWUPL, ">>$config{'basepath'}$config{'upldir'}/upload.dat");
			my $newpass = &randompass; 
			print NEWUPL "$form{'ALIAS'}$upldelim$newpass$upldelim$config{'upldir2'}\n";
			close NEWUPL;			

				if (!(-f "$config{'basepath'}$config{'accounts'}/$form{'ALIAS'}.dat")) {
					&oops('We were unable to write to the billing directory.') unless (open NEWBILL, ">$config{'basepath'}$config{'accounts'}/$form{'ALIAS'}.dat");
					print NEWBILL "New Account opened$delimiter$config{'open_amount'}$delimiter$ftype$delimiter$opentime$delimiter$config{'open_amount'}";
					close NEWBILL;
				}		
				
			if ($form{'AFFREG'} ne ""){	
			# Add the info from this guy into his appropriate referrers file	
			
#######################################################################
# Learned a little Perl trick here:
#
# Open file to read information: 
# open FUTAUC, "$config{'basepath'}futures/$form{'ALIAS'}.new"; 
#
# Open file to overwrite all information: 
# open FUTAUC, ">$config{'basepath'}futures/$form{'ALIAS'}.new"; 
#
# Open file to append information: 
# open FUTAUC, ">>$config{'basepath'}futures/$form{'ALIAS'}.new";
########################################################################
			
						my $delimiter  = ":::";
						my $alias = $form{'ALIAS'};
						my (@bills) = &read_affil_file($form{'AFFREG'});						
						&oops('NEWAFFIL') unless (open(NEWAFFIL,">>$config{'basepath'}$config{'affildir'}/$form{'AFFREG'}.dat"));
						if ($config{'flock'}) {
						flock(NEW, 2);
						seek(NEW, 0, 2);
						}
						print NEWAFFIL "\n$alias$delimiter$nowtime";
#						my $bill;
#						foreach $bill (@bills) {print NEWAFFIL "\n$bill";}
						close(NEWAFFIL);
				
			# Add info to his debit/credit file too
						my $trans = "Affiliate Sign-up: $form{'ALIAS'}";
						my $ammount  = $config{'affil_amount'};
						my $transtype  = "Credit";
						my $delimiter  = ":::";
	#					$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
						my (@bills) = &read_affil_bill_file($form{'AFFREG'});
						my ($transaction, $amount, $type, $btime, $balance) = &read_affil_bill($form{'AFFREG'});
						my @firstbill =  &read_affil_bill($bills[0]);
						my $newtime = (time);
						my $newbalance = &parsebid($firstbill[4] + $ammount);
						&oops('NEWBILL') unless (open(NEWBILL,">$config{'basepath'}$config{'accounts'}/$form{'AFFREG'}.dat"));
						if ($config{'flock'}) {
						flock(NEW, 2);
						seek(NEW, 0, 2);
						}
						print NEWBILL "$trans$delimiter$ammount$delimiter$transtype$delimiter$newtime$delimiter$newbalance";
						my $bill;
						foreach $bill (@bills) {print NEWBILL "\n$bill";}
						close(NEWBILL);
			}
			
			require "sendemail.pl";
			&headers;
			print "$form{'ALIAS'}, <br>you should receive an e-mail to $form{'EMAIL'} in a few minutes.  It will contain your password needed to post or bid.  You may change your password once you receive it.  If you do not get an e-mail, please re-register.\n";
			&footers;
			&sendemail($form{'EMAIL'}, $config{'admin_address'}, 'Auction Password', "PLEASE DO NOT REPLY TO THIS E-MAIL.\n\nThank you for registering to use the online auctions at $config{'sitename'}!\n\nYour new password is: $newpass\nYour alias (as you entered it) is: $form{'ALIAS'}\n\nYour account has been credited $20.  You can use this credit to add extra's to your listings, such as bold face, attention grabbers or adding it to the Featured Items section.  There is NO COST to the seller for standard auctions, costs apply only to those extras mentioned previously.\n\nThank you for visiting!");
		}
		else {
			&headers;
			print "Sorry...  that alias is taken.  Hit back to try again!\n";
			&footers;
		}
	}
	else {
		&headers;
		print "User Registration is Not Implemented on This Server!  The System Administrator Did Not Specify a Registration Directory...\n";
		&footers;
	}
	


#-#############################################
# Sub: Random Password
# This generates psudo-random 8-letter
# passwords

sub randompass {
	srand(time ^ $$);
	my @passset = ('a'..'k', 'm'..'n', 'p'..'z', '2'..'9');
	my $randpass = "";
	for (my $i=0; $i<8; $i++) {
		$randpass .= $passset[int(rand($#passset + 1))];
	}
	return $randpass;
}

#-#############################################
# Sub: Headers
sub headers{
print "<HTML>";
print "<HEAD>";
print "<TITLE></TITLE>";
print "</HEAD>";
print "$config{'header'}";
print "$config{'navbar'}";			
}

#-#############################################
# Sub: Footers
sub footers{
print "$config{'navbar'}";
print "$config{'footer'}";
print "</BODY>";
print "</HTML>";
}

###Added for Multi-Aliasing####
#########################
sub multalias {
my $file;
opendir THEDIR, "$config{'basepath'}/$config{'regdir'}" || die "Unable to open directory: $!";
my @allfiles = readdir THEDIR;
closedir THEDIR;
foreach $file (@allfiles) {
if ($file =~ /\.dat/){ 
open REGFILE, "$config{'basepath'}/$config{'regdir'}/$file";
my($alias, $email, $bid, $time, $add1, $add2, $add3) = <REGFILE>;      # be sure to edit this to match the rest of your script
chomp($alias, $email, $bid, $time, $add1, $add2, $add3);	     # be sure to edit this to match the rest of your script
close REGFILE;
if ($form{'EMAIL'} =~ $email) {
&oops3
}
}
}
}

#-#############################################
sub read_affil_bill {
my $bill_string = shift;
my ($transaction, $amount, $type, $btime , $balance) = split(/:::/,$bill_string);
return ($transaction, $amount, $type, $btime , $balance);
}
#-#############################################
sub read_affil_file {
my $user = shift;
open FILE, "$config{'basepath'}$config{'affildir'}/$form{'AFFREG'}.dat";
my (@bills) = <FILE>;
close FILE;
chomp (@bills);
return (@bills);
}
#-#############################################
sub read_affil_bill_file {
my $user = shift;
open FILE, "$config{'basepath'}$config{'accounts'}/$form{'AFFREG'}.dat";
my (@bills) = <FILE>;
close FILE;
chomp (@bills);
return (@bills);
}
#############################################

##############################################
# Sub: Oops3!
# This generates an error message for multiple accounts and dies.

sub oops3 {
&headers;
print "This e-mail address, <b>$form{'EMAIL'}</b>, has already been
registered. ";
die "This e-mail address, <b>$form{'EMAIL'}</b>, has already been
registered. ";
&footers;
} 

###End Multi-Aliasing####