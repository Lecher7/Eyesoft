use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Process Changed Registration
# This modifies an account

	if ($config{'regdir'}) {
		&oops('Your must enter your alias so we can validate your account.') unless ($form{'ALIAS'});
		&oops('You must enter your old password so we can validate your account.') unless ($form{'OLDPASS'});
		if ($form{'ADDRESS1'}) {
			&oops('You must enter all of your contact information.  Please enter your street address.') unless ($form{'ADDRESS2'});
			&oops('You must enter all of your contact information.  Please enter your city, state, and zip.') unless ($form{'ADDRESS3'});
		}
		if ($form{'NEWPASS1'}) {
			&oops('Your new passwords do not match.') unless ($form{'NEWPASS2'} eq $form{'NEWPASS1'});
		}
		if (my ($password,$email,$add1,$add2,$add3,@past_bids) = &read_reg_file($form{'ALIAS'})) {
			$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
			&oops('Your old password does not match up.') unless ((lc $password) eq (lc $form{'OLDPASS'}));
			$form{'NEWPASS1'} = $password if !($form{'NEWPASS1'});
			$form{'EMAIL'} = $email if !($form{'EMAIL'});
			$form{'ADDRESS1'} = $add1 if !($form{'ADDRESS1'});
			$form{'ADDRESS2'} = $add2 if !($form{'ADDRESS2'});
			$form{'ADDRESS3'} = $add3 if !($form{'ADDRESS3'});
			&oops('We cannot open your account.  This could be a server data write issue.') unless (open NEWREG, ">$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat");
			print NEWREG "$form{'NEWPASS1'}\n$form{'EMAIL'}\n$form{'ADDRESS1'}\n$form{'ADDRESS2'}\n$form{'ADDRESS3'}";
			my $bid;
			foreach $bid (@past_bids) {
				print NEWREG "\n$bid";
			}
			close NEWREG;
			&headers;
			print "$form{'ALIAS'}, your information has been successfully changed.\n";
			&footers;
		}
		else {
			&headers;
			print "Sorry...  That Username is not valid.  If you do not have an alias (or cannot remember it) you should create a <A HREF=$ENV{'SCRIPT_NAME'}?action=reg>new account</A>.\n";
			&footers;
		}
	}
	else {
		&headers;
		print "User Registration is Not Implemented on This Server!  The System Administrator Did Not Specify a Registration Directory...\n";
		&footers;
	}
	
#-#############################################
# Sub: Headers
sub headers{
print "<HTML>";
print "<HEAD>";
print "<TITLE></TITLE>";
print "</HEAD>";
print "$config{'header'}";
print "$config{'navbar'}";			
}

#-#############################################
# Sub: Footers
sub footers{
print "$config{'navbar'}";
print "$config{'footer'}";
print "</BODY>";
print "</HTML>";
}	
	
1;