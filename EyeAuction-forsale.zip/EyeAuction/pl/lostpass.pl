use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
if ($form{'passaction'}){
	$form{'ALIAS'} =~ s/\W//g;
	$form{'ALIAS'} = lc($form{'ALIAS'});
	$form{'ALIAS'} = ucfirst($form{'ALIAS'});
	my ($password,$email,$add1,$add2,$add3,@past_bids) = &read_reg_file($form{'ALIAS'});
	require 'sendemail.pl';
	&sendemail($email, "Auction Password Request", $config{'admin_address'}, "Our system received a request for your password from IP address $ENV{'REMOTE_ADDR'} due to it being lost.\n\nYour password is: $password");
	my $message = "$form{'ALIAS'}... your password has been sent.";
    	print	&load_template ('passsent.html', {
				MESSAGE	=>	$message, 
				%globals
		});      
}
else {
    	print	&load_template ('lostpass.html', { 
				REMOTE_HOST	=>	$ENV{'REMOTE_ADDR'},
				%globals
		});      
}
1;