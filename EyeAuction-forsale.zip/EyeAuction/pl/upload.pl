#!/usr/bin/perl
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.

use strict;
use CGI;

$|=1;

my $version="V1.2";

## vvvvvvvvvvvvvvvvvvv MODIFY vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv

# the text database  of the user. The text database contains the | 
# separated items, namely  login|encrypted password|upload path
# example: muquit|fhy687kq1hger|/usr/local/web/upload/muquit
# if no path is specified, the file must be located in the cgi-bin directory.

my $g_upload_db="d:/EyeAuction/data/upload.dat";

# overwrite the existing file or not. Default is to overwrite
# chanage the value to 0 if you do not want to overwrite an existing file.
my $g_overwrite=1;

## ^^^^^^^^^^^^^^^^^^^ MODIFY ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^



#-------------- globals---------- STARTS ------------------
my $query=new CGI;
my $g_debug=0;


my $g_title="BidBunny.com File Upload";
my $g_upload_path='f:\Cards';

#-------------- globals----------  ENDS  ------------------


print $query->header;

# Java Script for form validation
#
my $JSCRIPT=<<EJS;

var returnVal=true;
var DEBUG=0;

//===========================================================================
// Purpose: check if field is blank or NULL
// Params:
//  field (IN)
//  errorMsg (IN - MODIFIED)
//  fieldTitle (IN)
// Returns:
//  errorMsg - error message
// Globals:
//  sets global variable (returnVal) to FALSE if field is blank or NULL
// Comments:
//  JavaScript code adapted from netscape software registration form.
//  ma_muquit\@fccc.edu, May-09-1997
//===========================================================================

function ValidateAllFields(obj)
{
   returnVal = true;
   errorMsg = "The required field(s):\\n";

   // make sure all the fields have values
   if (isSomeFieldsEmpty(obj) == true) 
   {
     // DISPLAY ERROR MSG
     displayErrorMsg();
     returnVal = false;
   }

   if (returnVal == true)
     document.forms[0].submit();
   else
     return (false);
}

//===========================================================================
function displayErrorMsg()
{
   errorMsg += "\\nhas not been completed.";
   alert(errorMsg);
}

//===========================================================================
function isSomeFieldsEmpty(obj)
{
    var
        returnVal3=false;



// check if login is null
   if (obj.userid.value == "" || obj.userid.value == null)
   {
       errorMsg += " " + "Userid" + "\\n";
       returnVal3=true;
   }

// check if Password is null

   if (obj.password.value == "" || obj.password.value == null)
   {
       errorMsg += " " + "Password" + "\\n";
       returnVal3=true;
   }

// check if upload_file is null
   if (obj.upload_file.value == "" || obj.upload_file.value == null)
   {
       errorMsg += " " + "Upload filename" + "\\n";
       returnVal3=true;
   }

   return (returnVal3);
}

EJS
;

# print the HTML HEADER
 &printHTMLHeader;

if ($query->path_info eq "/author")
{
    &printForm;
    &printAuthorInfo;
    return;
}

if ($query->param)
{
    &doWork();
}
else
{
    &printForm();
}

##-----
# printForm() - print the HTML form
##-----
sub printForm
{
###########################################################################
# Header
	print "<TABLE WIDTH=100\% BORDER=0><TR><TD VALIGN=TOP WIDTH=100\%>\n";
	print "<img src=\"/images/bidbunny.gif\">\n";
	print "</TD></TR></TABLE>\n";
	print "<table border=0 cellpadding=3 cellspacing=0 width=100\%>\n";
	print "<tr>\n";
	print "<td align=right valign=bottom bgcolor=#DCDCDC>\n";
	print "<A HREF=http://www.bidbunny.com?action=reg><font size=2 face=arial>\n";
	print "<b>Register</b></A> - <A HREF=http://www.bidbunny.com?action=new>\n";
	print "<font size=2 face=arial>\n";
	print "<b>Post New Item</b></A> - <A HREF=http://www.bidbunny.com?action=creg>\n";
	print "<font size=2 face=arial>\n";
	print "<b>Change Registration</b></A> - <A HREF=http://www.bidbunny.com?action=help>\n";
	print "<font size=2 face=arial><b>Help</b></A>\n";
	print "</td></tr></table>\n";

  print "<table border=0 cellpadding=2 cellspacing=0 width=100\%>\n";
	print "<tr>\n";
	print "<td bgcolor=#6082D2><font color=#FFFFFF size=4 face=Arial>\n";
	print "<b>BidBunny.com Auctions</b></font></td>\n";
	print "<td align=right bgcolor=#6082D2>&nbsp;<!-- SpaceID=18186925 loc=Z noad --> </td>\n";
	print "<td align=right bgcolor=#6082D2><table border=0 cellpadding=4>\n";
	print "<tr>\n";
	print "<td align=center bgcolor=#6082D2><font size=2>&nbsp;</font>\n";
	print "<font size=2 face=arial> </font><a href=http://www.bidbunny.com>\n";
	print "<font color=#FFFFFF size=2 face=arial>Auctions Home</font></a>\n";
	print "<font size=2 face=arial> </font><font size=2>&nbsp;</font>\n";
	print "</td></tr></table>\n";
	print "</td></tr></table>\n";
 ###############################################################################       
    print "<center>\n";
    print "<table border=0 bgcolor=\"#c0c0c0\" cellpadding=5 cellspacing=0>\n";

    print $query->start_multipart_form,"\n";

    #------------- userid
    print "<tr>\n";
    print "<td align=\"right\">\n";
    print "Userid:\n";
    print "</td>\n";
    
    print "<td>\n";
    print $query->textfield(-name=>'userid',
            -size=>20);
    print "</td>\n";
    print "</tr>\n";

    #------------- password
    print "<tr>\n";
    print "<td align=\"right\">\n";
    print "Password:\n";
    print "</td>\n";
    
    print "<td>\n";
    print $query->password_field(-name=>'password',
            -size=>20);
    print "</td>\n";
    print "</tr>\n";

    #------------- upload
    print "<tr>\n";
    print "<td align=\"right\">\n";
    print "Upload file:\n";
    print "</td>\n";
    
    print "<td>\n";
    print $query->filefield(-name=>'upload_file',
            -size=>30,
            -maxlength=>80);
    print "</td>\n";
    print "</tr>\n";



    #------------- submit
    print "<tr>\n";
    print "<td colspan=2 align=\"center\">\n";
    print "<hr noshade size=1>\n";
    print $query->submit(-label=>'Upload',
            -value=>'Upload',
            -onClick=>"return ValidateAllFields(this.form)"),"\n";
    print "</td>\n";
    print "</tr>\n";



    print $query->endform,"\n";

    print "</table>\n";
    print "If you do not have an upload account, please <a href=mailto:webmaster@bidbunny.com>request</a> one.\n";
    print "</center>\n";
    
# &footers;    
}



##------
# printHTMLHeader()
##------
sub printHTMLHeader
{
    print $query->start_html(
            -title=>"$g_title",
            -script=>$JSCRIPT);
#            -bgcolor=>"#ffffff",
#            -link=>"#ffff00",
#            -vlink=>"#00ffff",
#            -alink=>"#ffff00",
#            -text=>"#000000");
}

##-------
# doWork() - upload file 
##-------
sub doWork
{
    ##################
    my $em='';
    ##################


    # import the paramets into a series of variables in 'q' namespace
    $query->import_names('q');
    #  check if the necessary fields are empty or not
    $em .= "<br>You must specify your Userid!<br>" if !$q::userid;
    $em .= "You must specify your Password!<br>" if !$q::password;
    $em .= "You must select a file to upload!<br>" if !$q::upload_file;

    &printForm();
    if ($em)
    {
        &printError($em);
        return;
    }

    if (&validateUser() == 0)
    {
        &printError("Will not upload! Could not validate Userid: $q::userid");
        return;
    }

    # now upload file
    &uploadFile();

    if ($g_debug == 1)
    {
        my @all=$query->param;
        my $name;
        foreach $name (@all)
        {
            print "$name ->", $query->param($name),"<br>\n";
        }
    }
}

##------
# printError() - print error message
##------
sub printError
{
    my $em=shift;
    print<<EOF;
<center>
    <hr noshade size=1 width="80%">
        <table border=0 bgcolor="#000000" cellpadding=0 cellspacing=0>
        <tr>
            <td>
                <table border=0 width="100%" cellpadding=5 cellspacing=1>
                    <tr">
                        <td bgcolor="#ffefd5" width="100%">
                        
                        <font color="#ff0000"><b>Error -</b></font>
                        $em</td>
                    </tr>
                </table>
            </td>
        </tr>
            
        </table>
</center>
EOF
;
}

##--
# validate login name
# returns 1, if validated successfully
#         0 if  validation fails due to password or non existence of login 
#           name in text database
##--
sub validateUser
{
    my $rc=0;
    my ($u,$p);
    my $userid=$query->param('userid');
    my $plain_pass=$query->param('password');

    # open the text database
    unless(open(PFD,$g_upload_db))
    {
        &printError("Could not open user database");
        return;
    }
    
    # first check if user exist
    $g_upload_path='';
    while (<PFD>)
    {
        chomp;
        ($u,$p,$g_upload_path)=split('\|',$_);
        if ($userid eq $u)
        {
            $rc=1;
            last;
        }
    }
    close(PFD);

    if ($plain_pass ne $p)
    {
        $rc=0;
    }

    return ($rc);
}

##--------
# uploadFile()
##--------
sub uploadFile
{
    my $bytes_read=0;
    my $size='';
    my $buff='';
    my $start_time;
    my $time_took;
    my $filepath='';
    my $filename='';
    my $write_file='';

    $filepath=$query->param('upload_file');

    # James Bee" <JamesBee@home.com> reported that from Windows filename
    # such as c:\foo\fille.x saves as c:\foo\file.x, so we've to get the
    # filename out of it
    # look at the last word, hold 1 or more chars before the end of the line
    # that doesn't include / or \, so it will take care of unix path as well
    # if it happens, muquit, Jul-22-1999
    if ($filepath =~ /([^\/\\]+)$/)
    {
        $filename="$1";
    }
    else
    {
        $filename="$filepath";
    }
    # if there's any space in the filename, get rid of them
    $filename =~ s/\s+//g;

    $write_file="$g_upload_path" . "/" . "$filename";    

    print "Filename=$filename<br>\n" if $g_debug;
    print "Writefile= $write_file<br>\n" if $g_debug;

    if ($g_overwrite == 0)
    {
        if (-e $write_file)
        {
            &printError("File $filename exists, will not overwrite!");
            return;
        }
    }

    if (!open(WFD,">$write_file"))
    {
        &printError("Error opening file for writing. It's a permission problem. Make sure your web server has write permission to the upload directory");
        return;
    }

    $start_time=time();
    while ($bytes_read=read($filepath,$buff,2096))
    {
        $size += $bytes_read;
        binmode WFD;
        print WFD $buff;
    }

    print "size= $size<br>\n" if $g_debug;

    close(WFD);

    if ((stat $write_file)[7] <= 0)
    {
        unlink($write_file);
        &printError("Could not upload file: $filename");
        return;
    }
    else
    {
        $time_took=time()-$start_time;
    print<<EOF;
<center>
    <hr noshade size=1 width="90%">
        <table border=0 bgcolor="#c0c0c0" cellpadding=0 cellspacing=0>
        <tr>
            <td>
                <table border=0 width="100%" cellpadding=10 cellspacing=2>
                    <tr align="center">
                        <td bgcolor="#000099" width="100%">
                        <font color="#ffffff">
                        File 
                        <font color="#00ffff"><b>$filename</b></font> of size 
                        <font color="#00ffff"><b>$size</b></font> bytes is 
                        uploaded successfully!
                        </font>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
            
        </table>
</center>
EOF
;
    }
}

sub printAuthorInfo
{
    my $url="http://www.fccc.edu/users/muquit/";
    my $upl_url="$url" . "upload/upload.html";
    print<<EOF;
<center>
    <hr noshade size=1 width="90%">
        <table border=0 bgcolor="#c0c0c0" cellpadding=0 cellspacing=0>
        <tr>
            <td>
                <table border=0 width="100%" cellpadding=10 cellspacing=2>
                    <tr align="center">
                        <td bgcolor="#000099" width="100%">
                        <font color="#ffffff">
                        <a href="$upl_url">
                        upload.pl</a> $version by 
                        <a href="$url">Muhammad A Muquit</A>
                        </font>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
            
        </table>
</center>
EOF
;
}

#-#############################################
# Sub: Headers
sub headers{
print "<HTML>";
print "<HEAD>";
print "<TITLE></TITLE>";
print "</HEAD>";
	
}

#-#############################################
# Sub: Footers
sub footers{
# print "$config{'navbar'}";
# print "$config{'footer'}";
print "</BODY>";
print "</HTML>";
}

