#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#-#############################################
# Sub: Process Dutch Bid
# This processes new bids from a posted form


	my ($password, @userbids);
	if ($config{'regdir'} ne "") {
		&oops('Your alias could not be found!') unless ($password, $form{'EMAIL'}, $form{'ADDRESS1'}, $form{'ADDRESS2'}, $form{'ADDRESS3'}, @userbids) = &read_reg_file($form{'ALIAS'});
		$form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
		&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	}
	&oops('You must enter an alias to track your item.') unless ($form{'ALIAS'});
	&oops('You must enter a valid e-mail address.') unless ($form{'EMAIL'} =~ /^.+\@.+\..+$/);
	&oops('You must enter a valid bid amount.') unless ($form{'BID'} =~ /^(\d+\.?\d*|\.\d+)$/);
	$form{'BID'} = &parsebid($form{'BID'});
	&oops('You must enter your full name.') unless ($form{'ADDRESS1'});
	&oops('You must enter your street address.') unless ($form{'ADDRESS2'});
	&oops('You must enter you city, state, and zip.') unless ($form{'ADDRESS3'});
	&oops('You must enter a valid quantity.') if (($form{'QUANTITY'} != int($form{'QUANTITY'})) || ($form{'QUANTITY'} < 1));
	my ($title, $reserve, $inc, $desc, $image, $quantity, @bids) = &read_item_file($form{'CATEGORY'},$form{'ITEM'});
	&oops('The item number you entered cannot be found.  Maybe it has closed or it was moved since you last loaded the page.') if $title eq '';
	my $avail = 0;
	my (@sortbids,@highbids);
	my @firstbid = &read_bid($bids[0]);
	my $bidline;
	foreach $bidline (@bids) {
		my ($alias, $email, $bid, $time, $add1, $add2, $add3, $qtybid) = &read_bid($bidline);
		$avail += $qtybid if (($bid + $inc) > $form{'BID'});
	}
	my ($alias, $email, $bid, $time, $add1, $add2, $add3, $qtybid) = &read_bid($bids[$#bids]);
	if ((time <= $form{'ITEM'}) or (time <= (60 * $config{'aftermin'} + $time))) {
		&oops('Insuficient Items available for that bid. Sorry.') if ($form{'QUANTITY'} > ($quantity - $avail));
		&oops('Your bid is too low.  Sorry.') if ($form{'BID'} < $firstbid[2]);
		&oops('We are unable to append your bid to the auction item.  It appears to be a file write problem.') unless (open NEW, ">>$config{'basepath'}$form{'CATEGORY'}/$form{'ITEM'}.dat");
		if ($config{'flock'}) {
			flock(NEW, 2);
			seek(NEW, 0, 2);
		}
		my $nowtime = time;
		my $highbid ="\n$form{'ALIAS'}\[\]$form{'EMAIL'}\[\]$form{'BID'}\[\]$nowtime\[\]$form{'ADDRESS1'}\[\]$form{'ADDRESS2'}\[\]$form{'ADDRESS3'}\[\]$form{'QUANTITY'}";
		print NEW "$highbid";
		close NEW;
		print "<B>$form{'ALIAS'}, your bid has been placed on item number $form{'ITEM'} for $form{'QUANTITY'} items at \$$form{'BID'} each on ".scalar(localtime(time)).".</B><BR>You may want to print this notice as confirmation of your bid.<P>Go <A HREF=\"$ENV{'SCRIPT_NAME'}\?category=$form{'CATEGORY'}\&item=$form{'ITEM'}\">back to the item</A>\n";
		@sortbids = &get_dutch_bidders ($quantity,@bids);
		push @bids, $highbid;
		@highbids = &get_dutch_bidders ($quantity,@bids);
		my $oldbid;
		foreach $oldbid (@sortbids) {
			my $flag = 0;
			my ($oalias, $oemail, $obid, $otime, $oadd1, $oadd2, $oadd3, $oqtybid) = &read_bid($oldbid);		
			my $newbid;
			foreach $newbid (@highbids) {
				($alias, $email, $bid, $time, $add1, $add2, $add3, $qtybid) = &read_bid($newbid);		
				if (($alias eq $oalias) && ($time eq $otime) && ($bid eq $obid) && ($qtybid < $oqtybid)) {
					&sendemail($email, $config{'admin_address'}, "Outbid Notice!", "User $alias,\r\n\r\nYou have been outbid on $title\! However, you still have $qtybid items remaining.\r\n\r\nIf you want to place a higher bid, please visit:\r\nhttp://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?category=$form{'CATEGORY'}\&item=$form{'ITEM'}\r\n\r\nThe current high bid is \$$form{'BID'}.");
				}
				$flag++ if ($alias eq $oalias) && ($time eq $otime) && ($bid eq $obid);
			}
			if ($flag == 0) {
				&sendemail($oemail, $config{'admin_address'}, "Outbid Notice!", "User $oalias,\r\n\r\nYou have been outbid on $title\!  If you want to place a higher bid, please visit:\r\n\r\nhttp://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?category=$form{'CATEGORY'}\&item=$form{'ITEM'}\r\n\r\nThe current high bid is \$$form{'BID'}.");
			}
		}
		my $flag=0;
		my $userbid;
		foreach $userbid (@userbids) {
			$flag=1 if ("$form{'CATEGORY'}$form{'ITEM'}" eq $userbid);
		}
		if ($flag==0 && $config{'regdir'} ne "") {
			&oops('We could not open the registration file.  This could be a server write issue.') unless (open(REGFILE, ">>$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat"));
			print REGFILE "\n$form{'CATEGORY'}$form{'ITEM'}";
			close REGFILE;
		}
	}
	else {
		print "Item number $form{'ITEM'} in category $form{'CATEGORY'} is now closed!<BR>Sorry...\n";
	}


#-#############################################
# Sub: Get Highest Bidders (Dutch)

sub get_dutch_bidders {
	my ($quantity, @readbids) = @_;
	my $index = 0;
	my ($total, $bidline, @highbids, @sortbids);
	foreach $bidline (reverse @readbids) {		
		my @highbids = &read_bid($bidline);
		my $key = ($highbids[2] * 100000) + $index;
		$bidline =~ s/\n//g;
		my $sortbid = "$key\]\[$bidline\n";
		push @sortbids, $sortbid;
		$index++;
	}
	foreach $bidline (sort { int($b) <=> int($a) } @sortbids) {		
		my ($key, $readbids) = split /\]\[/,$bidline;
		$readbids =~ s/\n//g;
		my ($alias, $email, $bid, $time, $add1, $add2, $add3, $qtybid) = &read_bid("\n$readbids");
		$total += $qtybid;
		if (($quantity >= $total) && ($qtybid > 0)) {
			my $changebid = "\n$alias\[\]$email\[\]$bid\[\]$time\[\]$add1\[\]$add2\[\]$add3\[\]$qtybid";
			push @highbids, $changebid if ($qtybid > 0);
			} else {
			$qtybid -= ($total - $quantity) if (($total - $quantity) > 0);
			my $changebid = "\n$alias\[\]$email\[\]$bid\[\]$time\[\]$add1\[\]$add2\[\]$add3\[\]$qtybid";
			push @highbids, $changebid if ($qtybid > 0);
			}
		}
	return @highbids;
}
