use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
if ($form{'helpaction'} eq 'bid'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| Bidding |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=privacy>Privacy</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_bid.html', {
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'faq'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| FAQ |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=privacy>Privacy</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_faq.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'resolution'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| FAQ |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=privacy>Privacy</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_resolution.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'post'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| Posting |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=privacy>Privacy</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_post.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'privacy'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| Privacy |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_privacy.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'features'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| Privacy |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_features.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'fees'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| Privacy |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_fees.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'copy'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| Privacy |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_copy.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
elsif ($form{'helpaction'} eq 'guide'){
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| Privacy |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=terms>Terms of Use</A>";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_guide.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
else {
	my $helpbar .= "<P><P ALIGN=CENTER><FONT SIZE=-1>";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=bid>Bidding</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=post>Posting</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=faq>FAQ</A> |";
	$helpbar .= "| <A HREF=$ENV{'SCRIPT_NAME'}\?action=help&helpaction=privacy>Privacy</A> |";
	$helpbar .= "| Terms of Use";
	$helpbar .= "</FONT></P>";
    	print	&load_template ('help_terms.html', { 
				HELPBAR	=>	$helpbar,
				%globals
		});      
}
1;