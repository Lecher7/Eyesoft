use vars qw(%config %globals %category);
use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Configuration Section
# Edit these variables!
#
#
#
%category = (
	'antiques' => 'Antiques',
	'antiques/Pre_1900' => 'Antiques:Pre 1900',
	'antiques/Post_1900' => 'Antiques:Post 1900',
	'antiques/Other' => 'Antiques:Other',
	'books_movies_music' => 'Books, Movies & Music',
	'books_movies_music/Books' => 'Books, Movies & Music:Books',
	'books_movies_music/Movies' => 'Books, Movies & Music:Movies',
	'books_movies_music/Movies/Children' => 'Books, Movies & Music:Movies:Childrens',
	'books_movies_music/Movies/Comedy' => 'Books, Movies & Music:Movies:Comedy',
	'books_movies_music/Movies/Docu' => 'Books, Movies & Music:Movies:Documentary',
	'books_movies_music/Movies/Drama' => 'Books, Movies & Music:Movies:Drama',
	'books_movies_music/Movies/Horror' => 'Books, Movies & Music:Movies:Horror',
	'books_movies_music/Movies/Music' => 'Books, Movies & Music:Movies:Musical',
	'books_movies_music/Movies/Porn' => 'Books, Movies & Music:Movies:Porn',
	'books_movies_music/Movies/SciFi' => 'Books, Movies & Music:Movies:Sci-Fi',
	'books_movies_music/Movies/Other' => 'Books, Movies & Music:Movies:Other',
	'books_movies_music/Music' => 'Books, Movies & Music:Music',
	'books_movies_music/Music/Alternative' => 'Books, Movies & Music:Music:Alternative',
	'books_movies_music/Music/Blues' => 'Books, Movies & Music:Music:Blues',
	'books_movies_music/Music/ClassicRock' => 'Books, Movies & Music:Music:Classic Rock',
	'books_movies_music/Music/Classical' => 'Books, Movies & Music:Music:Classical',
	'books_movies_music/Music/Country' => 'Books, Movies & Music:Music:Country',
	'books_movies_music/Music/Metal' => 'Books, Movies & Music:Music:Metal',
	'books_movies_music/Music/Pop' => 'Books, Movies & Music:Music:Pop',
	'books_movies_music/Music/Rock' => 'Books, Movies & Music:Music:Rock',
	'books_movies_music/Music/Other' => 'Books, Movies & Music:Music:Other',
	'clothing' => 'Clothing',
	'clothing/mens' => 'Clothing:Mens',
	'clothing/womens' => 'Clothing:Womens',	
	'clothing/childrens' => 'Clothing:Childrens',	
	'coins_stamps' => 'Coins & Stamps',
	'coins_stamps/Coins' => 'Coins & Stamps:Coins',
	'coins_stamps/Stamps' => 'Coins & Stamps:Stamps',
	'coins_stamps/Paper_Money' => 'Coins & Stamps:Paper Money',
	'collectibles' => 'Collectibles',
	'computer_hardware' => 'Computer Hardware',
	'computer_software' => 'Computer Software',
	'consumer_electronics' => 'Consumer Electronics',
	'dolls_figures' => 'Dolls & Figures',
	'dolls_figures/Dolls' => 'Dolls & Figures:Dolls',
	'dolls_figures/Figures' => 'Dolls & Figures:Figures',
	'holidays' => 'Holidays',
	'holidays/Halloween' => 'Holidays:Halloween',
	'holidays/Christmas' => 'Holidays:Christmas',
	'holidays/Valentines' => 'Holidays:Valentines Day',
	'holidays/Other' => 'Holidays:Other',	
  'jewelry_gemstones' => 'Jewelry & Gemstones',
	'jewelry_gemstones/Gemstones' => 'Jewelry & Gemstones:Gemstones',	
	'jewelry_gemstones/Jewelry' => 'Jewelry & Gemstones:Jewelry',
	'jewelry_gemstones/Jewelry/Rings' => 'Jewelry & Gemstones:Jewelry:Rings',
	'jewelry_gemstones/Jewelry/Bracelets' => 'Jewelry & Gemstones:Jewelry:Bracelets',
	'music_instruments' => 'Music & Music Instruments',
	'music_instruments/Music' => 'Music & Music Instruments:Music',
	'music_instruments/Instruments' => 'Music & Music Instruments:Music Instruments',
	'photography' => 'Photography',
	'pottery_glass' => 'Pottery & Glass',
	'pottery_glass/Pottery' => 'Pottery & Glass:Pottery',
	'pottery_glass/Glass' => 'Pottery & Glass:Glass',
	'sports_outdoors' => 'Sports & Outdoors',
	'sports_outdoors/boating' => 'Sports & Outdoors:Boating',
	'sports_outdoors/camping' => 'Sports & Outdoors:Camping',
	'sports_outdoors/cycling' => 'Sports & Outdoors:Cycling',
	'sports_outdoors/exercise' => 'Sports & Outdoors:Exercise',
	'sports_outdoors/fishing' => 'Sports & Outdoors:Fishing',
	'sports_outdoors/golf' => 'Sports & Outdoors:Golf',
	'sports_outdoors/hunting' => 'Sports & Outdoors:Hunting',
	'sports_outdoors/skiing' => 'Sports & Outdoors:Skiing',
	'sports_outdoors/table_games' => 'Sports & Outdoors:Table Games',
	'sports_outdoors/team_sports' => 'Sports & Outdoors:Team Sports',
	'sports_outdoors/other' => 'Sports & Outdoors:Other',
	'sports_memorabilia' => 'Sports Memorabilia',
	'sports_memorabilia/Photos' => 'Sports Memorabilia:Photos',	
  'sports_memorabilia/Trading_Cards' => 'Sports Memorabilia:Trading Cards',
  'sports_memorabilia/Trading_Cards/Baseball' => 'Sports Memorabilia:Trading Cards:Baseball',
  'sports_memorabilia/Trading_Cards/Baseball/Boxes' => 'Sports Memorabilia:Trading Cards:Baseball:Boxes',
  'sports_memorabilia/Trading_Cards/Baseball/Packs' => 'Sports Memorabilia:Trading Cards:Baseball:Packs',
  'sports_memorabilia/Trading_Cards/Baseball/Rookies' => 'Sports Memorabilia:Trading Cards:Baseball:Rookie Cards',
  'sports_memorabilia/Trading_Cards/Baseball/Singles' => 'Sports Memorabilia:Trading Cards:Baseball:Singles',
  'sports_memorabilia/Trading_Cards/Baseball/Singles/Pre_1950' => 'Sports Memorabilia:Trading Cards:Baseball:Singles: Pre 1950',
  'sports_memorabilia/Trading_Cards/Baseball/Singles/1950-1990' => 'Sports Memorabilia:Trading Cards:Baseball:Singles: 1950 - 1990',
  'sports_memorabilia/Trading_Cards/Baseball/Singles/Current' => 'Sports Memorabilia:Trading Cards:Baseball:Singles: Current',
  'sports_memorabilia/Trading_Cards/Basketball' => 'Sports Memorabilia:Trading Cards:Basketball',
	'sports_memorabilia/Trading_Cards/Basketball/Boxes' => 'Sports Memorabilia:Trading Cards:Basketball:Boxes',
  'sports_memorabilia/Trading_Cards/Basketball/Packs' => 'Sports Memorabilia:Trading Cards:Basketball:Packs',
  'sports_memorabilia/Trading_Cards/Basketball/Rookies' => 'Sports Memorabilia:Trading Cards:Basketball:Rookie Cards',
  'sports_memorabilia/Trading_Cards/Basketball/Singles' => 'Sports Memorabilia:Trading Cards:Basketball:Singles',
  'sports_memorabilia/Trading_Cards/Basketball/Singles/Pre_1950' => 'Sports Memorabilia:Trading Cards:Basketball:Singles: Pre 1950',
  'sports_memorabilia/Trading_Cards/Basketball/Singles/1950-1990' => 'Sports Memorabilia:Trading Cards:Basketball:Singles: 1950 - 1990',
  'sports_memorabilia/Trading_Cards/Basketball/Singles/Current' => 'Sports Memorabilia:Trading Cards:Basketball:Singles: Current',
  'sports_memorabilia/Trading_Cards/Football' => 'Sports Memorabilia:Trading Cards:Football',
	'sports_memorabilia/Trading_Cards/Football/Boxes' => 'Sports Memorabilia:Trading Cards:Football:Boxes',
  'sports_memorabilia/Trading_Cards/Football/Packs' => 'Sports Memorabilia:Trading Cards:Football:Packs',
  'sports_memorabilia/Trading_Cards/Football/Rookies' => 'Sports Memorabilia:Trading Cards:Football:Rookie Cards',
  'sports_memorabilia/Trading_Cards/Football/Singles' => 'Sports Memorabilia:Trading Cards:Football:Singles',
  'sports_memorabilia/Trading_Cards/Football/Singles/Pre_1950' => 'Sports Memorabilia:Trading Cards:Football:Singles: Pre 1950',
  'sports_memorabilia/Trading_Cards/Football/Singles/1950-1990' => 'Sports Memorabilia:Trading Cards:Football:Singles: 1950 - 1990',
  'sports_memorabilia/Trading_Cards/Football/Singles/Current' => 'Sports Memorabilia:Trading Cards:Football:Singles: Current',
	'sports_memorabilia/Trading_Cards/Hockey' => 'Sports Memorabilia:Trading Cards:Hockey',
  'sports_memorabilia/Trading_Cards/Hockey/Boxes' => 'Sports Memorabilia:Trading Cards:Hockey:Boxes',
  'sports_memorabilia/Trading_Cards/Hockey/Packs' => 'Sports Memorabilia:Trading Cards:Hockey:Packs',
  'sports_memorabilia/Trading_Cards/Hockey/Rookies' => 'Sports Memorabilia:Trading Cards:Hockey:Rookie Cards',
  'sports_memorabilia/Trading_Cards/Hockey/Singles' => 'Sports Memorabilia:Trading Cards:Hockey:Singles',
  'sports_memorabilia/Trading_Cards/Hockey/Singles/Pre_1950' => 'Sports Memorabilia:Trading Cards:Hockey:Singles: Pre 1950',
  'sports_memorabilia/Trading_Cards/Hockey/Singles/1950-1990' => 'Sports Memorabilia:Trading Cards:Hockey:Singles: 1950 - 1990',
  'sports_memorabilia/Trading_Cards/Hockey/Singles/Current' => 'Sports Memorabilia:Trading Cards:Hockey:Singles: Current',
  'sports_memorabilia/Trading_Cards/Other' => 'Sports Memorabilia:Trading Cards:Other Sports',  
	'toys' => 'Toys',
	'toys/Electronic' => 'Toys:Electronic',
	'toys/Diecast' => 'Toys:Diecast',
	'toys/Handheld' => 'Toys:Hand Held',
	'toys/Video_Games/Atari' => 'Toys:Video Games:Atari',
	'toys/Video_Games/Sega' => 'Toys:Video Games:Sega',
	'toys/Video_Games/Sony' => 'Toys:Video Games:Sony',
	'toys/Video_Games/Nintendo' => 'Toys:Video Games:Nintendo',
	'toys/Video_Games/Other' => 'Toys:Video Games:Other',
	'toys/Video_Games' => 'Toys:Video Games',
	'toys/Action_Figures' => 'Toys:Action Figures',
	'toys/Stuffed' => 'Toys:Stuffed',
	'toys/Board' => 'Toys:Board Games',
	'toys/Other' => 'Toys:Other',
	'miscellaneous' => 'Miscellaneous',
#	'other_bands' => 'Other Bands',
	);
my $bottombanner =<<"EOF";
<center><a href="http://www.homedepot.com">
<img src="/images/depot.gif" border="0" 
alt="Home Depot" ></a></center>
EOF
my $topbanner =<<"EOF";
EOF

my $header =<<"EOF";
<BODY TEXT=#000000 BGCOLOR=#FFFFFF LINK=#000088 VLINK=#000088 ALINK=#000088>
	<TABLE WIDTH=100\% BORDER=0><TR><TD VALIGN=TOP WIDTH=100\%>
	<img src=/images/bidbunny.gif>



	</TD></TR></TABLE>
	<table border="0" cellpadding="3" cellspacing="0"
	        width="100%">
	            <tr>
	                <td align="right" valign="bottom" bgcolor="#DCDCDC">
	                <A HREF=$ENV{'SCRIPT_NAME'}?action=reg><font size="2"
                face="arial"><b>Register</b></A> - 
	                <A HREF=$ENV{'SCRIPT_NAME'}?action=new><font size="2"
                face="arial"><b>Post New Item</b></A> - 
	                <A HREF=$ENV{'SCRIPT_NAME'}?action=creg><font size="2"
                face="arial"><b>Change Registration</b></A> - 
	                <A HREF=$ENV{'SCRIPT_NAME'}?action=help><font size="2"
                face="arial"><b>Help</b></A> 
                        </td>
	            </tr>
        </table>
        <table border="0" cellpadding="2" cellspacing="0"
	        width="100%">
	            <tr>
	                <td bgcolor="#6082D2"><font color="#FFFFFF"
	                size="4" face="Arial"><b>YourSite.com Auctions</b></font></td>
	                <td align="right" bgcolor="#6082D2">&nbsp;<!-- SpaceID=18186925 loc=Z noad --> </td>
	                <td align="right" bgcolor="#6082D2"><table
	                border="0" cellpadding="4">
	                    <tr>
	                        <td align="center" bgcolor="#6082D2"><font
	                        size="2">&nbsp;</font><font size="2"
	                        face="arial"> </font><a
	                        href="eyeauction.cgi"><font
	                        color="#FFFFFF" size="2" face="arial">Auctions
	                        Home</font></a><font size="2"
	                        face="arial"> </font><font size="2">&nbsp;</font>
	                        </td>
	                    </tr>
	                </table>
	                </td>
	            </tr>
        </table>
	$topbanner
EOF
my $footer =<<"EOF";
        
<P>

<CENTER><FONT SIZE=-1><I>
Site designed by <A HREF=http://www.aftk.com>Eye Software Solutions</A>
</I></FONT><p>
</CENTER>
$bottombanner

</BODY>
</HTML>
EOF
my $picicon = "<img src = \"../images/pic2.gif\">";
my $newicon = "<img src = \"../images/new.gif\">";
my $hoticon = "<img src = \"../images/hot.gif\">";
my $grabber1 = "<IMG SRC=\"../images/auction/siren.gif\">";
my $grabber2 = "<IMG SRC=\"../images/auction/eyes.gif\">";
my $grabber3 = "<IMG SRC=\"../images/auction/hand.gif\">";
my $grabber4 = "<IMG SRC=\"../images/auction/arrow_red.gif\">";
my $grabber5 = "<IMG SRC=\"../images/auction/box.gif\">";
my $grabber6 = "<IMG SRC=\"../images/auction/cdrom.gif\" width=26 height=22>";
my $grabber7 = "<IMG SRC=\"../images/auction/click.gif\" width=26 height=22>";
my $grabber8 = "<IMG SRC=\"../images/auction/clock.gif\" width=26 height=22>";
my $grabber9 = "<IMG SRC=\"../images/auction/cool1.gif\" width=26 height=22>";
my $grabber10 = "<IMG SRC=\"../images/auction/hot1.gif\" width=26 height=22>";
my $grabber11 = "<IMG SRC=\"../images/auction/dot.gif\">";
my $grabber12 = "<IMG SRC=\"../images/auction/star.gif\" width=26 height=22>";
my $metadesc = "YourSite.com auction site";
my $metakeywords = "auction, auction, auction, free, free, free, sell, sell, sell, cool";
my $newokay = 1;
my $regdir = 1;
my $closedir = 1;
my $descicon = "../images/descicon.gif";
my $bidicon = "../images/bidicon.gif";

my $navbar .= "";
$navbar .= "";
# my $navbar .= "<center><h3><A HREF=$ENV{'SCRIPT_NAME'}>Category List</A>&nbsp";
# $navbar .= " <A HREF=$ENV{'SCRIPT_NAME'}?action=new>Post New Item</A>&nbsp" if ($newokay);
# $navbar .= " <A HREF=$ENV{'SCRIPT_NAME'}?action=reg>New Registration</A>&nbsp  <A HREF=$ENV{'SCRIPT_NAME'}?action=creg>Change Registration</A>&nbsp " if ($regdir);
# $navbar .= " <A HREF=$ENV{'SCRIPT_NAME'}?action=help>Help</A>&nbsp";
# $navbar .= "</h3></center>";

%config = (
		pic 				=>	$picicon,
		new 				=>	$newicon,
		siren                   =>    $grabber1,
		eyes                    =>    $grabber2,
		hand                    =>    $grabber3,
    arrowred                =>    $grabber4,
    box                     =>    $grabber5,
		cdrom                   =>    $grabber6,
		click                   =>    $grabber7,
    clock                   =>    $grabber8,
    cool1                   =>    $grabber9,
		hot1                    =>    $grabber10,
		dot                     =>    $grabber11,
    star                    =>    $grabber12,
    newdays 			=>	1,
		goinghours 			=>	3,
		hot 				=>	$hoticon,
		hotnum				=>	5,
		navbar				=>	$navbar,
#		flock				=>	1,
		newokay				=>	$newokay,
		aftermin			=>	0,
		footer				=>	$footer,
		header				=>	$header,
		tableborder0 		=>	0,
		tableborder1 		=>	1,
		tablecellspace0 	=>	0,
		tablecellpad0 		=>	0,
		tablecellpad1 		=>	1,
		colortablerowodd 	=>	'#FFFFFF',
		colortableroweven 	=>	'#EEEEEE',
		colortablehead 		=>	'#66A8CC',
		colortablehead2 	=>	'#6082D2',
		colortablebody 		=>	'#FFFFFF',
		sitename			=>	'YourSite.com Online Auction',
		sitename2			=>	'YourSite.com',
		scripturl 			=>	'www.YourSite.com',
		closesite       =>  'N', # Close the site for maintenance
		headerpicpath		=>  'C:/EyeAuction/images/', # This will need to be changed to your path
		headerpic				=>  'headerpic.jpg',
		templatepath 		=>	'C:/EyeAuction/templates', # This will need to be changed to your path
		basepath 			=>	'C:/EyeAuction/', # This will need to be changed to your path
		closedir			=>	'closed/',
		deletedir			=>	'deleted/',	
		upldir				=>	'data',
		upldir2       =>  'C:/EyeAuction,  # This will need to be changed to your path		
#####################################
# Allow Seller To...
# 0 = Set the Buy-it Now Price at any price.
# 1 = Set the Buy-it Now Price at or below the Reserve Price.
# 2 = Set the Buy-it Now Price at or above the Reserve Price.
    buynow        => '0',	
    buyfee        => '0.00', # Amount to charge for Buy-It-Now auctions
#####################################
# Affiliate info
		affildir      =>  'affiliates',  # Affiliates directory
		affil_amount  => '2.00', # Amount to credit for a new registration   
#####################################				
		counterpath			=>	'Counter',
		newinc			=>	'0.25', # Default incriment for new auction item		
		regdir				=>	'reg',
		featureditems => 4, # Number of Featured Items to display
#####################################
# All these are used for accounting purposes
    accounts      =>  'user_accounts',
    paypal 				=> '1',  # Take PayPal Payments 1 =yes 0-no
    ppemail				=> 'yourname@yoursite.com', # Your PayPal Email Address
    verisign 			=> '0',  # Take Verisign Payments 1 =yes 0-no
    vsid 					=> 'none', # Your Verisign hps ID    
    open_amount    => '20.00', # Amount to open a user account with
    flock 				=> '0', # Use File Lock 1=yes 0= no DO NOT USE WITH NT
    pre_curr				=>	'$',
    count_amount  => '0.00', # Amount to charge for hit counter
    feat_amount 	=> '1.00', # Amount to charge for a Featured listing
		bold_amount 	=> '0.50', # Amount to charge for a Bold listing
		grabbercharge => '0.25', # Attention Grabber fee
# If starting is less than this:
		post_range_1 	=> '100.00',
# Charge this fee:
		post_fee_1 		=> '0.00',

# If starting is more than this:
		post_range_2 	=> '100.00',
# Charge this fee:
		post_fee_2		=> '0.00',

# If starting is more than this:
		post_range_3 	=> '200.00',
# Charge this fee:
		post_fee_3 		=> '0.00',

# If starting is more than this:
		post_range_4 	=> '300.00',
# Charge this fee:
		post_fee_4 		=> '0.00',

# If starting is more than this:
		post_range_5 	=> '400.00',
# Charge this fee:
		post_fee_5 		=> '0.00',

# If starting is more than this:
		post_range_6 	=> '500.00',
# Charge this fee:
		post_fee_6 		=> '0.00',

# If closing price is less than this:
		range_1 			=> '100.00',
# Charge this percentage: (i.e. '0.060', # 6%)
		close_range_fee1 => '0.000', # 6%

# If closing price is more than this: 
		range_2 			=> '200.00',
# Charge this percentage:
		close_range_fee2 => '0.000', # 5%

# If closing price is more than this:
		range_3 			=> '300.00',
# Charge this percentage:
		close_range_fee3 => '0.000', # 4%

# If closing price is more than this:
		range_4 			=> '400.00',
# Charge this percentage:
		close_range_fee4 => '0.000', # 3%

# If closing price is more than above and less than this:
		range_5 			=> '500.00',
# Charge this percentage:
		close_range_fee5 => '0.000', # 2.5%
# If closing price is more than above Charge this percentage:
		close_range_fee6 => '0.000', # 1.5%
###################################
		feeddir				=>	'feed',
		adminpass			=>	'auction',
		#mailprog			=>	'/usr/sbin/sendmail',
		mailhost			=>	'mail.yoursite.com',
		admin_address		=>	'webmaster@yoursite.com',
		
		trackhot => 10, #This is the number of bids before the item becomes "HOT"
		trackhotpic => '<IMG SRC=../pics/hot.gif border=0>',
		trackpic => '<IMG SRC=../pics/pic.gif border=0>',
		trackreservemetpic => '<IMG SRC=../pics/reservemet.gif border=0>',
		tracknoreservepic => '<IMG SRC=../pics/noreserve.gif border=0>',
		trackicon => '<IMG SRC=../pics/watch.gif border=0>',
		trackcolorevenrow => '#FFFFFF',
		trackcoloroddrow => '#EEEEEE',
		trackpath => 'track/',
);
%globals = (
		TITLE				=>	$config{'sitename'},
		TITLE2				=>	$config{'sitename2'},
		HEADER				=>	$config{'header'},
		HEADERPICPATH	=>	$config{'headerpicpath'},
		HEADERPIC			=>	$config{'headerpic'},
		FOOTER				=>	$config{'footer'},
		DESCICON			=>	$descicon,
		BIDICON				=>	$bidicon,
		NAVBAR				=>	$config{'navbar'},
		META_DESC			=> 	$metadesc,
		META_KEYWORDS		=> 	$metakeywords,
		SCRIPT_NAME			=>	$ENV{'SCRIPT_NAME'},
		SCRIPTURL			=>	$config{'scripturl'},
		TABLECELLSPACE0		=>	$config{'tablecellspace0'},
		TABLECELLPAD0		=>	$config{'tablecellpad0'},
		TABLECELLPAD1		=>	$config{'tablecellpad1'},
		TABLEBORDER0		=>	$config{'tableborder0'},
		TABLEBORDER1		=>	$config{'tableborder1'},
		COLORTABLEHEAD		=>	$config{'colortablehead'},
		COLORTABLEHEAD2		=>	$config{'colortablehead2'},
		COLORTABLEBODY		=>	$config{'colortablebody'},
);
1;