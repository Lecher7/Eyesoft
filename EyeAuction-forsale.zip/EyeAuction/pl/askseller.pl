use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#------------------------------------------------------#
# Ask The Seller a Question
# This starts the process
#------------------------------------------------------#
	&oops("User $form{'ALIAS'} could not be found.") unless (my ($password,$email,$add1,$add2,$add3,@past_bids) = &read_reg_file($form{'ALIAS'}));
    print	&load_template ('askseller.html', { 
	   SELLER		=>	  $form{'ALIAS'},
	   CATTREE		=>	  $form{'category'},
       ALIAS	  	=>    $form{'ALIAS'},
	   ITEMNUM		=>	  $form{'item'},        
				%globals
	});      
1;



