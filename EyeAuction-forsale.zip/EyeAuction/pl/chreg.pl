use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Change Registration
# This allows a user to change information


    print	&load_template ('chreg.html', { 
				TITLE	=>	"Change Registration",
				%globals
	});      
1;

