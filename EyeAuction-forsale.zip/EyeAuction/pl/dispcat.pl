use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Display List Of Categories
# This creates a "nice" list of categories.
	my ($key, $maincat, $categorytable, $listtable, %maincats);
	my $stats = &stats;
	&listtable;
#	&disp_random(2);
	&autoclose;
	&maincats;
	foreach $maincat (sort keys %maincats) {
			$categorytable .= "<TR><TD BGCOLOR=$config{'colortablebody'}><A HREF=$ENV{'SCRIPT_NAME'}\?category=$maincat&listtype=current&level=0>$category{$maincat}</A> <small>($maincats{$maincat})</small></TD></TR>";
			$listtable = &listtable;
#			$disp_random = &disp_random;
	}
	

    print	&load_template ('dispcat.html', { 
				CATEGORYTABLE => $categorytable,
				LISTTABLE => $listtable,
#				LISTTABLE => $disp_random,
				STATS => $stats,
				%globals
	});      
##############################################
# Sub: Get Main Categories 

sub maincats {
	my @data;
	foreach $key (sort keys %category) {
		my @catarray = split (/\//,$key);
			umask(000);  # UNIX file permission junk
			mkdir("$config{'basepath'}$key", 0777) unless (-d "$config{'basepath'}$key");
			opendir DIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
			$maincats{$catarray[0]} = $maincats{$catarray[0]} + scalar(grep -T, map "$config{'basepath'}$key/$_", readdir DIR);
			closedir DIR;
	}
}
#######################################
# Copy and paste this sub to the script
# to get stats for your site
#######################################
sub stats {
# Count Registered Users

my $numusers = 0;       
opendir THEDIR, "$config{'basepath'}$config{'regdir'}";
my @allfiles = grep -T, map "$config{'basepath'}$config{'regdir'}/$_", readdir THEDIR;
closedir THEDIR;
my $numusers = $numusers + @allfiles;        

# Count Open Auctions

my $key;
my $totalfiles = 0;
foreach $key (sort keys %category) {
opendir THEDIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
my @allfiles = grep -T, map "$config{'basepath'}$key/$_", readdir THEDIR;
closedir THEDIR;
$totalfiles = $totalfiles + @allfiles;

}

#$stats .= "<center><b>There are currently<FONT face="arial" COLOR=\"ff0000\"> $numusers</FONT>
#registered users and<font face="arial" color=\"ff0000\"> $totalfiles</font><font color=\"000000\"> open auctions.</font></b></center><br>\n";

$stats .= "<pre><font face = \"arial\">There are currently:
      <b>Registered Users: </font></b><FONT face = \"arial\" COLOR=\"ff0000\"> $numusers</FONT>
   <b><font face = \"arial\">Open Auctions: </font></b><font face = \"arial\" color=\"ff0000\"> $totalfiles</font>
</pre><br>\n";

}


#-#############################################
# Sub: Display Random Items
# This creates a "nice" list of random items.

sub disp_random {
#	my $max_display;
#	$max_display = 1 unless ($max_display = $_[0]);
##	print "<TABLE BORDER=1 WIDTH=100\%>\n";
##	print "<TR><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Category</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Closes</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Num Bids</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>High Bid</B></TD></TR>\n";
#	my @allfiles = ();
#	my $key;
#foreach $key (sort keys %category) {
#	opendir THEDIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
#	@allfiles = grep -T, map "$config{'basepath'}$key/$_", sort { int($a) <=> int($b) } (readdir THEDIR);
#	closedir THEDIR;
#	}
#	my ($file, $disp_random);
#	my @cellcolor=($config{'colortablerowodd'},$config{'colortableroweven'});
#	my $color = 0;
##	$max_display = ($#allfiles + 1) if ($max_display > ($#allfiles + 1));
#	print "Max1: $max_display\n";
#	while ($max_display > 0) {
#		$file = splice (@allfiles, (int rand ($#allfiles + 1)), 1); 
#		$file =~ s/^$config{'basepath'}$key\///;
#		$file =~ s/\.dat$//;
#		($key, $file) = split /\//, $file;
#		my ($title, $reserve, $inc, $desc, $image, $grabber, $catfeat, $bolditem, @bids) = &read_item_file($key,$file);
#		if ($title ne '') {
#			my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
#			my @closetime = localtime($file);
#			$closetime[4]++;
#			my $rowcolor = $cellcolor[$color];
#			my $timeleft = &timeleft($file);		
#			$disp_random .= "<TR><font size=2<TD BGCOLOR=$rowcolor ALIGN=LEFT><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$title</A>";
##			$disp_random .= "$config{'pic'}" if ($image);
##			$disp_random .= "$config{'new'}" if (($sellertime + (86400 * $config{'newdays'})) > time);
##			$disp_random .= "$config{'hot'}" if ($#bids >= $config{'hotnum'});
#			$disp_random .= "</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>\$$bid</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$#bids</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$timeleft</font></TD></TR>\n";			
##			print "<TR><TD BGCOLOR=$config{'colortablebody'}><A HREF=$config{'auctionurl'}\?category=$key>$category{$key}</A><TD BGCOLOR=$config{'colortablebody'}><A HREF=$config{'auctionurl'}\?category=$key\&item=$file>$title</A>";
##			print " <FONT COLOR=#3333FF SIZE=-1>[PIC]</FONT>" if ($image);
##			print "</TD><TD BGCOLOR=$config{'colortablebody'}>$closetime[4]/$closetime[3]</TD><TD BGCOLOR=$config{'colortablebody'}>$#bids</TD><TD BGCOLOR=$config{'colortablebody'}>\$$bid</TD></TR>\n";
#		}
#	print "Max: $max_display\n";
#	$max_display--;
#	}
##	print "</TABLE>\n";
#	if (!$disp_random){
#			$disp_random = "<TR><TD>No Featured Listings</TD><TD></TD><TD></TD><TD></TD></TR>";
#		}
#		
#	return $disp_random;
}

##############################################
# Sub: Featured Items
# If user chooses to feature their item, then the last 9 auctions
# with that option chosen should appear in the "Featured Items" section
# on the front page of the site
#
# Use the 'X' variable to determine how many items to feature
#
sub listtable {
my ($key, @allfiles, $listtable, $X, $Y);
$X = $config{'featureditems'};
foreach $key (sort keys %category) {
	opendir THEDIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
	@allfiles = grep -T, map "$config{'basepath'}$key/$_", sort { int($a) <=> int($b) } (readdir THEDIR);
	closedir THEDIR;
	my ($file,);
	my @cellcolor=($config{'colortablerowodd'},$config{'colortableroweven'});
	my $color = 0;
	foreach $file (@allfiles) {
		$file = splice (@allfiles, (int rand ($#allfiles + 1)), 1); 
		$file =~ s/^$config{'basepath'}$key\///;
		$file =~ s/\.dat$//;
#		($key, $file) = split /\//, $file;	
	
#		$file =~ s/^$config{'basepath'}$key\///;
#		$file =~ s/\.dat$//;
		if (my ($iteminfo, $image, $desc, @bids) = &read_item_file($key,$file)) {
			my @itemvals = split(/:::/, $iteminfo);
			my ($selleralias, $selleremail, $sellerbid, $sellertime, $selleradd1, $selleradd2, $selleradd3) = &read_bid($bids[0]);
			if ($itemvals[5] eq "CATFEATYES"){
			  if ($X > 0) {
					my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
					my @closetime = localtime($file);
					$closetime[4]++;
					my $rowcolor = $cellcolor[$color];
					my $timeleft = &timeleft($file);
					$listtable .= "<TR><font size=-1><TD BGCOLOR=$rowcolor ALIGN=LEFT><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$itemvals[0]</A>";
					$listtable .= "$config{'pic'}" if ($image);
					$listtable .= "$config{'new'}" if (($sellertime + (86400 * $config{'newdays'})) > time);
					$listtable .= "$config{'hot'}" if ($#bids >= $config{'hotnum'});
					$listtable .= "</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>\$$bid</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$#bids</TD><TD BGCOLOR=$rowcolor ALIGN=CENTER>$timeleft</TD></font></TR>\n";
					$color = int(!($color));
			    $X--					
				}
			}
		}
	}
}
	if (!$listtable){
		$listtable = "<TR><TD>No Featured Listings</TD><TD></TD><TD></TD><TD></TD></TR>";
	}else{
		$listtable .= "<TR><TD ALIGN=LEFT><A HREF=$ENV{'SCRIPT_NAME'}\?action=featured>All Featured Items</A></TD></TR>\n";	
	}
	
	return $listtable;
 
}
##############################################
# Sub: Automate Close Auctions 
# This allows the script to close all items that
# have passed their closing time, w/o having
# to go to each item seperately
#
# Figure out a way to loop through the closed items and move them to a folder for
# deleting once a month has passed since closing time.  Use this code:
#
# if $file le localtime(time - (86400 * 31) ){ 
#   rename "myfile.txt","trash/myfile.txt";
# }

# &autorelist;

sub autoclose {
require "sendemail.pl";
mkdir("$config{basepath}$config{closedir}", 0777) unless (-d "$config{basepath}$config{closedir}/$key");             
# my ($iteminfo, $image, $desc, @lastbid, @firstbid, $key, @allfiles, $file, $bid, @bids, @thebid, $bidtime, $reservemsg, $nowtime, $closetime, $numauct);
# my ($bidstart, $repostseconds);
	my $doit = 0;		
	my ($iteminfo, $delim, $delim2, $newdays);
	my ($key, $bid, $bidtime, $nosellreason, $opening, $opentext, $bidstart, $repostseconds, $repost, $new);
	my ($resend, $numauct, $winnermessage, $sellermessage, $highbidmessage, $reservemsg, $file, @lastbid, @firstbid);
	my ($numfile, $closetime, @allfiles, @thebid, $nowtime, $senderrormsg);
	my ($title, $reserve, $inc, $desc, $image, $location, $payments, $shipping, $condition, $relist, @bids);
	my ($alias, $email, $maxbid, $time, $name, $address, $city, $state, $postal, $country, $currentbid);

 foreach $key (sort keys %category) {
   mkdir("$config{basepath}$config{closedir}$key", 0777) unless (-d "$config{basepath}$config{closedir}/$key");             
   opendir THEDIR, "$config{basepath}$key" || die "Unable to open directory: $!";
        @allfiles = readdir THEDIR;
        closedir THEDIR;
          foreach $file (sort { int($a) <=> int($b) } @allfiles) {
            if (time > $file) {
              if (-T "$config{basepath}$key/$file") {
              

              
                open THEFILE, "$config{basepath}$key/$file";
                ($iteminfo, $image, $desc, @bids) = <THEFILE>;
                close THEFILE;
                chomp($iteminfo, $image, $desc, @bids);
                @firstbid = split(/\[\]/,$bids[0]);
                @lastbid = split(/\[\]/,$bids[$#bids]);
                my @itemvals = split(/:::/, $iteminfo);
                $nowtime = localtime(time);
                $closetime = localtime($file);
                
					#--Relist Section Loop---------------------------------#
					
					if ($itemvals[8] > 0) {
#					
						$bidstart = localtime($firstbid[3]);
						$repostseconds = ($file - $firstbid[3]);
#						print "Close: $closetime - Bidstart: $bidstart - Repost: $repostseconds\n";
						$newdays = $repostseconds/86400;
						
						#--No bids placed section------------------------------#
#						if ($firstbid[0] eq $lastbid[0])  {
#							$nosellreason = "No bids were placed";
#							$doit = 1;
							$new = ($repostseconds + time);
							$new = ($repostseconds + time) until (!(-f "$config{'basepath'}$form{'CATEGORY'}/$new.dat"));

#							$senderrormsg = "
#							An item file could not be renamed during the AutoClose Routine.
#							$config{'basepath'}$key/$numfile.dat TO $config{'basepath'}$key/$new.dat";
#	
#							&sendemail("$config{'admin_address'}", 'nobody', 'Auction Site ERROR', "$senderrormsg") unless rename("$config{'basepath'}$key/$file", "$config{'basepath'}$key/$new.dat");
#
#							&oops('incorrect alias') unless (open(REGFILE, ">>$config{'basepath'}$config{'regdir'}/$firstbid[0].dat"));
#							print REGFILE "\n$key$new";
#							close REGFILE;
#						}
#						#--END: No bids placed section-------------------------#


#						#--Reserve or opening bid not met section--------------#
#						elsif ($lastbid[2] < $opening) {
#							$nosellreason = "$opentext was not met, highest bid was \$$lastbid[2]";
#							$doit = 1;
#							$new = ($repostseconds + time);
#							$new = ($repostseconds + time) until (!(-f "$config{'basepath'}$form{'CATEGORY'}/$new.dat"));
#
#							$senderrormsg = "
#							An item file could not be renamed during the AutoClose Routine.
#							$config{'basepath'}$key/$file TO $config{'basepath'}$key/$new.dat";
#
#							&sendemail("$config{'admin_address'}", 'nobody', 'Auction Site ERROR', "$senderrormsg") unless rename("$config{'basepath'}$key/$file", "$config{'basepath'}$key/$new.dat");
#
#							&oops('incorrect alias') unless (open(REGFILE, ">>$config{'basepath'}$config{'regdir'}/$firstbid[0].dat"));
#							print REGFILE "\n$key$new";
#							close REGFILE;
#						}
						#--END: Reserve or opening not met section-------------#


						$delim = ":::";
						$delim2 = " ";
						$itemvals[8] = ($itemvals[8] - 1); 
						open THEFILE, ">$config{'basepath'}$key/$new.dat";
						# print THEFILE "$title\n$reserve\n$inc\n$desc\n$image\n$relist";
		        print THEFILE "$itemvals[0]$delim$itemvals[1]$delim$itemvals[2]$delim$itemvals[3]$delim$itemvals[4]$delim$itemvals[5]$delim$itemvals[6]$delim$itemvals[7]$delim2$delim$itemvals[8]\n";
						print THEFILE "$image\n";
						print THEFILE "$desc\n";
						$firstbid[3] = time;

						#-Only keep the initial opening bid--------------------#
						print THEFILE "$firstbid[0]\[\]$firstbid[1]\[\]$firstbid[2]\[\]$firstbid[3]\[\]$firstbid[4]\[\]$firstbid[5]\[\]$firstbid[6]";
						#------------------------------------------------------#

						close THEFILE;
						
#						if ($doit == 1) {
							$resend = "
							Hello $firstbid[0],

							Thank you for using $config{'sitename'}!

							The following item has been relisted at your request:
	  
							The NEW item information re-listed is as follows :

							   Item number :  $new
							   Title       :  $itemvals[0]
							   Length      :  $newdays days
							   Category    :  $category{$key}
							   Relists     :  $itemvals[8]
							   URL Below
							   http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?category=$key\&item=$new
   
							Once again, thank you and please tell a friend about us!
							Sincerely,
							$config{'sitename'}
							";

							&sendemail("$firstbid[1]", 'Webmaster@BidBunny.com', 'Relist of Auction', "$resend");  
							sleep 2; # Wait 2 seconds to make sure we don't get duplicate item numbers
#							next FILE; 
#						}
					}
					#--END: Relist section loop----------------------------#                
                
                foreach $bid (@bids) {
                        @thebid = split(/\[\]/,$bid);
                        $bidtime = localtime($thebid[3]);
                        #$X = $X + 1
                }
                        if ($key ne $config{closedir}) {
                        				my $closing_percent;
																$closing_percent = "$config{'close_range_fee1'}" if (($lastbid[2] >= 0.01) and ($lastbid[2] < $config{'range_1'}));
																$closing_percent = "$config{'close_range_fee2'}" if (($lastbid[2] >= $config{'range_1'}) and ($lastbid[2] < $config{'range_2'}));
																$closing_percent = "$config{'close_range_fee3'}" if (($lastbid[2] >= $config{'range_2'}) and ($lastbid[2] < $config{'range_3'}));
																$closing_percent = "$config{'close_range_fee4'}" if (($lastbid[2] >= $config{'range_3'}) and ($lastbid[2] < $config{'range_4'}));
																$closing_percent = "$config{'close_range_fee5'}" if (($lastbid[2] >= $config{'range_4'}) and ($lastbid[2] < $config{'range_5'}));
																$closing_percent = "$config{'close_range_fee6'}" if ($lastbid[2] >= $config{'range_5'});
																my $close_fee_charge = ($lastbid[2] * $closing_percent);
																my $parsedfee = sprintf "%.2f", $close_fee_charge;
																my $finalfee = &parsebid($parsedfee);
                                if ($config{closedir}) {
                                        umask(000);  # UNIX file permission junk
                                        print "Please notify the site admin that this item cannot be copied to the closed directory even though it is closed.\n" unless &movefile("$config{basepath}$key/$file", "$config{basepath}$config{closedir}$key/$file");
                                #       print "<H3>$category{$key}\: $itemvals[0] closed</H3><BR>";
                                        $numauct = $file;
                                        $numauct =~ s/\.dat//;  #makes it just the number, rather than number.dat 
                                }
                                else {
                                print "Please notify the site admin that this item cannot be removed even though it is closed.\n" unless unlink("$config{basepath}$key/$file");
                                }
                                #if $X > 1 {
                                  if (($lastbid[2] >= $itemvals[1]) && ($lastbid[2] > $firstbid[2])) {
                                        &sendemail($lastbid[1], $config{'admin_address'}, "Auction Winner: $itemvals[0]", "Congratulations!  You are the winner of auction number $numauct.\nYour winning bid was \$$lastbid[2].\n\nPlease contact the seller to make arrangements for payment and shipping:\n\n$firstbid[4]\n$firstbid[5]\n$firstbid[6]\n$firstbid[1]\n\nThanks for using the $config{'sitename2'} Auction site!");
                                        &closedebit($firstbid[0], "Closing Fee based on \$$lastbid[2], $numauct", "$finalfee", "$config{'adminpass'}", "debit");
                                        $reservemsg = " ";
                                  }
                                  else {
                                        if ($firstbid[2] ne $lastbid[2]) {
                                                &sendemail($lastbid[1], $config{'admin_address'}, "Auction Close: $itemvals[0]", "Congratulations!  You were the high bidder on auction number $numauct.\nYour bid was \$$lastbid[2].\n\nUnfortunately, your bid did not meet the seller\'s reserve price...\n\nYou may still wish to contact the seller to negotiate a fair price:\n\n$firstbid[4]\n$firstbid[5]\n$firstbid[6]\n$firstbid[1]\n\nThanks for using the $config{'sitename2'} Auction site!");
                                        $reservemsg = "YOUR RESERVE PRICE WAS NOT MET! Feel free to repost your auction by following this link: http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?action=act_login";
                                        }
                                        else {
                                                $reservemsg = "Sorry, no bids were placed on your auction. Feel free to repost your auction by following this link: http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?action=acct_login";
                                        }
                                  }
                                        &sendemail($firstbid[1], $config{'admin_address'}, "Auction Close: $itemvals[0]", "Auction Number $numauct Is Now Closed.\nThe high bid was \$$lastbid[2] (Your reserve was: \$$itemvals[1]).\n\n$reservemsg\n\nPlease contact the high bidder to make any necessary arrangements:\n\n$lastbid[4]\n$lastbid[5]\n$lastbid[6]\n$lastbid[1]\n\nThanks for using the $config{'sitename2'} Auction site!");
                                #}        
                        }
                }
         }
           }
     }
     
###############################################
# Move the items over a month old to a "Delete" folder.
# 

 foreach $key (sort keys %category) {
	 my ($nowtime, $closetime, $newtime);
   mkdir("$config{basepath}$config{closedir}$config{deletedir}", 0777) unless (-d "$config{basepath}$config{closedir}$config{deletedir}");             
   opendir THEDIR, "$config{basepath}$config{closedir}$key" || die "Unable to open directory: $!";
        @allfiles = readdir THEDIR;
        closedir THEDIR;
          foreach $file (sort { int($a) <=> int($b) } @allfiles) {
							$closetime = localtime($file);
							$nowtime = localtime(time);
							my $timenum = time;
							$newtime = localtime($file + (30 * 86400));
							my $timeleft = &timeleft($file + (30 * 86400));
							if ($timeleft eq "<font color=red> auction has ended</font>"){
							 print "Please notify the site admin that this item cannot be copied to the delete directory even though it is older than 30 days.\n" unless &movefile("$config{basepath}$config{closedir}$key/$file", "$config{basepath}$config{closedir}$config{deletedir}/$file");
# If you just want to flat-out delete the file, use the line below instead:
#							 print "Please notify the site admin that this item cannot be deleted even though it is older than 30 days.\n" unless unlink("$config{basepath}$config{closedir}$key/$file");
							}
					}
 }     
# End moving  
###############################################     
} 

#-#############################################
# Sub: time left
# revised w/ proper english - smarter output
# Note: This sub does not handle the year change properly, yet.
# Also may not handle leap years. Fixes are welcome.

sub timeleft {

 my ($rsecond, $rminute, $rhour, $rday, $timeremain, $adddays); 
 my ($second, $minute, $hour, $dayofmonth, $month, $year, $weekday, $dayofyear, $iddst) = localtime($_[0]); 
 my ($csecond, $cminute, $chour, $cdayofmonth, $cmonth, $cyear, $cweekday, $cdayofyear, $ciddst) = localtime(time); 
if (($cyear % 4) == 0) { 
$adddays = 366; 
} 
else { 
$adddays = 365; 
} 
if ($cyear != $year) { 
$dayofyear = ($dayofyear + $adddays); 
} 

  if ($second >= $csecond) { $rsecond = ($second - $csecond); }
  else { $rsecond = (($second + 60) - $csecond);
         $minute = ($minute - 1); }

  if ($minute >= $cminute) { $rminute = ($minute - $cminute); }
  else { $rminute = (($minute + 60) - $cminute);
         $hour = ($hour - 1); }

  if ($hour >= $chour) { $rhour = ($hour - $chour); }
  else { $rhour = (($hour + 24) - $chour);
         $dayofyear = ($dayofyear - 1); }

    if ($dayofyear == $cdayofyear) {
     if($rhour < 1) {
      if($rminute < 1) {
       if ($rminute = 0) { $timeremain = "<font color=red> auction has ended</font>"; }
       else { 
         $timeremain = sprintf('%02d seconds', $rsecond);
         my @s = split / /, $timeremain;
         if ($s[0] eq "01") {$s[1] = "second";}
         $timeremain = "<font color=red> " . "$s[0] $s[1]"; }}

      else {
       $timeremain = sprintf('%02d minutes %02d seconds', $rminute, $rsecond);
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "minute";}
       if ($s[2] eq "01") {$s[3] = "second";}
       $timeremain = "<font color=red> " . "$s[0] $s[1] $s[2] $s[3]"; }}

     else {
       $timeremain = sprintf('%02d hours %02d minutes', $rhour, $rminute); 
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "hour";}
       if ($s[2] eq "01") {$s[3] = "minute";}
       $timeremain = "<font color=red> " . "$s[0] $s[1] $s[2] $s[3]"; }}

    else {
     $rday = ($dayofyear - $cdayofyear);
 
     if ($rday <= -1) { $timeremain = "<font color=red> auction has ended</font>"; }
     else {
       $timeremain = sprintf('%02d days %02d hours +', $rday, $rhour);
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "day";}
       if ($s[2] eq "01") {$s[3] = "hour";}
       if ($s[2] eq "00") {($s[3], $s[2], $s[4]) = (" 1 hour","\<","");}
       $timeremain = "$s[0] $s[1] $s[2] $s[3] $s[4]"; }
     }
  return "$timeremain";
}   

#-#############################################
# Sub: Movefile(file1, file2)
# This moves a file.  Quick and dirty!

sub movefile {
	my ($firstfile, $secondfile) = @_;
	print "Failed to open first file" unless open(FIRSTFILE,$firstfile);
	my @lines=<FIRSTFILE>;
	close FIRSTFILE;
	print "Failed to open second file" unless open(SECONDFILE,">$secondfile");
	my $line;
	foreach $line (@lines) {
		print SECONDFILE $line;
	}
	close SECONDFILE;
	print "Failed to unlink first file" unless unlink($firstfile);
	return 1;
}

1;