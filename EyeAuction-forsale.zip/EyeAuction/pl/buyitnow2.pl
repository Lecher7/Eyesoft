use strict;
#
# 
#-#############################################
# Sub: Buy-it Now Form
# This displays the Buy Now Form.


  print "Test\n";

                
#-#############################################
# Sub: Process Buy-it Now Form
# This processes the Buy-it Now Form


#  my $cat;
#  my ($password, @userbids);
#  if ($config{'regdir'} ne "") {
#    &oops('Your alias could not be found!') unless ($password, $form{'EMAIL'}, $form{'ADDRESS1'}, $form{'ADDRESS2'}, $form{'ADDRESS3'}, @userbids) = &read_reg_file($form{'ALIAS'});
#    $form{'ALIAS'} = ucfirst(lc($form{'ALIAS'}));
#    &oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
#    my ($iteminfo, $desc, @bids) = &read_item_file($form{'category'},$form{'item'}); 
#		my @itemid = split(/:::/, $iteminfo); 
#    my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[0]);
#    &oops('You cannot bid on your own item.') if ((lc $form{'ALIAS'}) eq (lc $alias));
#  }
#  &oops('You must enter an alias to track your item.') unless ($form{'ALIAS'});
#  &oops('You must enter a valid e-mail address.') unless ($form{'EMAIL'} =~ /^.+\@.+\..+$/);
#  &oops('You must enter a valid bid amount.') unless ($form{'BID'} =~ /^(\d+\.?\d*|\.\d+)$/);
#  $form{'BID'} = &parsebid($form{'BID'});
#  &oops('You must enter your full name.') unless ($form{'ADDRESS1'});
#  &oops('You must enter your street address.') unless ($form{'ADDRESS2'});
#  &oops('You must enter you city, state, and zip.') unless ($form{'ADDRESS3'});
#  &oops('The item number you entered cannot be found.  Maybe it has closed or it was moved since you last loaded the page.') unless my ($title, $reserve, $inc, $desc, $image, $buyit, @bids) = &read_item_file($form{'CATEGORY'},$form{'ITEM'});
#  my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
#  &oops('Bids have been place on this item.') if ($bid > $buyit); 
#  if ((time <= $form{'ITEM'}) or (time <= (60 * $config{'aftermin'} + $time))) {
#    &oops('We are unable to append your bid to the auction item.  It appears to be a file write problem.') unless (open NEW, ">>$config{'basepath'}$form{'CATEGORY'}/$form{'ITEM'}.dat");
#    my $nowtime = localtime(time);
#    if ($config{'flock'}) {
#      flock(NEW, 2);
#      seek(NEW, 0, 2);
#    }
#    print NEW "\n$form{'ALIAS'}\[\]$form{'EMAIL'}\[\]$form{'BID'}\[\]".time."\[\]$form{'ADDRESS1'}\[\]$form{'ADDRESS2'}\[\]$form{'ADDRESS3'}";
#    close NEW;
#    print qq|<B>$form{'ALIAS'}, you have purchased lot number #$form{'ITEM'} for \$$form{'BID'} on $nowtime.</B><P>Within a few minutes, you will receive an automated e-mail response acknowledging the completion and details of the sale.<P>Go <A HREF=\"$ENV{'SCRIPT_NAME'}\">back to the Auction</A>\n|;
#    &closeit2($form{'CATEGORY'},$form{'ITEM'});
#    my $flag=0;
#    my $userbid;
#    foreach $userbid (@userbids) {
#      $flag=1 if ("$form{'CATEGORY'}$form{'ITEM'}" eq $userbid);
#    }
#    if ($flag==0 && $config{'regdir'} ne "") {
#      &oops('We could not open the registration file.  This could be a server write issue.') unless (open(REGFILE, ">>$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat"));
#      print REGFILE "\n$form{'CATEGORY'}$form{'ITEM'}";
#      close REGFILE;
#    }
#  }
#  else {
#    print qq|Item number $form{'ITEM'} in category $form{'CATEGORY'} is now closed!<BR>Sorry...\n|;
#  }
	


#-#############################################
# Sub: Close Buy-it Now Auction
# This sets an item's status to closed when the
# Buy-it Now Function is used and by-passes 
# the closeit sub.

sub closeit2 {

  my ($cat,$item) = @_;
  if ($cat ne $config{'closedir'}) {
    my ($iteminfo, $desc, @bids) = &read_item_file($form{'category'},$form{'item'}); 
		my @itemid = split(/:::/, $iteminfo); 
    my @lastbid = &read_bid($bids[$#bids]);
    my @firstbid =  &read_bid($bids[0]);
    if ($#bids) {
      &sendemail($lastbid[1], $firstbid[1], "Auction Close: ".&enable_html($title), "Congratulations!  You are the winner of auction number $item.\nThe Buy-it Now price for $item is \$$lastbid[2].\n\nThe seller will contact you within 24 hours to make arrangements for payment and shipping:\n\n$firstbid[4]\n$firstbid[5]\n$firstbid[6]\n$firstbid[1]\n\nThanks for using $config{'sitename'}!");
      &sendemail($firstbid[1], $lastbid[1], "Auction Close: ".&enable_html($title), "Auction number $item is now closed.\nThe item sold for \$$lastbid[2] using the Buy-it Now option.\n\nPlease contact the high bidder within 24 hours to make any necessary arrangements for $item:\n\n$lastbid[4]\n$lastbid[5]\n$lastbid[6]\n$lastbid[1]\n\nThanks for using $config{'sitename'}!");
    }
    if ($config{'closedir'}) {
      umask(000);  # UNIX file permission junk
      mkdir("$config{'basepath'}$config{'closedir'}", 0777) unless (-d "$config{'basepath'}$config{'closedir'}");             
      print qq|Please notify the site admin that this item cannot be copied to the closed directory even though it is closed.\n| unless &movefile("$config{'basepath'}$cat/$item.dat", "$config{'basepath'}$config{'closedir'}/$cat$item.dat");         
    }
    else {
      print qq|Please notify the site admin that this item cannot be removed even though it is closed.\n| unless unlink("$config{'basepath'}$cat/$item.dat");
    }
  }
}

#-#############################################
# Sub: Display All Buy-it Now Items
# This will display all open auction's using
# the Buy-it Now bid function.

sub allbuynow {

  print qq|<H2>Buy-it Now Auctions</H2>\n|;
  print qq|<TABLE summary="" width="100%" cellpadding="0" cellspacing="0" border="1">\n|;
  print qq|<TR><TD ALIGN="CENTER" BGCOLOR="$config{'colortablehead'}"><B>Item</B></TD><TD ALIGN="CENTER" BGCOLOR="$config{'colortablehead'}"><B>Closes</B></TD><TD ALIGN="CENTER" BGCOLOR="$config{'colortablehead'}"><B>Buy Now Price</B></TD></TR>\n|;
  my $key;
  foreach $key (sort keys %category) {
    opendir THEDIR, "$config{'basepath'}$key" or &oops("Category directory $key could not be opened.");
    my @allfiles = grep -T, map "$config{'basepath'}$key/$_", sort { int($a) <=> int($b) } (readdir THEDIR);
    closedir THEDIR;
    my $file;
    foreach $file (@allfiles) {
      $file =~ s/^$config{'basepath'}$key\///;
      $file =~ s/\.dat$//;
      my ($iteminfo, $desc, $image, @bids) = &read_item_file($key,$file);
      my @itemid = split(/:::/, $iteminfo);
      my @lastbid = &read_bid($bids[$#bids]);
      if (($buyit > 0) && ($bids[0]) eq ($bids[$#bids]))  {
        my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]); # read last bid
        my @closetime = localtime($file);
        $closetime[4]++;
        my @firstbid =  &read_bid($bids[0]);
        print qq|<TR><TD BGCOLOR="$config{'colortablebody'}"><A HREF="$ENV{'SCRIPT_NAME'}?category=$key&item=$file">$title</A>&nbsp;|;
        print qq| <FONT COLOR="#3333FF" SIZE="-1">[PIC]</FONT>| if ($image);
        print qq|</TD><TD ALIGN="CENTER" BGCOLOR="$config{'colortablebody'}">$closetime[4]/$closetime[3]</TD><TD ALIGN="CENTER" BGCOLOR="$config{'colortablebody'}">\$$buyit</TD></TR>\n|;
        }
      }
    }
  print qq|</TABLE>\n|;
	
}

1;