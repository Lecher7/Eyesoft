use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#
#-#############################################
# Process Admin
# Allows the administrator to delete items.


	if (lc($form{'PASSWORD'}) eq lc($config{'adminpass'})) {
		&oops('Bad Item Category or Number!') unless &read_item_file($form{'CATEGORY'},$form{'ITEM'});
		if (unlink("$config{'basepath'}$form{'CATEGORY'}/$form{'ITEM'}.dat")) {
			&deletesuccess;
		}
		else {
			&deletefailed;
		}
	}
	else {
		&badpass;
	}


#-#############################################
# Sub Delete Success
#

sub deletesuccess {
    print	&load_template ('adminsuccess.html', { 
			ADMIN	=>	"File Successfully Removed!",
				%globals
	});      
}

#-#############################################
# Sub Delete Failed
#

sub deletefailed {
			&oops("File Could Not Be Removed!");
}

#-#############################################
# Sub Bad Password
#

sub badpass {
		&oops("Sorry...  Incorrect administrator password for delete!");
}
1;