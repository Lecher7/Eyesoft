use strict;
#
#
#---------------------------------------------------------------------------#
# Sub: AutoRelist. Automatic closing, relisting and emailing routine.
#---------------------------------------------------------------------------#
sub autorelist { 
#---------------------------------------------------------------------------#
	my $doit = 0;		
	my ($iteminfo, $delim, $delim2);
	my ($key, $bid, $bidtime, $nosellreason, $opening, $opentext, $bidstart, $repostseconds, $repost, $new);
	my ($resend, $numauct, $winnermessage, $sellermessage, $highbidmessage, $reservemsg, $file, @lastbid, @firstbid);
	my ($numfile, $closetime, @allfiles, @thebid, $nowtime, $senderrormsg);
	my ($title, $reserve, $inc, $desc, $image, $location, $payments, $shipping, $condition, $relist, @bids);
	my ($alias, $email, $maxbid, $time, $name, $address, $city, $state, $postal, $country, $currentbid);

	#--For each CAT loop section---------------------------#
	foreach $key (sort keys %category) {
		opendir THEDIR, "$config{'basepath'}$key" || &oops("SUB: AUTOCLOSE\n\nCategory directory $key could not be opened.");
		@allfiles = readdir THEDIR;
		closedir THEDIR;

		#--For each file loop section--------------------------#
		FILE: foreach $file (sort { int($a) <=> int($b) } @allfiles) {

			#--Auction is over section-----------------------------#
			if (time > $file) {

				#--File exists section---------------------------------#
				if (-T "$config{'basepath'}$key/$file") {
        print "Hello\n";				
					open THEFILE, "$config{'basepath'}$key/$file";
					($iteminfo, $image, $desc, @bids) = <THEFILE>;
					chomp($iteminfo, $image, $desc, @bids);
					my @iteminfo = split(/:::/, $iteminfo);
					@firstbid = split(/\[\]/,$bids[0]);
					@lastbid = split(/\[\]/,$bids[$#bids]);
					$nowtime = localtime(time);
					$closetime = localtime($file);
					foreach $bid (@bids) {
						@thebid = split(/\[\]/,$bid);
						$bidtime = localtime($thebid[3]);
					}
					close THEFILE;
					$opening = $iteminfo[1];
					$opentext = "Your reserve price";
					print "Item: $iteminfo[8]\n";
					if ($firstbid[2] > $iteminfo[1]) { 
						$opening = $firstbid[2];
						$opentext = "Your opening bid";
					}
					#--Relist Section Loop---------------------------------#
					
					if ($iteminfo[8] > 0) {
						$bidstart = localtime($firstbid[3]);
						$repostseconds = ($closetime - $bidstart);
						
						#--No bids placed section------------------------------#
						if ($firstbid[0] eq $lastbid[0])  {
							$nosellreason = "No bids were placed";
							$doit = 1;
							$new = ($repostseconds + time);
							$new = ($repostseconds + time) until (!(-e "$config{'basepath'}$key/$new.dat"));

							$senderrormsg = "
							An item file could not be renamed during the AutoClose Routine.
							$config{'basepath'}$key/$numfile.dat TO $config{'basepath'}$key/$new.dat";
	
							&sendemail("$config{'admin_address'}", 'nobody', 'Auction Site ERROR', "$senderrormsg") unless rename("$config{'basepath'}$key/$file", "$config{'basepath'}$key/$new.dat");

							&oops('incorrect alias') unless (open(REGFILE, ">>$config{'basepath'}$config{'regdir'}/$firstbid[0].dat"));
							print REGFILE "\n$key$new";
							close REGFILE;
						}
						#--END: No bids placed section-------------------------#


						#--Reserve or opening bid not met section--------------#
						elsif ($lastbid[2] < $opening) {
							$nosellreason = "$opentext was not met, highest bid was \$$lastbid[2]";
							$doit = 1;
							$new = ($repostseconds + time);
							$new = ($repostseconds + time) until (!(-e "$config{'basepath'}$key/$new.dat"));

							$senderrormsg = "
							An item file could not be renamed during the AutoClose Routine.
							$config{'basepath'}$key/$file TO $config{'basepath'}$key/$new.dat";

							&sendemail("$config{'admin_address'}", 'nobody', 'Auction Site ERROR', "$senderrormsg") unless rename("$config{'basepath'}$key/$file", "$config{'basepath'}$key/$new.dat");

							&oops('incorrect alias') unless (open(REGFILE, ">>$config{'basepath'}$config{'regdir'}/$firstbid[0].dat"));
							print REGFILE "\n$key$new";
							close REGFILE;
						}
						#--END: Reserve or opening not met section-------------#


						#-Image Upload-----------------------------------------#
						# If you ARE using the image upload addon, un-comment
						# this section.
						#------------------------------------------------------#
						#$numauct = $file;
						#$numauct =~ s/\.dat//;
						#if ($image ne '') {
						#	$extension = (split(/\./,$image))[-1];
						#	$imagefile = "$imageuploaddir/$key$numauct.$extension";
						#	if (-f "$imagefile") {
						#		$image = "$imageuploadurl/$key$new.$extension";
						#		&oops("Please notify the site administrator that this items image file cannot be renamed.") unless rename("$imagefile", "$imageuploaddir/$key$new.$extension");
						#	}
						#}
						#-Image Upload END-------------------------------------#
						$delim = ":::";
						$delim2 = " ";
						$iteminfo[8] = ($iteminfo[8] - 1); 
						open THEFILE, ">$config{'basepath'}$key/$new.dat";
						# print THEFILE "$title\n$reserve\n$inc\n$desc\n$image\n$relist";
		        print THEFILE "$iteminfo[0]$delim$iteminfo[1]$delim$iteminfo[2]$delim$iteminfo[3]$delim$iteminfo[4]$delim$iteminfo[5]$delim$iteminfo[6]$delim$iteminfo[7]$delim2$delim$iteminfo[8]";

						$firstbid[3] = time;

						#-Only keep the initial opening bid--------------------#
						print THEFILE "\n$firstbid[0]\[\]$firstbid[1]\[\]$firstbid[2]\[\]$firstbid[3]\[\]$firstbid[4]\[\]$firstbid[5]\[\]$firstbid[6]";
						#------------------------------------------------------#

						close THEFILE;
						
						if ($doit == 1) {
							$resend = "
							Hello $firstbid[0],

							Thank you for using $config{'sitename'}!

							The following item has been relisted at your request:

#							Reason for not selling: $nosellreason
	  
							The NEW item information re-listed is as follows :

							   Item number :  $new
							   Title       :  $iteminfo[0]
							   Length      :  $repostseconds/86400
							   Category    :  $category{$key}
							   Relists     :  $iteminfo[8]
							   URL Below
							   http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?category=$key\&item=$new
   
							Once again, thank you and please tell a friend about us!
							Sincerely,
							$config{'sitename'}
							";

							&sendemail("$firstbid[1]", 'Webmaster@BidBunny.com', 'Relist of Auction', "$resend");  
							sleep 2; # Wait 2 seconds to make sure we don't get duplicate item numbers
							next FILE; 
						}
					}
					#--END: Relist section loop----------------------------#

					#--CAT <> Closed dir loop------------------------------#
					if ($key ne $config{'closedir'}) {
						if ($config{'closedir'}) {
							umask(000);
							mkdir("$config{'basepath'}$config{'closedir'}", 0777) unless (-d "$config{'basepath'}$config{'closedir'}");

							$senderrormsg = "
							An item file could not be copied to the closed directory during the AutoClose Routine.
							$config{'basepath'}$key/$numfile.dat TO $config{'basepath'}$config{'closedir'}/$key$file";

							&sendemail("$config{'admin_address'}", 'nobody', 'Auction Site ERROR', "$senderrormsg") unless &movefile("$config{'basepath'}$key/$file", "$config{'basepath'}$config{'closedir'}/$key$file");  

							$numauct = $file;
							$numauct =~ s/\.dat//;

							#-Image Upload-----------------------------------------#
							# If you ARE using the image upload addon, un-comment
							# this section.
							#------------------------------------------------------#
							#if ($image ne '') {
							#	$extension = (split(/\./,$image))[-1];
							#	$imagefile = "$imageuploaddir/$key$numauct.$extension";
							#	if (-f "$imagefile") {
							#		&oops("Please notify the site administrator that this items image file cannot be removed.") unless unlink("$imagefile");
							#	}
							#}
							#-Image Upload END-------------------------------------#
								
							#--AccountFirst Closed Item Charge Entry Point---------#
							#  Insert your AF line below if you are using the AF's # 
							#  charge when item closes feature                     #
							# &transaction_presetrates_closed($firstbid[0], "Auction closed, #$numauct ($iteminfo[0])", $firstbid[2], $lastbid[2], $iteminfo[8], 1, 0, 1);
							#--End-------------------------------------------------#

						}
						else {
							$senderrormsg = "
							An item file could not be removed during the AutoClose Routine.
							$config{'basepath'}$key/$file";

							&sendemail("$config{'admin_address'}", 'nobody', 'Auction Site ERROR', "$senderrormsg") unless unlink("$config{'basepath'}$key/$file");
						}

						#--Winning bid and seller <> bidder--------------------#	
						if (($lastbid[2] >= $opening) && ($firstbid[0] ne $lastbid[0])) {
							$winnermessage = "
							Congratulations!  You are the winner of auction number $numauct.
							Your winning bid was \$$lastbid[2].

							Please contact the seller to make arrangements for payment and shipping:

							$firstbid[4]
							$firstbid[5]
							$firstbid[6]
							$firstbid[1]

							Thanks for using $config{'sitename'}!
							";

							$sellermessage = "
							Auction Number $numauct Is Now Closed.
							The winning bid was \$$lastbid[2] by $lastbid[0].
							($opentext was: \$$opening).

							Please contact the winning bidder to make any necessary arrangements:

							$lastbid[4]
							$lastbid[5]
							$lastbid[6]
							$lastbid[1]

							Thanks for using $config{'sitename'}!
							";
							&sendemail("$lastbid[1]",  'nobody', "Auction Winner: $iteminfo[0]", "$winnermessage");
							$reservemsg = " ";
							&sendemail("$firstbid[1]", 'nobody', "Auction Close: $iteminfo[0]", "$sellermessage");
						}
						#--END: Winning bid and seller <> bidder---------------#

						#--No winning bid and seller <> bidder-----------------#
						elsif ($firstbid[2] ne $lastbid[2]) {
							$reservemsg = "
							YOUR RESERVE PRICE WAS NOT MET!
							(Your reserve was: \$$iteminfo[1])
							The high bid was \$$lastbid[2] by $lastbid[1].

							Feel free to repost your auction by following this link:
							http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?action=repost\&repost=$key$file
							";
							&sendemail("$firstbid[1]", 'nobody', "Auction Close: $iteminfo[0]", "Auction Number $numauct Is Now Closed.\n\n$reservemsg\n\nThanks for using $config{'sitename'}!");
						}
						#--END: No winning bid and seller <> bidder------------#

						#--No winning bid and seller = bidder (no bids)--------#
						else {
							$reservemsg = "
							Sorry, no bids were placed on your auction.
							Feel free to repost your auction by following this link:
							http://$config{'scripturl'}$ENV{'SCRIPT_NAME'}\?action=repost\&repost=$key$file
							";
							&sendemail("$firstbid[1]", 'nobody', "Auction Close: $iteminfo[0]", "Auction Number $numauct Is Now Closed.\n\n$reservemsg\n\nThanks for using $config{'sitename'}!");
						}
						#--END: No winning bid and seller = bidder (no bids)---#
					}
					#--END: CAT <> Closed dir loop-------------------------#
				}
				#--END: File exists section----------------------------#
			}
			#--END: Auction is over section------------------------#
		}
		#--END: For each file loop section---------------------#
	}
	#--END: For each CAT loop section----------------------#
}
#--END: Sub AutoClose----------------------------------#
1;