#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#################################################################################
#This is where the user logs in to track an item

sub track {
    
    print "<DIV ALIGN=center>\n";
    print "<BR><TABLE WIDTH=340 BORDER=0 cellpadding=1 cellspacing=1 bgcolor=000000>";
    print "<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>\n";
    print "<INPUT TYPE=HIDDEN NAME=action VALUE=proctrack>";
    print "<INPUT TYPE=HIDDEN NAME=CATEGORY VALUE=$form{'trackcat'}>\n";
    print "<INPUT TYPE=HIDDEN NAME=ITEM VALUE=$form{'item'}>\n";
    print "<TR><TD bgcolor=$config{'colortablehead'} COLSPAN=2 VALIGN=CENTER>\n";
    print "<font face=arial color=FFFFFF size=4><B><CENTER>Track item #$form{'item'}</CENTER></B></FONT>\n"; 
    print "</TD></TR>\n";
    print "<TR><TD bgcolor=$config{'colortablebody'} ALIGN=RIGHT VALIGN=CENTER><font face=arial><B>Username/Alias: \n";
    print "</B></TD>\n";
    print "<TD align=center bgcolor=$config{'colortablebody'}><INPUT TYPE=TEXT SIZE=22 NAME=\"ALIAS\">\n";
    print "</TD></TR>\n";
    print "<TR><TD bgcolor=$config{'colortablebody'} ALIGN=RIGHT VALIGN=CENTER><font face=arial><B>Password: \n";
    print "</B></TD>\n";
    print "<TD align=center bgcolor=$config{'colortablebody'}><INPUT TYPE=PASSWORD SIZE=22 NAME=\"PASSWORD\">\n";
    print "</TD></TR></TABLE>\n";
    print "<BR>\n";
    print "<INPUT TYPE=submit VALUE=\"Track Item\">\n";
    print "</FORM>\n";
}

##############################################################
#This is where the user logs in to see what there tracking

sub tracking {

    print "<DIV ALIGN=center>\n";
    print "<BR><TABLE WIDTH=340 BORDER=0 cellpadding=1 cellspacing=1 bgcolor=000000>";
    print "<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>\n";
    print "<INPUT TYPE=HIDDEN NAME=action VALUE=proctracking>";
    print "<TR><TD bgcolor=$config{'colortablehead'} COLSPAN=2 VALIGN=CENTER>\n";
    print "<font face=arial color=FFFFFF size=4><B><CENTER>Check your account</CENTER></B></FONT>\n";
    print "</TD></TR>\n";
    print "<TR><TD bgcolor=$config{'colortablebody'} ALIGN=RIGHT VALIGN=CENTER><font face=arial><B>Username/Alias: \n";
    print "</B></TD>\n";
    print "<TD align=center bgcolor=$config{'colortablebody'}><INPUT TYPE=TEXT SIZE=22 NAME=ALIAS>\n";
    print "</TD></TR>\n";
    print "<TR><TD bgcolor=$config{'colortablebody'} ALIGN=RIGHT VALIGN=CENTER><font face=arial><B>Password: \n";
    print "</B></TD>\n";
    print "<TD align=center bgcolor=$config{'colortablebody'}><INPUT TYPE=PASSWORD SIZE=22 NAME=PASSWORD>\n";
    print "</TD></TR></TABLE>\n";
    print "<BR>\n";
    print "<INPUT TYPE=submit VALUE=\"What Are You Tracking? \">\n";
    print "</FORM>\n";
}

##############################################################
#This lets you see the items your tracking

sub proctracking {
    
    &oops('You must enter your username !') if ($form{'ALIAS'} eq "");
    &oops('You must enter a password !') if ($form{'PASSWORD'} eq "");
  	
        my ($password,$email,$add1,$add2,$add3,@past_bids) = &read_reg_file($form{'ALIAS'});
  	
  	&oops('Your alias could not be found !') if ($password eq "");
	&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	open(TRACKFILE, "$config{'basepath'}$config{'trackpath'}$form{'ALIAS'}.track");
	
	(@watch) = <TRACKFILE>;
    close TRACKFILE;
    chomp(@watch);
    
	if ((lc $password) eq (lc $form{'PASSWORD'})) {
	
	
	
	
		 print "<HTML>";
		 print "<HEAD>";
		 print "<TITLE></TITLE>";
		 print "</HEAD>";
		 print "$config{'header'}";
		 print "$config{'navbar'}";
	   print "<H2>$category{$form{'category'}}</H2>\n";
#	   print "<TABLE CELLPADDING=1 CELLSPACING=1 BGCOLOR=000000 BORDER=0 WIDTH=100\%>\n";
#		 print "<CENTER><H2>Current listings $form{'ALIAS'} has bid on:</H2>\n";
		 print "<table BORDER=1 bgcolor=#6082D2 cellspacing=0 cellpadding=0><tr><td colspan=5><font color=white><H2>Current listings I'm tracking:</H2></font></td></tr>\n";
#		 print "<TABLE BORDER=1 BGCOLOR=$config{'colortablebody'} WIDTH=700 CELLSPACING=0 CELLPADDING=0>\n";
	   print "<TR><td WIDTH=45 BGCOLOR=$config{'colortablehead'} align=center><font size=-5 face=arial color=000000><B>Remove</b></td><TD ALIGN=CENTER WIDTH=350 BGCOLOR=$config{'colortablehead'}><font face=arial color=FFFFFF><B>Item</B></TD><TD WIDTH=120 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><font face=arial color=FFFFFF><B>Closes</B></TD><TD WIDTH=40 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><font face=arial color=FFFFFF><B>Bids</B></TD><TD WIDTH=133 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><font face=arial color=FFFFFF><B>High Bid</B></TD></TR>\n";
	   print "<FORM ACTION=$ENV{'SCRIPT_NAME'} METHOD=POST>\n";
	   print "<INPUT TYPE=HIDDEN NAME=action VALUE=deleteeye>\n";
	   print "<input type=hidden name=PASSWORD value=$form{'PASSWORD'}><INPUT TYPE=HIDDEN NAME=ALIAS VALUE=$form{'ALIAS'}>\n";
	
	}
	   
	else {
	
	}
	
	open(TRACKFILE, "$config{'basepath'}$config{'trackpath'}$form{'ALIAS'}.track");
	(@watch) = <TRACKFILE>;
    close TRACKFILE;
    chomp(@watch);
        
        my $file ;
        my $rcount = 0;
    
    for($i=0;$i<=$#watch;$i++) {
	   $file =~ s/^$config{'basepath'}$form{'category'}\///;
	   $file =~ s/\.dat$//;
	   @watching = split(/\[\]/,$watch[$i]);
    
        my $itemrowcolor;
    
    if ($rcount % 2 == 1) {
    
        $itemrowcolor=$config{'trackcolorevenrow'}
    
    }
    else {
    
        $itemrowcolor=$config{'trackcoloroddrow'}
    
    }
    
    $rcount++;
   
        my $file = $watching[1];
        my $category = $watching[0];
	
	 if (open(ITEMFILE, "$config{'basepath'}$watching[0]/$watching[1].dat")) {
	
	($iteminfo, $image, $desc, @bids) = <ITEMFILE>;
	close ITEMFILE;
	chomp($iteminfo, $image, $desc, @bids);
    
       my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$#bids]);
	   my @closetime = localtime($file);
	
	$closetime[4]++;
	    my @itemvals = split(/:::/, $iteminfo);
	   my $timeremain = time_remain($file);
       print "<TR><td BGCOLOR=$itemrowcolor align=center COLOR=#3333FF ><input type=radio name=ITEM value=$file><input type=hidden name=CATEGORY value=$watching[0]></td><TD BGCOLOR=$itemrowcolor><A HREF=$ENV{'SCRIPT_NAME'}\?category=$category\&item=$file>$itemvals[0]</A>";
	   print " <FONT COLOR=#3333FF SIZE=-1>\&nbsp\;$config{'trackhotpic'}</FONT>" if ($#bids >= $config{'trackhot'});
	   print " <FONT COLOR=#3333FF SIZE=-1>\&nbsp\;$config{'trackpic'}</FONT>" if ($image);
	   print "<FONT SIZE=-1>\&nbsp\;$config{'trackreservemetpic'}</FONT>" if (($bid >= $itemvals[1]) and ($itemvals[1] > 0));
	   print "<FONT SIZE=-1>\&nbsp\;$config{'tracknoreservepic'}</FONT>" if ($itemvals[1] < 1 );
	   print "</TD><TD ALIGN=CENTER BGCOLOR=$itemrowcolor>$timeremain</TD>";
	   
    if ($#bids >= $config{'trackhot'}) {
	
	   print "<TD ALIGN=CENTER BGCOLOR=$itemrowcolor><font color=red><b>$#bids</b></font></TD>";
	
	}
	else {
	
	   print "<TD ALIGN=CENTER BGCOLOR=$itemrowcolor><b>$#bids</b></TD>";
	
	}
      
	   print "<TD ALIGN=CENTER BGCOLOR=$itemrowcolor><b>\$$bid</b></TD></TR>\n";
    
    }
    else {	
    print "<TR><td BGCOLOR=$itemrowcolor align=center COLOR=#3333FF ><input type=radio name=ITEM value=$file><input type=hidden name=CATEGORY value=$watching[0]></td><TD BGCOLOR=$itemrowcolor COLSPAN=4><B>Item #$file from $category is closed . Go to our <A HREF=$ENV{'SCRIPT_NAME'}\?action=closed>closed auction viewer</A></B></TD></TR>";
    }
    }

       print "</TABLE>\n";
       print "<CENTER><BR><INPUT TYPE=submit VALUE=\"Stop Tracking\"></form></CENTER>\n";


#######################
## Display Current listings I'm bidding on
##	
	&oops('You must enter an alias that consists of alphanumeric characters.') if $form{'ALIAS'} =~ /\W/ or !($form{'ALIAS'});
			$form{'ALIAS'} =~ s/\W//g;
			$form{'ALIAS'} = lc($form{'ALIAS'});
			$form{'ALIAS'} = ucfirst($form{'ALIAS'});
			&oops('Your ALIAS does not exist') unless (open(REGFILE, "$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat"));
			my ($password,$email,$add1,$add2,$add3) = <REGFILE>;
			my $timeremain = time_remain($file);
			chomp($password,$email,$add1,$add2,$add3);
			close REGFILE;
			&oops('Your password is incorrect.') if $form{'PASSWORD'} ne $password;
	#			print "<CENTER><H2>Current listings $form{'ALIAS'} has bid on:</H2>\n";
				print "<table BORDER=1 bgcolor=#6082D2 cellspacing=0 cellpadding=0 width=700><tr><td colspan=5><font color=white><H2>Current listings I'm bidding on:</H2></font></td></tr>\n";
	#			print "<TABLE BORDER=1 BGCOLOR=$config{'colortablebody'} WIDTH=700 CELLSPACING=0 CELLPADDING=0>\n";
			print "<TR><TD width=100 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item Number</B></TD><TD width=350 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Opening Price</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Closing Price</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Status</B></TD></TR>\n";
			my $key;
			foreach $key (sort keys %category) {
			opendir THEDIR, "$config{'basepath'}$key" || die "Unable to open directory: $!";
			my @allfiles = readdir THEDIR;
			closedir THEDIR;
			my $file;
			foreach $file (sort { int($a) <=> int($b) } @allfiles) {
			if (-T "$config{'basepath'}$key/$file") {
			open THEFILE, "$config{'basepath'}$key/$file";
			my ($iteminfo, $image, $desc, @bids) = <THEFILE>;
			close THEFILE;
			chomp ($iteminfo, $image, $desc, @bids);
			my @lastbid = split(/\[\]/,$bids[$#bids]);
			my @itemvals = split(/:::/, $iteminfo);
			$file =~ s/\.dat//;
#			my @firstbids =  &read_bid($bids[0]);
			shift @bids; # remove the first bid (start bid)
			foreach my $bid (@bids) { 
				my @nowbid = split(/\[\]/,$bids[0]);
#			  print "Bids: @nowbid[0]\n";
			  if (@nowbid[0] eq $form{'ALIAS'}) {

					my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bid);
					my @closetime = localtime($file);
					$closetime[4]++;
					my @firstbid =  &read_bid($bids[0]);
					my $timediff = ($file - time);
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=green><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=red><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "&nbsp;&nbsp;&nbsp;$config{'imageiconpath'}" if ($image && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'hoticonpath'} " if ($config{'hotitemnum'} <= $#bids && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'newiconpath'} " if (time<($config{'newdays'} * 86400 + $firstbid[3]) && ($form{'ALIAS'} eq $alias)) ;
					print "&nbsp;&nbsp;&nbsp;$config{'endiconpath'} " if ($timediff<($config{'endhours'} * 3600) && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'auctionicon'} " if ($type eq 'Auction' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'classicon'} " if ($type eq 'Classified' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'wantedicon'} " if ($type eq 'Wanted' && ($form{'ALIAS'} eq $alias));
					print "</TD>" if ($form{'ALIAS'} eq $alias);
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
		#			print "<TD ALIGN=CENTER BGCOLOR=$itemrowcolor>$timeremain</TD>";
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>High Bid</font></B></td><TR> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
	# The below line prints the user and their email addy.  Work this into the table somewhere				
	#  print "$firstbid[0], $firstbid[1]";

					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font color=red>Out Bid </font></B></td><TR>"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
				}
			} 
	
			
			}
		}
	}
	print "</table>";
	
#			print "<BR><table border=\"2\" bordercolor=\"#000000\" bgcolor=\"#FF9933\" cellspacing=\"0\" cellpadding=\"0\" width=\"100\%\"><tr><td>&nbsp;</td></tr></table>";
print "<p><br>	\n";

#######################
## Display closed listings I've bid on
##

	&oops('You must enter an alias that consists of alphanumeric characters.') if $form{'ALIAS'} =~ /\W/ or !($form{'ALIAS'});
			$form{'ALIAS'} =~ s/\W//g;
			$form{'ALIAS'} = lc($form{'ALIAS'});
			$form{'ALIAS'} = ucfirst($form{'ALIAS'});
			&oops('Your ALIAS does not exist') unless (open(REGFILE, "$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat"));
			my ($password,$email,$add1,$add2,$add3) = <REGFILE>;
			chomp($password,$email,$add1,$add2,$add3);
			close REGFILE;
			&oops('Your password is incorrect.') if $form{'PASSWORD'} ne $password;
#			print "<CENTER><H2>Closed Listings $form{'ALIAS'} has bid on:</H2>\n";
			print "<table BORDER=1 bgcolor=#6082D2 cellspacing=0 cellpadding=0 width=700><tr><td colspan=5><font color=white><H2>Closed listings I've bid on:</H2></font></td></tr>\n";
#			print "<TABLE BORDER=1 BGCOLOR=$config{'colortablebody'} WIDTH=700 CELLSPACING=0 CELLPADDING=0>\n";
			print "<TR><TD width=100 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item Number</B></TD><TD width=350 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Opening Price</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Closing Price</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Status</B></TD></TR>\n";
			my $key;
			foreach $key (sort keys %category) {
			opendir THEDIR, "$config{'basepath'}$config{'closedir'}$key" || die "Unable to open directory: $!";
			my @allfiles = readdir THEDIR;
			closedir THEDIR;
			my $file;
			foreach $file (sort { int($a) <=> int($b) } @allfiles) {
			if (-T "$config{'basepath'}$config{'closedir'}$key/$file") {
			open THEFILE, "$config{'basepath'}$config{'closedir'}$key/$file";
			my ($iteminfo, $image, $desc, @bids) = <THEFILE>;
			close THEFILE;
			chomp ($iteminfo, $image, $desc, @bids);
			my @lastbid = split(/\[\]/,$bids[$#bids]);
			$file =~ s/\.dat//;			
			my @itemvals = split(/:::/, $iteminfo);
#			my @firstbids =  &read_bid($bids[0]);
			shift @bids; # remove the first bid (start bid)
			foreach my $bid (@bids) { 
				my @nowbid = split(/\[\]/,$bids[0]);
#					print "Bids: @nowbid[0]\n";
				if (@nowbid[0] eq $form{'ALIAS'}) {
					my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bid);
					my @closetime = localtime($file);
					$closetime[4]++;
					my @firstbid =  &read_bid($bids[0]);
					my $timediff = ($file - time);
		#			print "$firstbids[1], $firstbids[2]";
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=green><A HREF=$ENV{'SCRIPT_NAME'}\?action=dispcloseditem&category=$form{'category'}$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=red><A HREF=$ENV{'SCRIPT_NAME'}\?action=dispcloseditem&category=$form{'category'}$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "&nbsp;&nbsp;&nbsp;$config{'imageiconpath'}" if ($image && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'hoticonpath'} " if ($config{'hotitemnum'} <= $#bids && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'newiconpath'} " if (time<($config{'newdays'} * 86400 + $firstbid[3]) && ($form{'ALIAS'} eq $alias)) ;
					print "&nbsp;&nbsp;&nbsp;$config{'endiconpath'} " if ($timediff<($config{'endhours'} * 3600) && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'auctionicon'} " if ($type eq 'Auction' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'classicon'} " if ($type eq 'Classified' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'wantedicon'} " if ($type eq 'Wanted' && ($form{'ALIAS'} eq $alias));
					print "</TD>" if ($form{'ALIAS'} eq $alias);
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>Winner</font></B></td><TR> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));


					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font color=red>Sold </font></B></td><TR>"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
				}
			} 
	
			
			}
		}
	}
	print "</table>";
	
#			print "<BR><table border=\"2\" bordercolor=\"#000000\" bgcolor=\"#FF9933\" cellspacing=\"0\" cellpadding=\"0\" width=\"100\%\"><tr><td>&nbsp;</td></tr></table>";
	
print "<p><br>	\n";

#######################
## Display Items I'm Selling
##

	&oops('You must enter an alias that consists of alphanumeric characters.') if $form{'ALIAS'} =~ /\W/ or !($form{'ALIAS'});
			$form{'ALIAS'} =~ s/\W//g;
			$form{'ALIAS'} = lc($form{'ALIAS'});
			$form{'ALIAS'} = ucfirst($form{'ALIAS'});
			&oops('Your ALIAS does not exist') unless (open(REGFILE, "$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat"));
			my ($password,$email,$add1,$add2,$add3) = <REGFILE>;
			my $timeremain = time_remain($file);
			chomp($password,$email,$add1,$add2,$add3);
			close REGFILE;
			&oops('Your password is incorrect.') if $form{'PASSWORD'} ne $password;
	#			print "<CENTER><H2>Current listings $form{'ALIAS'} has bid on:</H2>\n";
				print "<table BORDER=1 bgcolor=#6082D2 cellspacing=0 cellpadding=0 width=700><tr><td colspan=5><font color=white><H2>Current listings I'm selling:</H2></font></td></tr>\n";
	#			print "<TABLE BORDER=1 BGCOLOR=$config{'colortablebody'} WIDTH=700 CELLSPACING=0 CELLPADDING=0>\n";
			print "<TR><TD width=100 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item Number</B></TD><TD width=350 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Opening Price</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Closing Price</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Time Left</B></TD></TR>\n";
			my $key;
			foreach $key (sort keys %category) {
			opendir THEDIR, "$config{'basepath'}$key" || die "Unable to open directory: $!";
			my @allfiles = readdir THEDIR;
			closedir THEDIR;
			my $file;
			foreach $file (sort { int($a) <=> int($b) } @allfiles) {
			if (-T "$config{'basepath'}$key/$file") {
			open THEFILE, "$config{'basepath'}$key/$file";
			my ($iteminfo, $image, $desc, @bids) = <THEFILE>;
			close THEFILE;
			chomp ($iteminfo, $image, $desc, @bids);
			my @lastbid = split(/\[\]/,$bids[$#bids]);
#			print "Bids: $bids[$#bids]\n";
			$file =~ s/\.dat//;
#			my @firstbids =  &read_bid($bids[0]);
			my @itemvals = split(/:::/, $iteminfo);
#			shift @bids; # remove the first bid (start bid)
			foreach my $bid (@bids) { 
				my @nowbid = split(/\[\]/,$bids[0]);
#			  print "Bids: @nowbid[0]\n";
			  if (@nowbid[0] eq $form{'ALIAS'}) {

					my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bid);
					my @closetime = localtime($file);
					$closetime[4]++;
					my @firstbid =  &read_bid($bids[0]);
					my $timediff = localtime($file - time);
					my $time2close = localtime($file);
					my $timeleft2 = &timeleft($file);
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=green><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=red><A HREF=$ENV{'SCRIPT_NAME'}\?category=$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "&nbsp;&nbsp;&nbsp;$config{'imageiconpath'}" if ($image && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'hoticonpath'} " if ($config{'hotitemnum'} <= $#bids && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'newiconpath'} " if (time<($config{'newdays'} * 86400 + $firstbid[3]) && ($form{'ALIAS'} eq $alias)) ;
					print "&nbsp;&nbsp;&nbsp;$config{'endiconpath'} " if ($timediff<($config{'endhours'} * 3600) && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'auctionicon'} " if ($type eq 'Auction' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'classicon'} " if ($type eq 'Classified' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'wantedicon'} " if ($type eq 'Wanted' && ($form{'ALIAS'} eq $alias));
					print "</TD>" if ($form{'ALIAS'} eq $alias);
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
#					print "<TD ALIGN=CENTER BGCOLOR=$itemrowcolor>$timeleft2</TD>";
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B>$timeleft2</B></td><TR> "if ($form{'ALIAS'} eq $alias);
	# The below line prints the user and their email addy.  Work this into the table somewhere				
	#  print "$firstbid[0], $firstbid[1]";

	#				print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font color=red>Out Bid </font></B></td><TR>"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
				}
			} 
	
			
			}
		}
	}
	print "</table>";
	
#			print "<BR><table border=\"2\" bordercolor=\"#000000\" bgcolor=\"#FF9933\" cellspacing=\"0\" cellpadding=\"0\" width=\"100\%\"><tr><td>&nbsp;</td></tr></table>";
print "<p><br>	\n";

#######################
## Display Items I've Sold
##	

	&oops('You must enter an alias that consists of alphanumeric characters.') if $form{'ALIAS'} =~ /\W/ or !($form{'ALIAS'});
			$form{'ALIAS'} =~ s/\W//g;
			$form{'ALIAS'} = lc($form{'ALIAS'});
			$form{'ALIAS'} = ucfirst($form{'ALIAS'});
			&oops('Your ALIAS does not exist') unless (open(REGFILE, "$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat"));
			my ($password,$email,$add1,$add2,$add3) = <REGFILE>;
			chomp($password,$email,$add1,$add2,$add3);
			close REGFILE;
			&oops('Your password is incorrect.') if $form{'PASSWORD'} ne $password;
#			print "<CENTER><H2>Closed Listings $form{'ALIAS'} has bid on:</H2>\n";
			print "<table BORDER=1 bgcolor=#6082D2 cellspacing=0 cellpadding=0 width=700><tr><td colspan=5><font color=white><H2>Items I've Sold:</H2></font></td></tr>\n";
#			print "<TABLE BORDER=1 BGCOLOR=$config{'colortablebody'} WIDTH=700 CELLSPACING=0 CELLPADDING=0>\n";
			print "<TR><TD width=100 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item Number</B></TD><TD width=350 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Opening Price</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Closing Price</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Status</B></TD></TR>\n";
			my $key;
			foreach $key (sort keys %category) {
			opendir THEDIR, "$config{'basepath'}$config{'closedir'}$key" || die "Unable to open directory: $!";
			my @allfiles = readdir THEDIR;
			closedir THEDIR;
			my $file;
			foreach $file (sort { int($a) <=> int($b) } @allfiles) {
			if (-T "$config{'basepath'}$config{'closedir'}$key/$file") {
			open THEFILE, "$config{'basepath'}$config{'closedir'}$key/$file";
			my ($iteminfo, $image, $desc, @bids) = <THEFILE>;
			close THEFILE;
			chomp ($iteminfo, $image, $desc, @bids);
			my @lastbid = split(/\[\]/,$bids[$#bids]);
			$file =~ s/\.dat//;
			my @firstbids =  &read_bid($bids[0]);
			my @itemvals = split(/:::/, $iteminfo);
#			shift @bids; # remove the first bid (start bid)
			foreach my $bid (@bids) { 
				my @nowbid = split(/\[\]/,$bids[0]);
				my @nowbid2 = split(/\[\]/,$bids[1]);
#        print "Bids: @nowbid[0] - @nowbid[1] - @nowbid[2]\n";
				if (@nowbid[0] eq $form{'ALIAS'}) {
				  if (@nowbid2[0]){
						my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bid);
						my @closetime = localtime($file);
						$closetime[4]++;
						my @firstbid =  &read_bid($bids[0]);
						my $timediff = ($file - time);
			#			print "$firstbids[1], $firstbids[2]";
						print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
						print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
						print "<TD BGCOLOR=$config{'colortablebody'}><font color=green><A HREF=$ENV{'SCRIPT_NAME'}\?action=dispcloseditem&category=$form{'category'}$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
						print "<TD BGCOLOR=$config{'colortablebody'}><font color=red><A HREF=$ENV{'SCRIPT_NAME'}\?action=dispcloseditem&category=$form{'category'}$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
						print "&nbsp;&nbsp;&nbsp;$config{'imageiconpath'}" if ($image && ($form{'ALIAS'} eq $alias));
						print "&nbsp;&nbsp;&nbsp;$config{'hoticonpath'} " if ($config{'hotitemnum'} <= $#bids && ($form{'ALIAS'} eq $alias));
						print "&nbsp;&nbsp;&nbsp;$config{'newiconpath'} " if (time<($config{'newdays'} * 86400 + $firstbid[3]) && ($form{'ALIAS'} eq $alias)) ;
						print "&nbsp;&nbsp;&nbsp;$config{'endiconpath'} " if ($timediff<($config{'endhours'} * 3600) && ($form{'ALIAS'} eq $alias));
						print "&nbsp;&nbsp;&nbsp;$config{'auctionicon'} " if ($type eq 'Auction' && ($form{'ALIAS'} eq $alias));
						print "&nbsp;&nbsp;&nbsp;$config{'classicon'} " if ($type eq 'Classified' && ($form{'ALIAS'} eq $alias));
						print "&nbsp;&nbsp;&nbsp;$config{'wantedicon'} " if ($type eq 'Wanted' && ($form{'ALIAS'} eq $alias));
						print "</TD>" if ($form{'ALIAS'} eq $alias);
						print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
						print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
						print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
						print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
						print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>$config{'highbiddericon'} </font></B></td><TR> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));


						print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font color=red>Sold </font></B></td><TR>"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					}	
				}
			} 
	
			
			}
		}
	}
	print "</table>";

	print "<p><br>	\n";

#######################
## Display Items I've listed
##

	&oops('You must enter an alias that consists of alphanumeric characters.') if $form{'ALIAS'} =~ /\W/ or !($form{'ALIAS'});
			$form{'ALIAS'} =~ s/\W//g;
			$form{'ALIAS'} = lc($form{'ALIAS'});
			$form{'ALIAS'} = ucfirst($form{'ALIAS'});
			&oops('Your ALIAS does not exist') unless (open(REGFILE, "$config{'basepath'}$config{'regdir'}/$form{'ALIAS'}.dat"));
			my ($password,$email,$add1,$add2,$add3) = <REGFILE>;
			chomp($password,$email,$add1,$add2,$add3);
			close REGFILE;
			&oops('Your password is incorrect.') if $form{'PASSWORD'} ne $password;
#			print "<CENTER><H2>Closed Listings $form{'ALIAS'} has bid on:</H2>\n";
			print "<table BORDER=1 bgcolor=#6082D2 cellspacing=0 cellpadding=0 width=700><tr><td colspan=5><font color=white><H2>Items I've listed:</H2></font></td></tr>\n";
#			print "<TABLE BORDER=1 BGCOLOR=$config{'colortablebody'} WIDTH=700 CELLSPACING=0 CELLPADDING=0>\n";
			print "<TR><TD width=100 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item Number</B></TD><TD width=350 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Item</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Opening Price</B></TD><TD width=75 ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Closing Price</B></TD><TD ALIGN=CENTER BGCOLOR=$config{'colortablehead'}><B>Status</B></TD></TR>\n";
			my $key;
			foreach $key (sort keys %category) {
			opendir THEDIR, "$config{'basepath'}$config{'closedir'}$key" || die "Unable to open directory: $!";
			my @allfiles = readdir THEDIR;
			closedir THEDIR;
			my $file;
			foreach $file (sort { int($a) <=> int($b) } @allfiles) {
			if (-T "$config{'basepath'}$config{'closedir'}$key/$file") {
			open THEFILE, "$config{'basepath'}$config{'closedir'}$key/$file";
			my ($iteminfo, $image, $desc, @bids) = <THEFILE>;
			close THEFILE;
			chomp ($iteminfo, $image, $desc, @bids);
			my @lastbid = split(/\[\]/,$bids[$#bids]);
			my @itemvals = split(/:::/, $iteminfo);
			$file =~ s/\.dat//;
			my @firstbids =  &read_bid($bids[0]);
#			shift @bids; # remove the first bid (start bid)
			foreach my $bid (@bids) { 
				my @nowbid = split(/\[\]/,$bids[0]);
		#			print "Bids: @nowbid[0]\n";
				if (@nowbid[0] eq $form{'ALIAS'}) {
					my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bid);
					my @closetime = localtime($file);
					$closetime[4]++;
					my @firstbid =  &read_bid($bids[0]);
					my $timediff = ($file - time);
		#			print "$firstbids[1], $firstbids[2]";
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TR><TD BGCOLOR=$config{'colortablebody'}><font color=black>$file</B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=green><A HREF=$ENV{'SCRIPT_NAME'}\?action=dispcloseditem&category=$form{'category'}$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD BGCOLOR=$config{'colortablebody'}><font color=red><A HREF=$ENV{'SCRIPT_NAME'}\?action=dispcloseditem&category=$form{'category'}$key\&item=$file>$itemvals[0]</a></B></font>" if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "&nbsp;&nbsp;&nbsp;$config{'imageiconpath'}" if ($image && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'hoticonpath'} " if ($config{'hotitemnum'} <= $#bids && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'newiconpath'} " if (time<($config{'newdays'} * 86400 + $firstbid[3]) && ($form{'ALIAS'} eq $alias)) ;
					print "&nbsp;&nbsp;&nbsp;$config{'endiconpath'} " if ($timediff<($config{'endhours'} * 3600) && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'auctionicon'} " if ($type eq 'Auction' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'classicon'} " if ($type eq 'Classified' && ($form{'ALIAS'} eq $alias));
					print "&nbsp;&nbsp;&nbsp;$config{'wantedicon'} " if ($type eq 'Wanted' && ($form{'ALIAS'} eq $alias));
					print "</TD>" if ($form{'ALIAS'} eq $alias);
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $bid</TD> "if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=red>\$ $lastbid[2]</font></TD>\n"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
	#				print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font size=-1 color=green>$config{'highbiddericon'} </font></B></td><TR> "if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));
					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font color=green>Closed </font></B></td><TR>"if ($form{'ALIAS'} eq $alias && ($bid eq $lastbid[2]));

					print "<TD ALIGN=CENTER BGCOLOR=$config{'colortablebody'}><B><font color=red>Sold </font></B></td><TR>"if ($form{'ALIAS'} eq $alias && ($bid ne $lastbid[2]));
				}
			} 
	
			
			}
		}
	}
	print "</table>";	

	
	
	
#################
## Profile info
##
my ($password,$email,$add1,$add2,$add3,@past_bids) = &read_reg_file($form{'ALIAS'}); 
&oops('Your alias could not be found!') unless ($form{'ALIAS'}); 
&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));

    print "<p align=center><font face=\"Arial\"><strong><u>Profile for $form{'ALIAS'}</u></strong></font></p>";
    print "<div align=center><center>";
    print "<table border=0 cellpadding=3 cellspacing=0 width=500>";
    print "<tr><td><font size=2 face=Arial>Name:</font></td><td><font size=2 face=Arial>$add1</font></td></tr>";
    print "<tr><td><font size=2 face=Arial>Street Address:</font></td><td><font size=2 face=Arial>$add2</font></td></tr>";
    print "<tr><td><font size=2 face=Arial>City, County, Postal Code:</font></td>";
    print "<td><font size=2 face=Arial>$add3</font></td></tr>";
    print "<tr><td><font size=2 face=Arial>E-mail address:</font></td><td><font size=2 face=Arial><a href=mailto:$email>$email</a></font></td></tr>";
	print "<tr><td colspan=2>&nbsp;</td></tr>";
	print "<tr><td colspan=2 align=center><font face=arial size=2>To change these details click <A HREF=$ENV{'SCRIPT_NAME'}?action=creg><strong>here</strong></a>.</font></td></tr>";
	print "<tr><td colspan=2>&nbsp;</td></tr>";
#	print "<tr><td colspan=2><hr align=center noshade color=#000080></td></tr>";
#	print "<tr><td colspan=2 align=center><U><font face=arial size=2><strong>Auctions that you are active in.</strong></font></U><br><br></td></tr>";
    print "</tr></table></center></div>";

	
	
}

##############################################################
#This is the sub that processes tracking

sub proctrack {
   
    $form{'item'} = ucfirst(lc($form{'item'}));
    $form{'category'} = (lc($form{'category'}));
    
    &oops('You must enter your username !') if ($form{'ALIAS'} eq "");
    &oops('You must enter a password !') if ($form{'PASSWORD'} eq "");
  	
  	my ($password,$email,$add1,$add2,$add3,@past_bids) = &read_reg_file($form{'ALIAS'});
  	
  	&oops('Your alias could not be found !') if ($password eq "");
	&oops('Your password is incorrect.') unless ((lc $password) eq (lc $form{'PASSWORD'}));
	
	my ($iteminfo, $image, $desc, @bids) = &read_item_file($form{'CATEGORY'},$form{'ITEM'});
  my @itemvals = split(/:::/, $iteminfo);
	
	&oops("Item $form{'ITEM'} or category $form{'category'} could not be found . The item number or category may have been mistyped .") if $itemvals[0] eq '';
	open(TRACKFILE, "$config{'basepath'}$config{'trackpath'}$form{'ALIAS'}.track");
	
	(@watch) = <TRACKFILE>;
    
    close TRACKFILE;
    chomp(@watch);
        
    my $file ;
    
    for($i=0;$i<=$#watch;$i++) {
	   $file =~ s/^$config{'basepath'}$form{'category'}\///;
	   $file =~ s/\.dat$//;
	@watching = split(/\[\]/,$watch[$i]);
    
    my $file = $watching[1];
    my $category = $watching[0];
       
    if ($form{'ITEM'} eq $file and $form{'CATEGORY'} eq $category) {
    
       &oops('You are already tracking this item')
    }
    else { } 
    }
	
	&oops('We were unable to write') unless (open(TRACKFILE, ">>$config{'basepath'}$config{'trackpath'}$form{'ALIAS'}.track"));
	
	   print TRACKFILE "$form{'CATEGORY'}\[\]$form{'ITEM'}\n";
	
	close TRACKFILE;
		print "<HTML>";
		print "<HEAD>";
		print "<TITLE></TITLE>";
		print "</HEAD>";
		print "$config{'header'}";
		print "$config{'navbar'}";
		print "<B>You are now tracking item $form{'ITEM'} from $category{$form{'CATEGORY'}}</B>\n\n";
		print "$config{'navbar'}";
		print "$config{'footer'}";
		print "</BODY>";
		print "</HTML>";
#	   print "<table align=center width=320 border=0 cellspacing=0 cellpadding=0 >";
#       print "<tr><td align=center><font size=4><b>You are now tracking item $form{'ITEM'} from $category{$form{'CATEGORY'}}</font></b></td></tr></table>";
}


###############################################################
## Sub to delete individual entries


sub deleteeye {

	open TRACKITEM, "$config{'basepath'}$config{'trackpath'}$form{'ALIAS'}.track" || die "Sorry, you are currently not tracking any items.";
   	(@watch) = <TRACKITEM>;
	chomp(@watch);
	close TRACKITEM;
	if ($form{'ITEM'} eq "") {
	 
	 &oops('You must first specify an item to delete')
		
	}
	
    $numwatch = $#watch;

    for($i=0;$i<=$#watch;$i++) {
	    @tracking = split(/\[\]/,$watch[$i]);

	    %category = ();
	    %item = ();

		if ($tracking[1] eq $form{'ITEM'}) {
			$category[$i] = "";
			$item[$i] = "";
		}

		else {
			$category[$i] = $tracking[0];
			$item[$i] = $tracking[1];
		}
	}

	open TRACKITEM, ">$config{'basepath'}$config{'trackpath'}$form{'ALIAS'}.track" || die "Sorry, you are currently not tracking any items.";
    (@watch) = <TRACKITEM>;
    chomp(@watch);

	for($i=0;$i<=$numwatch;$i++) {
		if ($category[$i] eq "") {
			print TRACKITEM "";
		}

		else {
			print TRACKITEM "$category[$i]\[\]$item[$i]\n";
		}
	}       
    close TRACKITEM;

    &proctracking

}

#-#############################################
# Sub: Time Remain
# Time Display

sub time_remain($){
    my $diff = $_[0] - time;
    if($diff < 0){ return "<font color=red><b>Closed</b></font>" }
    my $days  = int ( $diff                                  / 86400);
    my $hours = int (($diff - $days * 86400)                 / 3600 );
    my $mins  = int (($diff - $days * 86400 - $hours * 3600) / 60   );
    if($days > 1){
        return "<nobr><font color=green><b>$days Days $hours Hrs+</b></font></nobr>";
    }elsif($days == 1){
        return "<nobr><b>1 Day $hours Hrs+<b></nobr>";
    }elsif($hours > 12){
        return "<nobr><b>$hours Hrs $mins Min+<b></nobr>";
    }elsif($hours > 0){
        return "<nobr><font color=red><b>$hours Hrs $mins Min+<b></font></nobr>";
    }else{
        my $secs = int ($diff-($days*86400)-($hours*3600)-($mins*60));
        return "<nobr><font color=red><b>$mins Min $secs Sec+</b></font></nobr>";
    }
}

#-#############################################
# Sub: time left
# revised w/ proper english - smarter output
# Note: This sub does not handle the year change properly, yet.
# Also may not handle leap years. Fixes are welcome.
#
# Note: Fix was applied 1/17/01

sub timeleft {

 my ($rsecond, $rminute, $rhour, $rday, $timeremain, $adddays);
 my ($second, $minute, $hour, $dayofmonth, $month, $year, $weekday, $dayofyear, $iddst) = localtime($_[0]); 
 my ($csecond, $cminute, $chour, $cdayofmonth, $cmonth, $cyear, $cweekday, $cdayofyear, $ciddst) = localtime(time); 
if (($cyear % 4) == 0) { 
$adddays = 366; 
} 
else { 
$adddays = 365; 
} 
if ($cyear != $year) { 
$dayofyear = ($dayofyear + $adddays); 
} 


  if ($second >= $csecond) { $rsecond = ($second - $csecond); }
  else { $rsecond = (($second + 60) - $csecond);
         $minute = ($minute - 1); }

  if ($minute >= $cminute) { $rminute = ($minute - $cminute); }
  else { $rminute = (($minute + 60) - $cminute);
         $hour = ($hour - 1); }

  if ($hour >= $chour) { $rhour = ($hour - $chour); }
  else { $rhour = (($hour + 24) - $chour);
         $dayofyear = ($dayofyear - 1); }

    if ($dayofyear == $cdayofyear) {
     if($rhour < 1) {
      if($rminute < 1) {
       if ($rminute = 0) { $timeremain = "<font color=red> auction has ended</font>"; }
       else { 
         $timeremain = sprintf('%02d seconds', $rsecond);
         my @s = split / /, $timeremain;
         if ($s[0] eq "01") {$s[1] = "second";}
         $timeremain = "<font color=red> " . "$s[0] $s[1]"; }}

      else {
       $timeremain = sprintf('%02d minutes %02d seconds', $rminute, $rsecond);
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "minute";}
       if ($s[2] eq "01") {$s[3] = "second";}
       $timeremain = "<font color=red> " . "$s[0] $s[1] $s[2] $s[3]"; }}

     else {
       $timeremain = sprintf('%02d hours %02d minutes', $rhour, $rminute); 
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "hour";}
       if ($s[2] eq "01") {$s[3] = "minute";}
       $timeremain = "<font color=red> " . "$s[0] $s[1] $s[2] $s[3]"; }}

    else {
     $rday = ($dayofyear - $cdayofyear);
 
     if ($rday <= -1) { $timeremain = "<font color=red> auction has ended</font>"; }
     else {
       $timeremain = sprintf('%02d days %02d hours +', $rday, $rhour);
       my @s = split / /, $timeremain;
       if ($s[0] eq "01") {$s[1] = "day";}
       if ($s[2] eq "01") {$s[3] = "hour";}
       if ($s[2] eq "00") {($s[3], $s[2], $s[4]) = (" 1 hour","\<","");}
       $timeremain = "$s[0] $s[1] $s[2] $s[3] $s[4]"; }
     }
  return "$timeremain";
}    


1;
