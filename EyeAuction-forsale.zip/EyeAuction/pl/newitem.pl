use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#   
#-#############################################
# Add New Item
# This allows a new item to be put up for sale


	my $inc = '.25'; # default increment
	my ($iteminfo, $image, $desc, @bids, $categorytable);
	my @itemvals = split(/:::/, $iteminfo);
	if ($form{'action'} eq "repost"){
##########################################
# Changed 6/20/02 to make relistings work properly
# replaced the line below with the line above
#
#	if ($form{'REPOST'}) {
		$form{'REPOST'} =~ s/\W//g;
		if (-T "$config{'basepath'}$config{'closedir'}$form{'category'}/$form{'item'}.dat") {
			open THEFILE, "$config{'basepath'}$config{'closedir'}$form{'category'}/$form{'item'}.dat";
			($iteminfo, $image, $desc, @bids) = <THEFILE>;
			close THEFILE;
			chomp($iteminfo, $image, $desc, @bids);
#			$title =~ s/\"//g;  # quotes cause problems for a text input field
		}
		$inc = $itemvals[2]
	}
	my $key;
	foreach $key (sort keys %category) {
		$categorytable .= "<OPTION VALUE=\"$key\">$category{$key}</OPTION>\n";
	}
# Set the default incriment	
	$inc = $config{'newinc'};
	my @itemvals = split(/:::/, $iteminfo);
	if ($config{'regdir'}) {
    print	&load_template ('newitemreg.html', { 
				CATEGORYTABLE 	=>	$categorytable,
				DESC			=>	$desc,
				INC				=>	$inc,
				IMAGE			=>	$image,
				CATFEAT		=>	$itemvals[5],
				ITEMTITLE	=>	$itemvals[0],
				%globals
	});      
	}
	else {
    print	&load_template ('newitemnoreg.html', { 
				CATEGORYTABLE => $categorytable,
				DESC			=>	$desc,
				INC				=>	$inc,
				IMAGE			=>	$image,
				CATFEAT		=>	$itemvals[5],
				TITLE			=>	$itemvals[0],
				%globals
	});   
	}
1;
