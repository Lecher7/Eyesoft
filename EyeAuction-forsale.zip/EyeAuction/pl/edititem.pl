use strict;
#
#
# License: No one is licensed or authorized to use this code in whole or in part without
# prior written consent from Eye Software Solutions.
#  
#-#############################################
# Edit Item
# This allows an item to be edited


#	my $inc = '.25'; # default increment
	my ($iteminfo, $image, $desc, @bids, $categorytable);
	my @itemvals = split(/:::/, $iteminfo);
	my (@lastbid, @firstbid);

	
#	if ($form{'action'} eq "editpost"){
#		$form{'EDITPOST'} =~ s/\W//g;
		if (-T "$config{'basepath'}$form{'category'}/$form{'item'}.dat") {
			open THEFILE, "$config{'basepath'}$form{'category'}/$form{'item'}.dat";
			($iteminfo, $image, $desc, @bids) = <THEFILE>;
			close THEFILE;
			chomp($iteminfo, $image, $desc, @bids);
		}
#	}
	my $key;
	foreach $key (sort keys %category) {
		$categorytable .= "<OPTION VALUE=\"$key\">$category{$key}</OPTION>\n";
	}
	
  ########### Get the listing price ############
#	my $itembid = &bidz($form{'category'},$form{'item'});
	@firstbid = split(/\[\]/,$bids[0]);
#    print "Bidx: $bids[0]\n";
#    print "BidY: @firstbid[2]\n";
  ###########  #################################
	
		my $numbids = $#bids;
# print "bids: $numbids\n";
	my @itemvals = split(/:::/, $iteminfo);
&oops("Item $form{'item'} could not be edited because it has bids on it.") unless ($numbids == 0);

	if ($config{'regdir'}) {
    print	&load_template ('edititemreg.html', { 
				CATEGORYTABLE 	=>	$categorytable,
				DESC			=>	$desc,
				INC				=>	$itemvals[2],
				IMAGE			=>	$image,
				CATFEAT		=>	$itemvals[5],
				ITEMTITLE	=>	$itemvals[0],
				ITEMNUM   =>  $form{'item'},
				BID       =>  @firstbid[2],
				COUNTER   =>  $itemvals[3],
				GRABBER		=>  $itemvals[4],				
				BOLDITEM  =>  $itemvals[6],
				BUYIT			=>  $itemvals[7],
				RELIST		=>  $itemvals[8],	
# Added 7/21/02 to be able to move item to a new category when edited				
				OLDCAT    =>  $form{'category'},
				%globals
	});      
	}
#	else {
#    print	&load_template ('edititemnoreg.html', { 
#				CATEGORYTABLE => $categorytable,
#				DESC			=>	$desc,
#				INC				=>	$inc,
#				IMAGE			=>	$image,
#				CATFEAT		=>	$catfeat,
#				TITLE			=>	$title,
#				ITEMNUM   =>  $form{'item'}
#				%globals
#	});   
#	}

#######################################
# sub bidz
sub bidz{
	&oops("Item $form{'item'} could not be opened.") unless (my ($title, $reserve, $inc, $desc, $image, $counter, $catfeat, $grabber, $bolditem, @bids) = &read_item_file($form{'category'},$form{'item'}));
	my ($bidsout, $reserveout, $template, $seller, $highbidder, $lowest_new_bid, $buyerrating);
	my $nowtime = localtime(time);
	my $closetime = localtime($form{'item'});
	my $timeleft = &timeleft($form{'item'});

	my $imageout = "<IMG SRC=$image>" if ($image);
	my ($selleralias, $selleremail, $sellerbid, $sellertime, $selleradd1, $selleradd2, $selleradd3) = &read_bid($bids[0]); # read first bid
	my $bidstart = localtime($sellertime);
	my $numbids = $#bids;
	my ($alias, $email, $lastbid, $time, $add1, $add2, $add3) = &read_bid($bids[$numbids]); # read last bid
	if ($alias eq $selleralias){
		$lastbid = $sellerbid;
	}
	else {
	
	}

	if ($#bids) {
		shift @bids; # remove the first bid (start bid)
		for (my $i=0; $i<scalar(@bids); $i++) {
			my ($alias, $email, $bid, $time, $add1, $add2, $add3) = &read_bid($bids[$i]);
			my $bidtime = localtime($time);
			$bidsout .= "<FONT SIZE=-1>$alias \($bidtime\) - \$$bid</FONT><BR>";
		$lowest_new_bid = &parsebid($bid + $inc);
		}
	}
	else {
		$bidsout .= "<FONT SIZE=-1>No bids yet...</FONT><BR>";
		$lowest_new_bid = (&read_bid($bids[0]))[2];
	}
	return "$lowest_new_bid";
}	



1;
