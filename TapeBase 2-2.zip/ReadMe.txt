TapeBase 2.2

Username: Guest
Password: Guest
Reg #: 0000-0000-0000

If you're online and you buy, sell or trade, having a database to store
your information can be key to keeping yourself organized.  With TapeBase 2.0
you can do just that.  Not only can you store all your information about
the shows you have, but if you have access to a web server that allows
ASP pages, you can put your list online in a matter of seconds!  No need
to make info pages for each show, TapeBase 2.2 will generate the page for
you!  Saves time, webspace and energy.  For a quick look at a sample
database, go to:  http://www.aftk.com/scripts/BootList.asp

It is recommended that you create a directory on your local drive called TapeBase,
and copy the MDE file there.  MDE files are stand-alone Microsoft Access files that
do NOT require the user to have Microsoft Access installed on their machine.

The unregistered version will allow you to enter, edit and delete all information
in the database, but will NOT allow you to print reports.  For a Registration # to
unlock that capability, please send a request to jdibella@sbcglobal.net.  After you register
the product, I will e-mail you the ASP files to allow you to generate a complete
website (like the one above) for people to view your shows.  All other software of 
this nature is in excess of $50, so $30 is certainly fair.  I think you'll find that 
its usefullness will more than adequately be worth the fee.

This is a "Work In Progress", as is all software.  Please report any bugs and/or
requests for increased functionality to its authors:

John DiBella - jdibella@sbcglobal.net
Frank Demaio - ropedope@optonline.net

All code and concepts contained within are �2003 Eye Software Solutions

------****************************************************************************-----
Version 2.2 added functionality:
  � Added "Forest" concept to handle Weeds, Vines and Trees
  
Version 2.0 added functionality:
  � Added the concept of "Genres" to the database
  � Added seperate Audio and Video forms for more flexability
  � Added Website Customization form to registered databases
  � Changed menuing system for easier understanding
  
This version is now a complete Audio/Video inventory program, allowing you to track and 
report your entire collection, from audio cassettes to DVDs.  With the "Librarian" function
you can also keep track of items you lend out and/or receive from friends.